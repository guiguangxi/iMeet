'use strict';

define(["app","meeting"], function (app,meeting) {
    console.log('commonService is called!');
    
    app.service('commonService', ['$rootScope','$location','$window', function($rootScope,$location,$window) {
        //standard
        //type: popup类型（alert/confirm/others）
        //msg: popup 提示信息内容
        //callback: popup 按钮点击的回调函数
        function standardPopup(type,msg,callback){
            if(type == 1){
                extendPopup("",msg,callback,"",[{text:"OK",value:0}],"");
            }else if(type == 2){
                extendPopup("",msg,callback,"",[{text:"OK",value:1},{text:"CANCEL",value:0}],"");
            }
        }
        //extendPopup(3,"","Welcome Welcome Welcome Welcome",[fun1,fun2,fun3],[{text:'OK',value:1},{text:'Cancel',value:0}]);
        //type: popup类型（alert/confirm/others），此处暂时没设定。没用
        //title: popup 提示标题（如：warning/tips)
        //msg: popup 提示信息内容
        //callback: popup 按钮点击的回调函数
        //cancelcallback:对应所传参数btnvalarr中value值是-1的时候需要调用的函数
        //btnvalarr: popup 按钮对应的value值（即，相应按钮名字）如果value是-1，则表示CANCEL取消按钮也绑定cancelcallback回调函数
        //extend
        //param: Other parameter
        function extendPopup(title,msg,callback,cancelcallback,btnvalarr,param){
            var msg_h = $(".pop_msg").height(),
                popBtns = $(".pop_btns"),
                len = btnvalarr.length;
            popBtns.html("");
            $(".pop_title").html("");
            $(".pop_msg").text("");
            if(title != ""){
                $(".pop_title").text(title+":");
            }
            $(".pop_msg").text(msg);
            if(msg_h > 25){
                $(".pop_msg").css({"text-align":"justify"});
            }
            if(len == 1){
                $("<a href='javascript:;' class='pop_btn' id='pop_btn'></a>").html(btnvalarr[0].text).addClass("only_btn").appendTo(popBtns);
                $("a.pop_btn").on("click",function(){
                    if(callback){
                        $(".pop").hide();
                        callback(1);
                    }else{
                        $(".pop").hide();
                    }
                });
            }
            if(len == 2){
                for(var i = 0;i < btnvalarr.length;i ++){
                    $('<a href="javascript:;" class="pop_btn" id="pop_btn'+i+'"></a>').html(btnvalarr[i].text).addClass("two_btn").appendTo(popBtns);
                    if(btnvalarr[i].value == 0 || btnvalarr[i].value == -1){
                        var index = $(this).index();
                        $(".pop_btn").eq(index).addClass("oColor");
                    }
                }
                for(var i = 0;i < $("a.pop_btn").length;i ++){
                    $("a.pop_btn").eq(i).on("click",function(){
                        var index = $(this).index();
                        if(btnvalarr[index].value == 1){
                            $(this).parents().find(".pop").hide();
                            callback(1,param);
                        }else if(btnvalarr[index].value == -1){
                            $(this).parents().find(".pop").hide();
                            cancelcallback(-1);
                        }
                        $(".pop").hide();
                    });
                }
            }
            $(".pop").show();
        }
        //拆分日期字符串并重新组合
        //var DD = "08/30/2016";
        function dateFormat(d){//d代表日期
            var newDateType;
            var myDate = new Date(d);
            var Y = myDate.getFullYear();
            var M = myDate.getMonth()+1;
            var D = myDate.getDate();
            if(M < 10){
                M = "0" + M;
            }
            if(D < 10){
                D = "0" + D;
            }
            if(d.indexOf("-") > 0){//MM/DD/YYYY
                newDateType = M + '/' + D + '/' + Y;
            }else if(d.indexOf("/") > 0){//YYYY-MM-DD
                newDateType = Y + '-' + M + '-' + D;
            }else{
            	 newDateType = M + '/' + D + '/' + Y;
            }
            return newDateType;
        }
        //Count Down 倒计时
        //countDown();
        function countDown(deadtime){//deadtime 即会议或活动开始时间或结束时间 改参数格式必须是日期+时间:如10/28/2016 8:00
            var deadTime = deadtime;
            //console.log(deadTime);
            var countdowntime;
            var deadline= new Date(deadTime); //会议开始时间
            var now = new Date();
            var diff = -480 - now.getTimezoneOffset(); //是北京时间和当地时间的时间差
            //console.log(deadline.getTime());
            //console.log(now.getTime());
            var leave = (deadline.getTime() - now.getTime()) + diff*60000;
            var day = Math.floor(leave / (1000 * 60 * 60 * 24));
            var hour = Math.floor(leave / (1000*3600)) - (day * 24);
            if(hour < 10){
                hour = "0" + hour;
            }
            var minute = Math.floor(leave / (1000*60)) - (day * 24 *60) - (hour * 60);
            if(minute < 10){
                minute = "0" + minute;
            }
            var second = Math.floor(leave / (1000)) - (day * 24 *60*60) - (hour * 60 * 60) - (minute*60);
            if(second < 10){
                second = "0" + second;
            }
            if (leave>0){
                if(day > 0){
                    countdowntime = day + "Day" + "  " + hour + ":" + minute + ":" + second;
                }else{
                    countdowntime = hour+":"+minute+":"+second;
                }

            }else{
                countdowntime = "00"+":"+"00"+":"+"00";
                //alert("The meeting has expired!");
            }
            return {
                countdowntime:countdowntime,
                leave:leave
            };
        }
        function getQueryString(name) {
            var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
            var r = window.location.search.substr(1).match(reg);
            if (r != null)return unescape(r[2]);
            return null;
        }
        //function setIntervalCountDown(deadtime){
        //    setInterval(function(){countDown(deadtime);},1000);
        //}
        //拆分日期获取年，月，日，时，分，秒
        function splitDate(date){
            var dateSplitObj = {},myDate;
            if(date){
                myDate = new Date(date);
            }else{
                myDate = new Date();
            }
            dateSplitObj.Year = myDate.getFullYear();
            dateSplitObj.Mon = myDate.getMonth() + 1;
            if(dateSplitObj.Mon < 10){
                dateSplitObj.Mon = "0" + dateSplitObj.Mon;
            }
            dateSplitObj.Day = myDate.getDate();
            if(dateSplitObj.Day < 10){
                dateSplitObj.Day = "0" + dateSplitObj.Day;
            }
            dateSplitObj.Week = myDate.getDay();
            dateSplitObj.Hour = myDate.getHours();
            if(dateSplitObj.Hour < 10){
                dateSplitObj.Hour = "0" + dateSplitObj.Hour;
            }
            dateSplitObj.Min = myDate.getMinutes();
            if(dateSplitObj.Min < 10){
                dateSplitObj.Min = "0" + dateSplitObj.Min;
            }
            dateSplitObj.Sec = myDate.getSeconds();
            if(dateSplitObj.Sec < 10){
                dateSplitObj.Sec = "0" + dateSplitObj.Sec;
            }
            console.log(dateSplitObj.Year + "-" + dateSplitObj.Mon + "-" + dateSplitObj.Day + " " + dateSplitObj.Week + " " + dateSplitObj.Hour + ":" + dateSplitObj.Min + ":" + dateSplitObj.Sec);
            return dateSplitObj;
        }
        //格式化number字符串。普通number字符串与金额number字符串相互转化
        //"120000000"转"120,000,000" 或 "10,000,000,000 或 10,880.76"转"10000000000" 10880.76
        function sumOfMoneyFormat(numstr) {
            var resnumstr;
            if(numstr =="" || numstr == null || numstr == undefined){
                return ;
            }else{
                if(numstr.indexOf(",") > 0){
                    resnumstr = numstr.replace(/\,/g,"");
                }else{
                    if(numstr.indexOf(".") > 0){
                        var idx = numstr.indexOf(".");
                        var xiaoshu = numstr.substring(idx + 1);

                        var zint = numstr.substring(0, idx);

                        if (zint.length <= 3) {
                            resnumstr = (numstr == 0 ? '' : numstr);
                        }else {
                            var mod = zint.length % 3;
                            resnumstr = (mod == 0 ? '' : (zint.substring(0, mod)));
                            for (var i = 0; i < Math.floor(zint.length / 3); i++) {
                                if ((mod == 0) && (i == 0))
                                    resnumstr += zint.substring(mod + 3 * i, mod + 3 * i + 3);
                                else
                                    resnumstr += ',' + zint.substring(mod + 3 * i, mod + 3 * i + 3);
                            }
                            resnumstr = resnumstr + "." + xiaoshu;
                        }
                    }else{
                        if (numstr.length <= 3) {
                            resnumstr = (numstr == 0 ? '' : numstr);
                        }else {
                            var mod = numstr.length % 3;
                            resnumstr = (mod == 0 ? '' : (numstr.substring(0, mod)));
                            for (var i = 0; i < Math.floor(numstr.length / 3); i++) {
                                if ((mod == 0) && (i == 0))
                                    resnumstr += numstr.substring(mod + 3 * i, mod + 3 * i + 3);
                                else
                                    resnumstr += ',' + numstr.substring(mod + 3 * i, mod + 3 * i + 3);
                            }
                        }
                    }
                }
            }
            return resnumstr;
        }
        //Amount format
        //amount 为带","的金额数值。返回不带","的数值。如传入"1,000"或"12,000.56" 则输出"1000"和"12000.56"
        function amountToNumFormat(amount){
            var resnumstr;
            if(amount =="" || amount == null || amount == undefined){
                return ;
            }else if(amount.indexOf(",") > 0){
                resnumstr = amount.replace(/\,/g,"");
            }else{
                resnumstr = amount;
            }
            return resnumstr;
        }
        //numstr传入的数值，为不带","逗号的数值。返回带","逗号的数值。如传入"1000"或"10000"或"12000.88"等，则返回"1.000""10,000""12,000.88"
        function numToAmountFormat(numstr){
            var resnumstr;
            if(numstr =="" || numstr == null || numstr == undefined){
                return ;
            }else{
                if(numstr.indexOf(".") > 0){
                    var idx = numstr.indexOf(".");
                    var xiaoshu = numstr.substring(idx + 1);

                    var zint = numstr.substring(0, idx);

                    if (zint.length <= 3) {
                        resnumstr = (numstr == 0 ? '' : numstr);
                        //return resnumstr;
                    }else {
                        var mod = zint.length % 3;
                        resnumstr = (mod == 0 ? '' : (zint.substring(0, mod)));
                        for (var i = 0; i < Math.floor(zint.length / 3); i++) {
                            if ((mod == 0) && (i == 0))
                                resnumstr += zint.substring(mod + 3 * i, mod + 3 * i + 3);
                            else
                                resnumstr += ',' + zint.substring(mod + 3 * i, mod + 3 * i + 3);
                        }
                        resnumstr = resnumstr + "." + xiaoshu;
                        //return resnumstr;
                    }
                }else{
                    if (numstr.length <= 3) {
                        resnumstr = (numstr == 0 ? '' : numstr);
                        //resnumstr = resnumstr.toFixed(2);
                        //return resnumstr;
                    }else {
                        var mod = numstr.length % 3;
                        resnumstr = (mod == 0 ? '' : (numstr.substring(0, mod)));
                        for (var i = 0; i < Math.floor(numstr.length / 3); i++) {
                            if ((mod == 0) && (i == 0))
                                resnumstr += numstr.substring(mod + 3 * i, mod + 3 * i + 3);
                            else
                                resnumstr += ',' + numstr.substring(mod + 3 * i, mod + 3 * i + 3);
                        }
                    }
                }
            }
            return resnumstr;
        }

        function randNumber(){
            var rand = "";
            for(var i = 0; i < 3; i++){
                var r = Math.floor(Math.random() * 10);

                rand += r;

            }t
        }
        function toUpperCaseFirstLetter(str){
            var str = str.toLowerCase();
            var strarr = str.split(' ');
            var result = '';
            for(var i in strarr){
                result += strarr[i].substring(0,1).toUpperCase()+strarr[i].substring(1)+' ';
            }
            return result;
        }

        return {
            standardPopup:standardPopup,
            extendPopup:extendPopup,
            dateFormat:dateFormat,
            systemInfo:getQueryString,
            countDown:countDown,
            splitDate:splitDate,
            sumOfMoneyFormat:sumOfMoneyFormat,
            amountToNumFormat:amountToNumFormat,
            numToAmountFormat:numToAmountFormat,
            randNumber:randNumber,
            toUpperCaseFirstLetter:toUpperCaseFirstLetter
        };
    }]);
    meeting.service('commonService', ['$rootScope','$location','$window', function($rootScope,$location,$window) {
        //standard
        //type: popup类型（alert/confirm/others）
        //msg: popup 提示信息内容
        //callback: popup 按钮点击的回调函数
        function standardPopup(type,msg,callback){
            if(type == 1){
                extendPopup("",msg,callback,[{text:"OK",value:0}]);
            }else if(type == 2){
                extendPopup("",msg,callback,[{text:"OK",value:1},{text:"CANCEL",value:0}]);
            }
        }
        //extendPopup(3,"","Welcome Welcome Welcome Welcome",[fun1,fun2,fun3],[{text:'OK',value:1},{text:'Cancel',value:0}]);
        //type: popup类型（alert/confirm/others），此处暂时没设定。没用
        //title: popup 提示标题（如：warning/tips)
        //msg: popup 提示信息内容
        //callback: popup 按钮点击的回调函数
        //btnvalarr: popup 按钮对应的value值（即，相应按钮名字）
        //extend
        function extendPopup(title,msg,callback,btnvalarr){
            var msg_h = $(".pop_msg").height(),
                popBtns = $(".pop_btns"),
                len = btnvalarr.length;
            popBtns.html("");
            $(".pop_title").html("");
            $(".pop_msg").text("");
            if(title != ""){
                $(".pop_title").text(title+":");
            }
            $(".pop_msg").text(msg);
            if(msg_h > 25){
                $(".pop_msg").css({"text-align":"justify"});
            }
            if(len == 1){
                $("<button type='button' class='pop_btn'></button>").html(btnvalarr[0].text).addClass("only_btn").appendTo(popBtns).on("click",function(){
                    $(".pop").hide();
                });
            }
            if(len == 2){
                for(var i = 0;i < btnvalarr.length;i ++){
                    $("<button type='button' class='pop_btn'></button>").html(btnvalarr[i].text).addClass("two_btn").appendTo(popBtns);
                    if(btnvalarr[i].value == 0){
                        var index = $(this).index();
                        $(".pop_btn").eq(index).addClass("oColor");
                    }
                }
                for(var i = 0;i < $("button").length;i ++){
                    $(".pop_btn").eq(i).on("click",function(){
                        var index = $(this).index();
                        if(btnvalarr[index].value == 1){
                            callback(1);
                        }
                        $(".pop").hide();
                    });
                }
            }
            $(".pop").show();
        }
        //拆分日期字符串并重新组合
        //var DD = "08/30/2016";
        function dateFormat(d){//d代表日期
            var newDateType;
            var myDate = new Date(d);
            var Y = myDate.getFullYear();
            var M = myDate.getMonth()+1;
            var D = myDate.getDate();
            if(M < 10){
                M = "0" + M;
            }
            if(D < 10){
                D = "0" + D;
            }
            if(d.indexOf("-") > 0){//MM/DD/YYYY
                newDateType = M + '/' + D + '/' + Y;
            }else if(d.indexOf("/") > 0){//YYYY-MM-DD
                newDateType = Y + '-' + M + '-' + D;
            }else{
                newDateType = M + '/' + D + '/' + Y;
            }
            return newDateType;
        }
        //拆分日期获取年，月，日，时，分，秒 date必须是MM/DD/YYYY or YYYY-MM-DD
        function splitDate(date){
            var dateSplitObj = {},myDate;
            if(date){
                myDate = new Date(date);
            }else{
                myDate = new Date();
            }
            dateSplitObj.Year = myDate.getFullYear();
            dateSplitObj.Mon = myDate.getMonth() + 1;
            if(dateSplitObj.Mon < 10){
                dateSplitObj.Mon = "0" + dateSplitObj.Mon;
            }
            dateSplitObj.Day = myDate.getDate();
            if(dateSplitObj.Day < 10){
                dateSplitObj.Day = "0" + dateSplitObj.Day;
            }
            dateSplitObj.Week = myDate.getDay();
            dateSplitObj.Hour = myDate.getHours();
            if(dateSplitObj.Hour < 10){
                dateSplitObj.Hour = "0" + dateSplitObj.Hour;
            }
            dateSplitObj.Min = myDate.getMinutes();
            if(dateSplitObj.Min < 10){
                dateSplitObj.Min = "0" + dateSplitObj.Min;
            }
            dateSplitObj.Sec = myDate.getSeconds();
            if(dateSplitObj.Sec < 10){
                dateSplitObj.Sec = "0" + dateSplitObj.Sec;
            }
            console.log(dateSplitObj.Year + "-" + dateSplitObj.Mon + "-" + dateSplitObj.Day + " " + dateSplitObj.Week + " " + dateSplitObj.Hour + ":" + dateSplitObj.Min + ":" + dateSplitObj.Sec);
            return dateSplitObj;
        }
        
        return {
            standardPopup:standardPopup,
            extendPopup:extendPopup,
            dateFormat:dateFormat,
            splitDate:splitDate
        };
    }]);
});
