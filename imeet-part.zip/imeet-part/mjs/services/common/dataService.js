'use strict';

define(["app"], function (app) {
    console.log('dataService is called!');
    
    app.service('dataService', function() {
    	this.sysInfo;
        this.products;
        this.health;
        this.healthHtml;
        this.healthRequestStep;
        this.protectProducts;
        this.protectProductsTitle;
        this.productDetails;
        this.insured;
        this.pdflists;
        this.objProductData ;
        this.objRiderData;
        this.oncetimeLoadFlag;
    });
});