'use strict';

define(["app"], function (app) {
    console.log('IMeetWebService is called!');
    
    app.factory('IMeetWebService', ['$http','$q', function($http,$q) {
        function syncPost(url,param){
            var deferred = $q.defer();  
            var req = {
                     method: 'POST',
                     url:url,
                     headers: {
                       'Content-Type': 'application/json'
                     },
                     data: param
                    }
            $http(req).success(function(data){
                 deferred.resolve(data);  
            }).error(function(error) {
                deferred.reject(error);
            });
            return deferred.promise; 
        };
        
        function syncJsonPost(url,param){
            param['callback'] = 'JSON_CALLBACK';
            var deferred = $q.defer();  
            var req = {
                     method: 'JSONP',
                     url:url,
                     headers: {
                       'Content-Type': 'application/json'
                     },
                     data: param
                    }
            $http(req).success(function(data){
                 deferred.resolve(data);  
            }).error(function(error) {
                deferred.reject(error);
            });
            return deferred.promise; 
        };
        
        return {
            syncPost:syncPost,
            syncJsonPost:syncJsonPost
        };
    }]);
});