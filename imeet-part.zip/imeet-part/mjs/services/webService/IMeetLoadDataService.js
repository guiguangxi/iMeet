'use strict';

define(["app"], function (app) {
    console.log('IMeetLoadDataService is called!');
    
    app.service('IMeetLoadDataService', ['$http','$q','IMeetWebService','dataService', function($http,$q,IMeetWebService,dataService) {

        function loadData(type,param){
            console.log(param);
        	console.warn("load :" + type);
            var promise;
            if(type == 'products'){
                $(".loading").show();
                promise = IMeetWebService.syncPost('jsondata/tsconfig.json',{}).then(function(data){
                   dataService.products = data.meetingmodel.productmodel.data;

                    $(".loading").hide();
                   return true;
               },function(error){
                  console.log(error);
                  return false;
               })
            }else if(type == 'protectionProducts'){
                promise = IMeetWebService.syncPost('jsondata/tsconfig1.json',{}).then(function(data){
                	dataService.protectProducts = data.meetingmodel.productmodel.data;
                    dataService.protectProductsTitle = data.meetingmodel.productmodel.ui;
                    return true;
               },function(error){
                  console.log(error);
                  return false;
               });
            }else if(type == 'productDetails'){
                promise = IMeetWebService.syncPost('jsondata/tsconfig2.json',{}).then(function(data){
                    dataService.productDetails = data.meetingmodel.productmodel.data;
                    //dataService.protectProductsTitle = data.meetingmodel.productmodel.ui;
                    return true;
                },function(error){
                    console.log(error);
                    return false;
                });
            }else if(type == 'insured'){
                console.log(param);
                if(param == "pro_plusMore_quote"){
                    var deledtElem = dataService.objProductData;
                    for(var key in deledtElem){
                        delete deledtElem[key];
                    }
                }
                promise = IMeetWebService.syncPost('jsondata/insured.json',{}).then(function(data){
                    dataService.insured = data.meetingmodel.productmodel.data;
                    return true;
                },function(error){
                    console.log(error);
                    return false;
                });

            }else{
                promise = $q.when(true).then(function(){
                      return true;
                   });
            }
            return promise;
        }
        
        return {
            loadData:loadData
        };
    }]);
});