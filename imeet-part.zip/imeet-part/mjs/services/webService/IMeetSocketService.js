'use strict';

define(["app"], function (app) {
    console.log('IMeetSocketService is called!');
    
    app.factory('IMeetSocketService', ['$rootScope','$location','$window','dataService','commonService', function($rootScope,$location,$window,dataService,commonService) {
            // We return this object to anything injecting our service
            // Create our websocket object with the address to the websocket
            
            var url = $location.absUrl();
            
            var ishttps = 'https:' == document.location.protocol ? true: false;
            var ip = "";
            var port = "";
            if(ishttps){
            	ip = "aiaimeet.com";
            	port = "8489";
            }else{
            	ip = "54.255.164.113";
            	port = "8089";
            }
            
            
            
            var token = 'a123456789012334444444';
            var reg = new RegExp("(^|&)token=([^&]*)(&|$)");
            
            var s=url.indexOf("?"); 
            var s1 = url.indexOf("#/");
            var searchObj = '';
            if(s1 == -1){
                searchObj=url.substring(s+1);
            }else{
                searchObj=url.substring(s+1,s1);
            }
            var r = searchObj.match(reg);
            
            if (r != null){
                token =  unescape(r[2]);
            }
            
            var ws;
            var heartBeatTime = 30;
            $rootScope.sysInfo = {};
            $rootScope.sysInfo['token'] = token;
            var socketConnectCount = 0;
            //$rootScope.sysInfo['token'] = "0123456789009876";//modify
            
            function connect(){
	            if(ishttps){
	            	ws  = new WebSocket("wss://"+ ip +":" + port + "/WebSocket//aiaWebsocket/" +  $rootScope.sysInfo.token);
	            }else{
	            	ws  = new WebSocket("ws://"+ ip +":" + port + "/WebSocket//aiaWebsocket/" +  $rootScope.sysInfo.token);
	            }
            	
	            
	            ws.onopen = function(){  
	                console.log("Socket has been opened!");  
	                socketConnectCount = 0;
	                heartBeat(heartBeatTime*1000);
	            };
	            
	            ws.onmessage = function(message) {
                    try{
                        var data = angular.fromJson (message.data);
                        var scope = angular.element("#" + data.elementID).scope();
                          scope.$apply(
                              function(){
                                  scope.listener(data);
                              }
                          );
                    }catch(e){
                        // statements
                        console.log(e);
                    }
	            };
	            ws.onclose = function(cb){
	            	if(socketConnectCount == 0){
	            		reconnect();
	            		return;
	            	}
	            	if(!ws||ws.readyState==3){
                        commonService.standardPopup(1,"Do you want to reconnect?",reconnect);
                        return;
	            		//reconnect();
	            	}	            	
	            }
            }
            //重新连接websocket
            function reconnect(value){
                if(value == 1){
                    if(ws){
                    	socketConnectCount ++;
                        connect();
                    }
                }
            }
            
            function heartBeat(value){
            	var timer = setInterval(function() {
                    var msg = {
                            "code": 'heartBeat'
                        };
            		sendRequest(msg);
                }, value);
            }
            
            
            //function reconnect(){
            //	if(ws){
            //		connect();
            //	}
            //}
            //对应webSocket连接失败是的popup的取消按钮
            //function cancelCallBack(value,that){
            //    if(value == -1){
            //        if((/iphone|ipad/gi).test(navigator.appVersion)) {
            //            //此处执行返回代码
            //            console.log("this");
            //            //that.html('<a href="ios:///{"method":"back"}">'+btnvalarr[index].text+'</a>');
            //        }else{
            //            //此处执行关闭当前浏览器
            //            $window.opener=null;
            //            $window.open('','_self');
            //            $window.close();
            //            $window.open("","_self").close();
            //            $window.open("about:blank","_self").close();
            //        }
            //    }
            //}
            function sendRequest(msg) {
            	if(ws.readyState==1){
            		ws.send(JSON.stringify(msg));
                }else{
                	console.log('WebSocket did not connected!');
                }
            }

            function createData(user,id,value,func,type) {
                var msg = {
                    "role": user,
                    "result":value,
                    "pos": [],
                    "elementID": id,
                    "action":func,
                    "type": type
                };
                return msg;
            }
            
         
            
            connect();
        return {
            createData:createData,
            sendRequest:sendRequest
        };
    }]);
});