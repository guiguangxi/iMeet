'use strict';

define([
        'app',
        'route-config'
    ],

    function (app, routeConfig) {
        return app.config(function ($routeProvider) {
        //products page
        $routeProvider.when('/products', routeConfig.config('view/products/products.html', 'controllers/products/productsCtrl'));
        $routeProvider.when('/protectionProducts', routeConfig.config('view/products/protectionProducts.html', 'controllers/products/protectProductsCtrl'));
        $routeProvider.when('/productDetails', routeConfig.config('view/products/productDetails.html', 'controllers/products/productDetailsCtrl'));
        $routeProvider.when('/pro_plusMore_quote', routeConfig.config('view/quotations/insured.html', 'controllers/quotations/insuredCtrl'));
        //quotations page
        $routeProvider.when('/quotations', routeConfig.config('view/quotations/quotations.html', 'controllers/quotations/quotationsCtrl'));
        $routeProvider.when('/quo_plusMore_add', routeConfig.config('view/quotations/add.html', 'controllers/quotations/addCtrl'));
        $routeProvider.when('/quo_plusMore_apply', routeConfig.config('view/application/appDetailsQuotation.html', 'controllers/application/appDetailsQuotationCtrl'));
        $routeProvider.when('/quo_plusMore_compare', routeConfig.config('view/quotations/compare.html', 'controllers/quotations/compareCtrl'));
        $routeProvider.when('/insured', routeConfig.config('view/quotations/insured.html', 'controllers/quotations/insuredCtrl'));
        $routeProvider.when('/backToInsured', routeConfig.config('view/quotations/insured.html', 'controllers/quotations/insuredCtrl'));
        $routeProvider.when('/quo_plusMore_tryMore', routeConfig.config('view/quotations/quotations.html', 'controllers/quotations/quotationsCtrl'));
        $routeProvider.when('/insure_plusMore_apply', routeConfig.config('view/application/appDetailsQuotation.html', 'controllers/application/appDetailsQuotationCtrl'));
        $routeProvider.when('/additional_plusMore_apply', routeConfig.config('view/application/appDetailsQuotation.html', 'controllers/application/appDetailsQuotationCtrl'));
        $routeProvider.when('/additional', routeConfig.config('view/quotations/additional.html', 'controllers/quotations/additionalCtrl'));

        $routeProvider.when('/pdfview', routeConfig.config('view/pdfview.html', 'controllers/pdfviewCtrl'));

            // $routeProvider.otherwise({redirectTo:'/products'});
    });
});
