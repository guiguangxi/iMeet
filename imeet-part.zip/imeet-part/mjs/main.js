'use strict';

//requireJS
requirejs.config({
    baseUrl:'mjs',
    urlArgs: 'ver=2017010901',
    paths:{
        'text': 'lib/require/text', //HTML
        'jquery': 'lib/jquery/jquery',
        // 'angular': 'lib/angular/angular',
        'angular': 'lib/angular/angular1.5.8',
        'angular-route':'lib/angular/angular-route',
        'angular-sanitize':'lib/angular/angular-sanitize',
        'angular-strap':'lib/angularstrap/angular-strap',
        'angular-strap.tpl':'lib/angularstrap/angular-strap.tpl',
        'es5-sham':'lib/es5Sham/es5-sham.min',
        'bootstrap': 'lib/bootstrap',
        
        'pdfjs':'lib/pdfview/pdf.combined',
        
        
        'angularPdfService':'lib/pdfview/delegate-service',
        'angularPdfDelegate':'lib/pdfview/pdf-viewer-delegate',
        'angularPdfCtrl':'lib/pdfview/pdf-ctrl',
        'angularPdfviewer':'lib/pdfview/pdf-viewer',
        'angularPdftoolbar':'lib/pdfview/pdf-viewer-toolbar',
        
        /*'angularPdfviewer':'lib/pdfview/angular-pdf-viewer.min',*/
        
        'dataService':'services/common/dataService',
        'commonService':'services/common/commonService',
        'IMeetWebService':'services/webService/IMeetWebService',
        'IMeetSocketService':'services/webService/IMeetSocketService',
        'IMeetLoadDataService':'services/webService/IMeetLoadDataService',

        'popupDirective': 'directives/popupDirective',
        'canvasDirective': 'directives/canvasDirective',
        'scrollDirective': 'directives/scrollDirective',

        'quoinsuredaddlistDirective':'directives/quoinsuredaddlistDirective',
        //'pdfDirectice':'directives/pdfDirective',
        'addlistCtrl':'controllers/addlistCtrl',

        'navCtrl': 'controllers/navCtrl',
        'canvasCtrl':'controllers/canvasCtrl',
        'scrollController': 'controllers/scrollController',

        'videoImp': 'video/videoInterface',

        'jsondata': '../jsondata'
        
    },
    waitSeconds: 0,
    shim:{
        'angular':{
            deps:['jquery'],
            exports:'angular'
        },
        'app':{
            deps:['angular']
        },
        'router':{
            deps:['angular']
        },
        'angular-route':{
            deps:['angular']
        },
       
        'angular-sanitize':{
            deps:['angular']
        },
        'angular-strap':{
            deps:['angular']
        },
        'angular-strap.tpl':{
            deps:['angular','angular-strap']
        },
        'es5-sham':{
            deps:['angular']
        },
        /*
        'angularPdfviewer':{
            deps:['angular','pdfjs']
        }*/
        'angularPdfDelegate':{
            deps:['angular']
        },
        'angularPdfCtrl':{
            deps:['angular','angularPdfDelegate']
        },
        'angularPdftoolbar':{
            deps:['angular','angularPdfDelegate']
        },
        
        'angularPdfviewer':{
            deps:['angular','angularPdfDelegate','angularPdftoolbar','angularPdfService','angularPdfCtrl','pdfjs']
        },
        
        
       
        
        
    }
});

requirejs([
        'text', 
        'jquery', 
        'angular', 
        'angular-route',
        'angular-sanitize',
        'angular-strap',
        'angular-strap.tpl',
        'es5-sham',
        'app', //app.js
        'router', //routes.js

        'commonService',
        'dataService',
        'IMeetSocketService',
        'IMeetWebService',
        'IMeetLoadDataService',

        'popupDirective',
        'scrollDirective',
        'canvasDirective',

        'quoinsuredaddlistDirective',
        //'pdfDirectice',
        'addlistCtrl',

        'navCtrl',
        'canvasCtrl',
        'scrollController',

       /* 'angularPdfviewer',*/
        'angularPdfService',
        'angularPdfviewer',       
        
        'videoImp'
        
    ],
    function (text, $, angular,$location){
        angular.element(document).ready(function(){
            angular.bootstrap(document, ['iMeet']);
            initTemasys();
        });
    }
);
