'use strict';

define([ 'angular', 'route-config'], function(angular, routeConfig) {
	var meeting = angular.module('meeting', ['ngRoute', 'ui.timepicker','ngSanitize','mgcrea.ngStrap.datepicker','mgcrea.ngStrap.timepicker','mgcrea.ngStrap.helpers.dateParser','mgcrea.ngStrap.helpers.dateFormatter'], function($provide,
			$compileProvider, $controllerProvider, $filterProvider) {
		routeConfig.setProvide($provide); // for services
		routeConfig.setCompileProvider($compileProvider); // for directives
		routeConfig.setControllerProvider($controllerProvider); // for controllers
		routeConfig.setFilterProvider($filterProvider); // for filters
	}).run(function ($rootScope){
		//$rootScope.root = "root";
		
		// get website information
		function initSystemData() {
			var rootObj={};
			var Url = window.location.href;
			var curObj = getC(Url);
			var ishttps = 'https:' == document.location.protocol ? true: false;
						
			if (typeof curObj.agent_code == "undefined") {
				rootObj.agent_code = "0913";
			}else{
				rootObj.agent_code = curObj.agent_code;
			}
			if (typeof curObj.agent_name == "undefined") {
				rootObj.agent_name = "casso";
			}else{
				rootObj.agent_name = curObj.agent_name;
			}
			if (typeof curObj.mrm_server == "undefined") {
				if(ishttps){
					rootObj.mrmServerURL = "https://aiaimeet.com:8488";
				}else{
					rootObj.mrmServerURL = "http://54.255.164.113:8088";
				}
				
				// mrmServerURL = "http://172.16.11.173:8088";
			}else{
				rootObj.mrmServerURL = curObj.mrm_server;
			}
			if (typeof curObj.web_server == "undefined") {
				if(ishttps){
					
					rootObj.webServerURL = "https://aiaimeet.com/imeet-web";
				}else{
					rootObj.webServerURL = "http://54.255.164.113:8080/imeet-web";
				}
				
			}else{
				rootObj.webServerURL = curObj.web_server;
			}
			if (typeof curObj.video_name == "undefined") {
				rootObj.video_name = "Temasys";
			}else{
				rootObj.video_name = curObj.video_name;
			}

			return rootObj;

		}
		;
		// parse url information
		function getC(url) {// 从携带参数的Url里截取所携带的参数并将其转换成参数对象集,可从对象中获取已知参数名称的值
			var obj = {};
			var temp = url.split("#");
			//var cs = url.sub(url.indexOf("?") + 1,url.indexOf("#"));
			
			var cs = temp[0].substr(temp[0].indexOf("?") + 1);
			
			//var cs = url.substr(url.indexOf("?") + 1);
//			var cs = url.substr(url.indexOf("?") + 1);
			// console.log(cs);
			var arr1 = cs.split("=");
			// console.log(arr1);
			var arrLen1 = cs.split("=").length - 1;
			// console.log(arrLen1);
			if (arrLen1 > 1) {
				var arr2 = cs.split("&");
				// console.log(arr1);
				for (var i = 0; i < arr2.length; i++) {
					// console.log(arr2[i].split("="));
					obj[(arr2[i].split("="))[0]] = (arr2[i].split("="))[1];
				}
			} else if (arrLen1 == 1) {
				obj[arr1[0]] = arr1[1];
			} else {
				// popAlert("The URL did not carry parameters!");
				// return;
			}
			return obj;
		}
		;
		
		$rootScope.rootObj = initSystemData();

		//alert($rootScope.rootObj);
		
	});
	meeting.controller("meetingFormController",function($scope){
		$scope.options = {
			step: 30,
			timeFormat: 'H:i'
		}
	});
	meeting.directive('popup', function() {
		return {
			restrict : 'E',
			replace : true,
			transclude : true,
			template : '<div>'+
			'<div class="pop_cont">'+
			'<h2 class="pop_title"></h2>'+
			'<p class="pop_msg"></p>'+
			'<div class="pop_btns"></div>'+
			'</div>'+
			'<div class="mask"></div>'+
			'</div>'
		}
	});

	

	/*
	 * app.controller('navCtrl', function($scope,$rootScope,$location) {
	 * console.log('navCtrl is called!'); $scope.navClick = function(param){
	 * angular.element("#" +
	 * param.id).parent().find("div").attr("style","display:none");
	 * angular.element("#" + param.id +" div").attr("style","display:block");
	 * //send message to server var url = '/'+ param.id.replace("_nav","");
	 * console.log(url); //change view $location.path(url);
	 * 
	 * if(msgStatus){
	 * socketService.sendMsgToServer(param.id,"","onclick","onclick"); }else{
	 * msgStatus = true; } } });
	 */

	// loading
	// app.factory('myInterceptor', ["$rootScope", function ($rootScope) {
	// var timestampMarker = {
	// request: function (config) {
	// $rootScope.loading = true;
	// return config;
	// },
	// response: function (response) {
	// $rootScope.loading = false;
	// return response;
	// }
	// };
	// return timestampMarker;
	// }]);
	/*
	 * app.directive("scroll", function ($window) { return function(scope,
	 * element, attrs) { angular.element($window).bind("scroll", function(e) {
	 * console.log(window.pageYOffset); scope.visible = false; scope.$apply();
	 * //send message to server if(msgStatus){
	 * socketService.sendMsgToServer(window.pageYOffset,"","scroll","scroll");
	 * }else{ msgStatus = true; } }); }; });
	 */

	return meeting;
});