'use strict';

define(["app"], function (app) {

    app.filter('encodeURIComponent', function() {
        return window.encodeURIComponent;
    });
})


