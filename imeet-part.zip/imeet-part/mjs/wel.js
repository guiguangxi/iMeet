/**
 * Created by Gola Zhai on 16/10/13.
 */
'use strict';

//requireJS
requirejs.config({
    baseUrl:'mjs',
    urlArgs: 'ver=2017010901',
    paths:{
        'jquery': 'lib/jquery/jquery',
        'angular': 'lib/angular/angular1.5.8',
        'angular-route':'lib/angular/angular-route',
        'bootstrap': 'lib/bootstrap',
        'commonService':'services/common/commonService',
        'popupDirective': 'directives/popupDirective',
        'welcomeCtrl':'controllers/welcomeCtrl',
        'pdfjs':'lib/pdfview/pdf.combined',
        'angular-sanitize':'lib/angular/angular-sanitize',
        'angular-strap':'lib/angularstrap/angular-strap',
        'angular-strap.tpl':'lib/angularstrap/angular-strap.tpl',
        'es5-sham':'lib/es5Sham/es5-sham.min',
        
        'angularPdfService':'lib/pdfview/delegate-service',
        'angularPdfDelegate':'lib/pdfview/pdf-viewer-delegate',
        'angularPdfCtrl':'lib/pdfview/pdf-ctrl',
        'angularPdfviewer':'lib/pdfview/pdf-viewer',
        'angularPdftoolbar':'lib/pdfview/pdf-viewer-toolbar',
        'jsondata': '../jsondata'
    },
    waitSeconds: 0,
    shim:{
        'angular':{
            deps:['jquery'],
            exports:'angular'
        },
        'welcomeCtrl':{
            deps:['angular']
        },
        'angular-route':{
            deps:['angular']
        },
        'angular-strap':{
            deps:['angular']
        },
        'angular-strap.tpl':{
            deps:['angular','angular-strap']
        },
        'es5-sham':{
            deps:['angular']
        },
        'angular-sanitize':{
            deps:['angular']
        },
        'angularPdfDelegate':{
            deps:['angular']
        },
        'angularPdfCtrl':{
            deps:['angular','angularPdfDelegate']
        },
        'angularPdftoolbar':{
            deps:['angular','angularPdfDelegate']
        },
        
        'angularPdfviewer':{
            deps:['angular','angularPdfDelegate','angularPdftoolbar','angularPdfService','angularPdfCtrl','pdfjs']
        }
    }
});

requirejs([
        'jquery',
        'angular',
        'angular-route',
        'angular-sanitize',
        'angular-strap',
        'angular-strap.tpl',
        'es5-sham',
        'welcomeCtrl',
        'commonService',
        'popupDirective',
        'angularPdfService',
        'angularPdfviewer'
        
    ],
    function ($, angular) {
        $(document).ready(function () {
            angular.bootstrap(document, ['iMeet']);
        });
    }
);
