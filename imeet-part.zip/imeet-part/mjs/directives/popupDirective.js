'use strict';

define(["app"], function(app) {
	console.log('popup directive is called!');
	app.directive('popup', function() {
	    return {
	        restrict : 'E',
	        replace : true,
	        transclude : true,
	        template : '<div>'+
	                        '<div class="pop_cont" id="pop_cont">'+
	                            '<h2 class="pop_title" id="pop_title"></h2>'+
	                            '<p class="pop_msg" id="pop_msg"></p>'+
	                            '<div class="pop_btns" id="pop_btns"></div>'+
	                        '</div>'+
	                        '<div class="mask" id="mask"></div>'+
	                    '</div>'
	    }
	});
});
