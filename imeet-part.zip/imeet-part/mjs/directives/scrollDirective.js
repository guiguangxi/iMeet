'use strict';

define(["app"], function(app) {
	console.log('scroll directive is called!');
	app.directive('scroll', function ($window,$document){
	    return function(scope, element, attrs) {
            	angular.element($window).bind("scroll", function(e) {
                    scope.visible = false;
                    scope.$apply();
                    
                    var scopeScroll = angular.element("#scroll").scope();
                    scopeScroll.$apply(
                        function(){
                     	   scopeScroll.scrollStop(window.pageYOffset);
                        });
                });
            };
	});
});
