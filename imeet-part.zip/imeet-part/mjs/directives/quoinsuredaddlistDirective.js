/**
 * Created by admin on 16/10/18.
 */
'use strict';

define(["app"], function(app) {
    console.log('quotation insured addlist directive is called!');
    app.directive('quoinsuredaddlist', function() {
        return {
            restrict : 'E',
            replace : true,
            transclude : true,
            template : '<div>'+
                            '<div id="quo_plusMore_cont" class="quo_plusMore_cont" ng-show="quoplusmorecontstatus">'+
                                '<ul id="quo_plusMore_list" class="quo_plusMore_list" ng-show="quoliststatus">'+
                                	
                                    '<li id="quo_plusMore_preview" class="quo_plusMore_preview" ng-click="preview($event)">' +
                                        '<a href="javascript:;">' +
                                            '<span class="quo_plusMore_icon quo_plus_sign"></span><span class="quo_plusMore_txt">PREVIEW</span>' +
                                        '</a>' +
                                    '</li>'+
                                    '<li id="quo_plusMore_tryMore" ng-click="getOtherPage($event)">' +
                                        '<a href="javascript:;">' +
                                            '<span class="quo_plusMore_icon quo_plus_trymore"></span><span class="quo_plusMore_txt" >TRY MORE</span>' +
                                        '</a>' +
                                    '</li>'+
                                    '<li id="insure_plusMore_apply">' +
                                        '<a href="javascript:;">' +
                                            '<span class="quo_plusMore_icon quo_plus_apply"></span><span class="quo_plusMore_txt">APPLY</span>' +
                                        '</a>' +
                                    '</li>'+
                                '</ul>'+
                                '<button type="button" id="quo_plusBtn" class="quo_plusBtn" ng-show="quobtnstatus" ng-click="showQuoInsuredAddlist($event)">' +
                                    '<a class="quo_plusBtn_add" href="javascript:;"></a>'+
                                '</button>'+
                            '</div>'+
                            '<div id="quo_plusMoreMask" class="quo_plusMoreMask" ng-show="quomaskstatus" ng-click="hideQuoInsuredAddlist($event)"></div>'+
                        '</div>'
        }
    });
    app.directive('quoaddlist', function() {
        return {
            restrict : 'E',
            replace : true,
            transclude : true,
            template : '<div>'+
                            '<div id="quo_plusMore_cont1" class="quo_plusMore_cont quo_plusMore_cont1" ng-show="quoplusmorecontstatus1">'+
                                '<ul id="quo_plusMore_list" class="quo_plusMore_list" ng-show="quoliststatus1">'+
                                    '<li id="quo_plusMore_add" class="quo_plusMore_preview" ng-click="getOtherPage($event)">' +
                                        '<a href="javascript:;">' +
                                            '<span class="quo_plusMore_icon quo_plus_add quo_more"></span><span class="quo_plusMore_txt">ADD</span>' +
                                        '</a>' +
                                    '</li>'+
                                    '<li id="quo_plusMore_apply">' +
                                        '<a href="javascript:;">' +
                                            '<span class="quo_plusMore_icon quo_plus_apply1 quo_more"></span><span class="quo_plusMore_txt">APPLY</span>' +
                                        '</a>' +
                                    '</li>'+
                                    '<li id="quo_plusMore_compare" ng-click="getOtherPage($event)">' +
                                        '<a href="javascript:;">' +
                                            '<span class="quo_plusMore_icon quo_plus_compare quo_more"></span><span class="quo_plusMore_txt">COMPARE</span>' +
                                        '</a>' +
                                    '</li>'+
                                    '<li id="quo_plusMore_delete">' +
                                        '<a href="javascript:;">' +
                                            '<span class="quo_plusMore_icon quo_plus_del quo_more"></span><span class="quo_plusMore_txt">DELETE</span>' +
                                        '</a>' +
                                    '</li>'+
                                '</ul>'+
                                '<button type="button" id="quo_plusBtn" class="quo_plusBtn" ng-show="quobtnstatus1" ng-click="showQuoAddlist($event)">' +
                                    '<a class="quo_plusBtn_add" href="javascript:;"></a>'+
                                '</button>'+
                            '</div>'+
                            '<div id="quo_plusMoreMask1" class="quo_plusMoreMask" ng-show="quomaskstatus1" ng-click="hideQuoAddlist($event)"></div>'+
                        '</div>'
        }
    });
    app.directive('productaddlist', function() {
        return {
            restrict : 'E',
            replace : true,
            transclude : true,
            template : '<div>'+
            '<div id="quo_plusMore_cont2" class="quo_plusMore_cont quo_plusMore_cont2" ng-show="quoplusmorecontstatus2">'+
                '<ul id="pro_plusMore_list" class="quo_plusMore_list" ng-show="quoliststatus2">'+
                    '<li id="pro_plusMore_brochure" class="quo_plusMore_preview">' +
                        '<a href="javascript:;">' +
                            '<span class="quo_plusMore_icon quo_plus_brochure quo_more"></span><span class="quo_plusMore_txt">BROCHURE</span>' +
                        '</a>' +
                    '</li>'+
                    '<li id="pro_plusMore_quote" ng-click="getOtherPage($event)">' +
                        '<a href="javascript:;">' +
                            '<span class="quo_plusMore_icon quo_plus_quote quo_more"></span><span class="quo_plusMore_txt">QUOTE</span>' +
                        '</a>' +
                    '</li>'+
                '</ul>'+
                '<button type="button" id="quo_plusBtn" class="quo_plusBtn" ng-show="quobtnstatus2" ng-click="showProductAddlist($event)">' +
                    '<a class="quo_plusBtn_add" href="javascript:;"></a>'+
                '</button>'+
            '</div>'+
                '<div id="quo_plusMoreMask2" class="quo_plusMoreMask" ng-show="quomaskstatus2" ng-click="hideProductAddlist($event)"></div>'+
            '</div>'
        }
    });
});