'use strict';

define([ "app" ], function(app) {
	console.log('init Canvas Directive!');
	app.directive("drawing", function() {
		return {
			restrict : "A",
			link : function(scope, element) {
				var ctx = element[0].getContext('2d');

				// variable that decides if something should be drawn on mousemove
				var drawing = false;
				var type = 'draw';

				// the last coordinates before the current move
				var lastX;
				var lastY;
				var positions;
				function drawDown(event){
					lastX = offsetX(event);
					lastY = offsetY(event);
//					ctx.beginPath();
					positions = new Array();
					drawing = true;
				}
				
				function drawMove(event){
					if(scope.isLock){
						event.preventDefault();
					}else{
						return;
					}
					if (drawing) {
						 var currentX = offsetX(event);
						 var currentY = offsetY(event);
						// get current mouse position
						 if(type == 'clear'){
							 
							 var leftgap = 10;
						 	 var topgap = 30;
							 if(event.type == 'touchstart'||
									   event.type == 'touchmove'||
									   event.type == 'touchend'){
								 	leftgap = 40;
							 		topgap = -50;
										 
							 	}else{
							 		document.getElementById("rubber_content").style.display = "block";

							 		$("#rubber_content").animate({
										left : currentX - leftgap +"px",
										top : currentY + topgap + "px"
							 		}, 0).show('fast');
							 	}
							 
							 clear(currentX, currentY);
						 }else{
							 draw(lastX, lastY, currentX, currentY);
						 }

						 var  position = {lX:lastX,
										 lY:lastY,
										 cX:currentX,
										 cY:currentY};
						 positions.push(position);
						 // set current coordinates to last one
						lastX = currentX;
						lastY = currentY;
					}
				}
				
				function offsetX(event){
					if(event.type == 'touchstart'||
					   event.type == 'touchmove'||
					   event.type == 'touchend'){
						return event.originalEvent.touches[0].pageX - event.originalEvent.touches[0].target.offsetLeft;  
					}
					if (event.offsetX !== undefined) {
						return event.offsetX;
					} else {
						return (event.layerX
								- event.currentTarget.offsetLeft);
					}
				}
				
				function offsetY(event){
					if(event.type == 'touchstart'||
					   event.type == 'touchmove'||
					   event.type == 'touchend'){
						var y = event.originalEvent.touches[0].pageY - event.originalEvent.touches[0].target.offsetTop - 47;
						return y;  
					}
					if (event.offsetY !== undefined) {
						return event.offsetY;
					} else {
						return (event.layerY
								- event.currentTarget.offsetLeft);
					}
				}
				
				function drawUp(event){
					// stop drawing
					scope.finished(type,positions);
					document.getElementById("rubber_content").style.display = "none";
					ctx.closePath();
					lastX;
					lastY;
					drawing = false;

				}
				$(window).bind('mousewheel',function(event){
					if(scope.isLock){
						event.preventDefault();
					}
				});
				$("#rubber_content").bind('mouseup',drawUp());


				//$(window).bind('keydown',function(event){
				//	if(scope.isLock){
				//		event.preventDefault();
				//	}
				//});
				$("#scroll").bind('keydown',function(event){
					if(scope.isLock){
						event.preventDefault();
					}
				});

				element.bind('mousedown', drawDown);
				element.bind('mousemove', drawMove);
				element.bind('mouseup',drawUp);

				element.bind('touchstart', drawDown);
				element.bind('touchmove', drawMove);
				element.bind('touchend',drawUp);
				
				// canvas reset
				function reset() {
					element[0].width = element[0].width;
				}
				
				function draw(lX, lY, cX, cY) {
					console.log('lX=======>'+lX);
					console.log('lY=======>'+lY);
					console.log('cX=======>'+cX);
					console.log('cY=======>'+cY);
					//alert('lX=>'+lX + ";" + 'lY=>' + lY + ";" + "cX=>" + cX + ";" +"cY=>" + cY);
					ctx.beginPath();
					// begins new line
					// line from
					ctx.moveTo(lX, lY);
					// to
					ctx.lineTo(cX, cY);
					// color
					// draw it
					ctx.stroke();
//					
//					ctx.restore();
				}
				
				
				function clear(cX, cY) {
					console.log('cX=======>'+cX);
					console.log('cY=======>'+cY);
					// line from
					ctx.clearRect(cX - 40, cY - 40, 50,50);
					
				}
				
				scope.$on('painting',function(e){ 
					positions = new Array();
					lastX;
					lastY;
					ctx.strokeStyle = 'black';
					ctx.lineJoin = "round";
					ctx.lineCap = "butt";
					ctx.lineWidth = 3;
					type = 'draw';
					document.getElementById("rubber_content").style.display = "none";
				});   
				
				
				scope.$on('highlighter',function(e){ 
					positions = new Array();
					lastX;
					lastY;
					//ctx.strokeStyle = 'rgba(240,240,0,0.1)';
					ctx.strokeStyle = scope.DiyColor;
					ctx.lineJoin = 'round';
					ctx.lineCap = "round";
					//ctx.lineWidth = 50;
					ctx.lineWidth = scope.DiyLineWidth;
					type = 'draw';
					document.getElementById("rubber_content").style.display = "none";
				});

				//highlighter tool S

				scope.$on('hLineSel',function(e,id){
					console.log(id);
					positions = new Array();
					lastX;
					lastY;
					//ctx.strokeStyle = 'rgba(240,240,0,0.1)';
					ctx.lineJoin = 'round';
					ctx.lineCap = "round";
					if(id == "h_line_1"){
						ctx.lineWidth = 10;
						scope.DiyLineWidth = 10;
					}else if(id == "h_line_2"){
						ctx.lineWidth = 20;
						scope.DiyLineWidth = 20;
					}else if(id == "h_line_3"){
						ctx.lineWidth = 30;
						scope.DiyLineWidth = 30;
					}
					//else if(id == "h_line_4"){
					//	ctx.lineWidth = 40;
					//	scope.DiyLineWidth = 40;
					//}
					//ctx.lineWidth = 50;
					type = 'draw';
					document.getElementById("rubber_content").style.display = "none";
				});

				scope.$on('hColorSel',function(e,id){
					console.log(id);
					positions = new Array();
					lastX;
					lastY;
					//ctx.strokeStyle = 'rgba(240,240,0,0.1)';
					ctx.lineJoin = 'round';
					ctx.lineCap = "round";
					if(id == "h_color_1"){
						ctx.strokeStyle = 'rgba(34,168,218,0.2)';
						scope.DiyColor = 'rgba(34,168,218,0.2)';
					}else if(id == "h_color_2"){
						ctx.strokeStyle = 'rgba(251,191,86,0.2)';
						scope.DiyColor = 'rgba(251,191,86,0.2)';
					}else if(id == "h_color_3"){
						ctx.strokeStyle = 'rgba(232,100,135,0.2)';
						scope.DiyColor = 'rgba(232,100,135,0.2)';
					}
					//else if(id == "h_color_4"){
					//	ctx.strokeStyle = 'rgba(15,127,18,0.2)';
					//	scope.DiyColor = 'rgba(15,127,18,0.2)';
					//}
					//ctx.lineWidth = 50;
					type = 'draw';
					document.getElementById("rubber_content").style.display = "none";
				});



				//highlighter tool E

				
				scope.$on('rubber',function(e){ 
					positions = new Array();
					lastX;
					lastY;
					type = 'clear';
				});   

				scope.$on('show',function(e,isShowing){ 
					if(ctx.globalAlpha != 0.5){
						ctx.globalAlpha = 0.5;
					}
					if(isShowing){
						lastX;
						lastY;
					}else{
						ctx.clear();
					}
					document.getElementById("rubber_content").style.display = "none";
				});   
				
				scope.$on('draw',function(e,data){
					lastX;
					lastY;					
//					ctx.beginPath();
					var position = data.positions
					var rateX = element[0].width/data.cwidth;
					var rateY = element[0].height/data.cheight;
					for(var i in position){
						draw(position[i].lX * rateX,position[i].lY * rateY,position[i].cX * rateX,position[i].cY * rateY);
					}
				}); 
				
				
				scope.$on('drawPDF',function(e,data){
					lastX;
					lastY;					
//					ctx.beginPath();
					var position = data.positions
					var rateX = element[0].width/data.cwidth;
					var rateY = element[0].height/data.cheight;
					for(var i in position){
						var lx = position[i].lX;
						var ly = position[i].lY;
						var cx = position[i].cX;
						var cy = position[i].cY;

					
						if(ly <= 50){
							lx = lx;
							ly = ly;
						}else{
							lx = lx * rateX;
							ly = (ly - 50) * rateX + 50;
						}
						
						if(cy <= 50){
							cx = cx;
							cy = cy;
						}else{
							cx = cx * rateX;
							cy = (cy - 50) * rateX + 50;
				
						}
					
						draw(lx,ly,cx,cy);
					}
				}); 
				
				scope.$on('clear',function(e,data){
					lastX;
					lastY;
//					ctx.beginPath();
					var position = data.positions
					var rateX = element[0].width/data.cwidth;
					var rateY = element[0].height/data.cheight;
					for(var i in position){
						clear(position[i].cX * rateX,position[i].cY * rateY);
					}
				}); 
			}
		};
	});
});
