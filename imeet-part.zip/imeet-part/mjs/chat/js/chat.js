/********************************************************
  API Settings
*********************************************************/
var Demo = Demo || {};
Demo.FILE_SIZE_LIMIT = 1024 * 1024 * 200;
Demo.Peers = {};
Demo.FilesPublic = [];
Demo.Files = {};
Demo.Streams = [];
Demo.Methods = {};
Demo.Skylink = new Skylink();
var userList;
var messageList;
var targetPeerId;
var token = getQueryString("token");
var userName = getQueryString("userName");
if(userName == undefined){
    userName = "Mike Yang";
}
console.log(userName);
if(token == undefined){
    token = "ICHAT-ROOM";
}
console.log(token);
//alert("verss");



function addMessage(user, message,chanel) {
    console.log("chanel-----"+chanel);
    //alert(user);
    var timestamp = new Date();
    var tolo=timestamp.toLocaleString()
    var getM=timestamp.getMonth()+1;
    var strO=timestamp.getMonth()>9?timestamp.getMonth().toString():'0' + getM;
    var strM=timestamp.getMinutes()>9?timestamp.getMinutes().toString():'0' + timestamp.getMinutes();
    var strH=timestamp.getHours()>9?timestamp.getHours().toString():'0' + timestamp.getHours();
    var strS=timestamp.getSeconds()>9?timestamp.getSeconds().toString():'0' + timestamp.getSeconds();
    var div = document.createElement('div');
    div.className = "media msg";
    if(chanel == true){
        div.innerHTML = '<div class="media-body">' +
            //'<div style="overflow:hidden">'+
            //'<small class="pull-left time" >' +
            //'<i class="fa fa-clock-o"></i>' +
            //    //timestamp.getFullYear()+'年'+strO+'月'+ strH+ ':' +strM +':'+strS+
            //strO + '/' + timestamp.getFullYear() + ' ' + strH + ':' +strM +':'+strS+
            //'</small>' +
            //'<h5 class="media-heading pull-right">' + user + '</h5>' +
            //'</div>'+
            '<div>'+
            '<p class="pull-right msgInfo" style="display:inline-block;word-break:break-all;max-width:80%;border:1px solid #ccc;border-radius:4px 0 4px 4px;padding:5px;margin-right:2px;background:rgb(162,229,99);">' + message + '</p>' +
            '</div>'+
            '</div>';
    }else if(chanel == false){
        div.innerHTML = '<div class="media-body">' +
            //'<div style="overflow:hidden">'+
            //'<small class="pull-right time" >' +
            //'<i class="fa fa-clock-o"></i>' +
            //    //timestamp.getFullYear()+'年'+strO+'月'+ strH+ ':' +strM +':'+strS+
            //strO + '/' + timestamp.getFullYear() + ' ' + strH + ':' +strM +':'+strS+
            //'</small>' +
            //'<h5 class="media-heading" style="color:#f60;">' + user + '</h5>' +
            //'</div>'+
            '<div>'+
            '<p class="msgInfo" style="display:inline-block;word-break:break-all;max-width:80%;border:1px solid #ccc;border-radius:0 4px 4px 4px;padding:5px;margin-left:2px;background:#faf9f2;">' + message + '</p>' +
            '</div>'+
            '</div>';
    }

    messageList.appendChild(div);
    var stH = messageList.scrollHeight;
    var scH = document.getElementById("chat_msg_body").offsetHeight;
    if(stH >= scH){
        //document.getElementById("chat_log").style.scrollTop = -(stH - scH);
        $("#chat_msg_body").scrollTop(stH - scH);
    }

    //messageList.scrollTop = messageList.scrollHeight;
}

/********************************************************
  Skylink Events
*********************************************************/

//---------------------------------------------------
Demo.Skylink.on('incomingMessage', function(message, peerId, peerInfo, isSelf) {
    var Name = peerInfo.userData;
    if(!isSelf){
        $('#chat_tips').html( "You are chatting with "+ peerInfo.userData );
        targetPeerId = peerId;
        //addMessage(Name, message.content,isSelf);
    }
    addMessage(Name, message.content,isSelf);
});

Demo.Skylink.on('peerJoined', function(peerId, peerInfo, isSelf) {
	//var div = document.createElement('div');
	//  div.className = "media conversation chatUser_li";
	//  div.id = "User_" + peerId;
	//  div.innerHTML = '<div class="media-body">' +
	//    '<h5 id="UserTitle_' + peerId + '" class="media-heading">' + peerInfo.userData + ((isSelf) ? " (Self)" : "") + '</h5>' +
	//    //'<small>' + peerId + '</small>' +
	//    '</div>';
	//  userList.appendChild(div);
  if (!isSelf){
      // $('#title_self').append(" (" + peerInfo.userData + ")");
      //$('#chat_tips').html( "You are chatting with "+ peerInfo.userData );
  }
});

//---------------------------------------------------
Demo.Skylink.on('peerLeft', function(peerId) {
	 //var elm = document.getElementById("User_" + peerId);
	 // if (elm) {
	 //   elm.remove();
	 // } else {
	 //   console.error('Peer "' + peerId + '" DOM element does not exists');
	 // }
    delete Demo.Peers[peerId];
    $('#chat_tips').html("Waiting for supporter join ...");
});

//---------------------------------------------------
Demo.Skylink.on('channelError', function(error) {
  //Demo.Methods.displayChatMessage('System', 'Channel Error:<br>' + (error.message || error));
    addMessage('System', 'Channel Error:<br>' + (error.message || error));
});
//---------------------------------------------------
Demo.Skylink.on('mediaAccessError', function(error) {
    standardPopup(1,(error.message || error));
});

Demo.Skylink.init({
    appKey: '2c771e60-5f86-4bf1-9d21-691b75a3e52c',
    //defaultRoom: "MY_ROOM",
    defaultRoom: token,
    enableDataChannel: true, // Disable this and sendBlobData(), sendP2PMessage() and sendURLData() will NOT work!
    enableIceTrickle: true,
    audioFallback: true,
    forceSSL: true
}, function (error, success) {
  if (success) {
    var displayName = userName;
    Demo.Skylink.joinRoom({
      userData: displayName,
      audio: false,
      video: false
    });
  } else {
      standardPopup(1,'An error occurred parsing and retrieving server code.\n' +
      'Error was: ' + error.errorCode);
  }
})
/********************************************************
  DOM Events
*********************************************************/
$(document).ready(function() {
    //standardPopup(1,"Welcome");
    var wH = window.innerHeight || document.body.clientHeight ||document.documentElement.clientHeight;
    if(wH < 400){
        wH = 400;
    }
    wH = wH - 280;
    $("#chat_msg_body").height(wH);

	userList = document.getElementById("chatUser_list");
    messageList = document.getElementById("chat_msg_log");

  //Public Chat
  $('#chat_input_public').keyup(function(e) {
    e.preventDefault();
    if (e.keyCode === 13) {
        if(targetPeerId == ""){
            return;
        }
        //console.log($('#chat_input_public').val().trim().length);
        if($('#chat_input_public').val().trim() == ""){
            return;
        }
        Demo.Skylink.sendMessage($('#chat_input_public').val(),targetPeerId);
        $('#chat_input_public').val('');
      }
  });
    $("#msg_clear").click(function(){
        $("#chat_msg_log").empty();
    });
    $("#msg_send").click(function(){
        if(targetPeerId == ""){
            return;
        }
        //console.log($('#chat_input_public').val().trim().length);
        if($('#chat_input_public').val().trim() == ""){
            return;
        }
        Demo.Skylink.sendMessage($('#chat_input_public').val(),targetPeerId);
        $('#chat_input_public').val('');
    });
});
$(window).resize(function(){
    var _wH = window.innerHeight || document.body.clientHeight ||document.documentElement.clientHeight;
    if(_wH < 400) {
        _wH = 400;
    }
    _wH = _wH - 280;
    $("#chat_msg_body").height(_wH);
});
//standard
//type: popup类型（alert/confirm/others）
//msg: popup 提示信息内容
//callback: popup 按钮点击的回调函数
function standardPopup(type,msg,callback){
    if(type == 1){
        extendPopup("",msg,"","",[{text:"OK",value:0}]);
    }else if(type == 2){
        extendPopup("",msg,callback,"",[{text:"OK",value:1},{text:"CANCEL",value:0}]);
    }
}
//extendPopup(3,"","Welcome Welcome Welcome Welcome",[fun1,fun2,fun3],[{text:'OK',value:1},{text:'Cancel',value:0}]);
//type: popup类型（alert/confirm/others），此处暂时没设定。没用
//title: popup 提示标题（如：warning/tips)
//msg: popup 提示信息内容
//callback: popup 按钮点击的回调函数
//cancelcallback:对应所传参数btnvalarr中value值是-1的时候需要调用的函数
//btnvalarr: popup 按钮对应的value值（即，相应按钮名字）如果value是-1，则表示CANCEL取消按钮也绑定cancelcallback回调函数
//extend
function extendPopup(title,msg,callback,cancelcallback,btnvalarr){
    var msg_h = $("#pop_msg").height(),
        popBtns = $("#pop_btns"),
        len = btnvalarr.length;
    popBtns.html("");
    $("#pop_title").html("");
    $("#pop_msg").text("");
    if(title != ""){
        $("#pop_title").text(title+":");
    }
    $("#pop_msg").text(msg);
    if(msg_h > 25){
        $("#pop_msg").css({"text-align":"justify"});
    }
    if(len == 1){
        $("<a href='javascript:;' class='pop_btn'></a>").html(btnvalarr[0].text).addClass("only_btn").appendTo(popBtns);
        $("a.pop_btn").on("click",function(){
            $(".pop").hide();
        });
    }
    if(len == 2){
        for(var i = 0;i < btnvalarr.length;i ++){
            $("<a href='javascript:;' class='pop_btn'></a>").html(btnvalarr[i].text).addClass("two_btn").appendTo(popBtns);
            if(btnvalarr[i].value == 0 || btnvalarr[i].value == -1){
                var index = $(this).index();
                $(".pop_btn").eq(index).addClass("oColor");
            }
            if(btnvalarr[i].value == -1){
                var index = $(this).index();
                $(".pop_btn").eq(index).attr({"href":"ios:///{\"method\":\"back\"}"});
            }
        }
        for(var i = 0;i < $("a.pop_btn").length;i ++){
            $("a.pop_btn").eq(i).on("click",function(){
                var index = $(this).index();
                if(btnvalarr[index].value == 1){
                    $(this).parents().find(".pop").hide();
                    callback(1);
                }else if(btnvalarr[index].value == -1){
                    $(this).parents().find(".pop").hide();
                    cancelcallback(-1);
                }
                $(".pop").hide();
            });
        }
    }
    $(".pop").show();
}
//get param from url
function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if (r != null)return unescape(r[2]);
    return null;
}