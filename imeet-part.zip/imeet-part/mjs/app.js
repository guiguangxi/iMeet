'use strict';

define([
        'angular',
        /*
        'angularPdftoolbar',
        'angularPdfCtrl',
        'angularPdfDelegate',
        'angularPdfviewer',
        */
        'route-config'
    ],

    function (angular, routeConfig){
        var app = angular.module('iMeet', ['ngSanitize','mgcrea.ngStrap.select','mgcrea.ngStrap.datepicker','mgcrea.ngStrap.popover','pdf','ngRoute','mgcrea.ngStrap.helpers.dateParser','mgcrea.ngStrap.helpers.dateFormatter'],
            function ($provide, $compileProvider, $controllerProvider, $filterProvider,$locationProvider){
                routeConfig.setProvide($provide); //for services
                routeConfig.setCompileProvider($compileProvider);  //for directives
                routeConfig.setControllerProvider($controllerProvider); //for controllers
                routeConfig.setFilterProvider($filterProvider); //for filters
        }).run(function ($rootScope,$location){
    		//$rootScope.root = "root";
    		
    		// get website information
    		function initSystemData() {
    			var rootObj={};
    			var Url = window.location.href;
    			var curObj = getC(Url);
    			var ishttps = 'https:' == document.location.protocol ? true: false;
    			var prjname='imeet-web';
    			if (typeof curObj.video_name == "undefined") {
    				rootObj.video_name = "Temasys";
    			}else{
    				rootObj.video_name = curObj.video_name;
    			}
    			
    			if (typeof curObj.token == "undefined") {
    				rootObj.token = "a12345678901233";
    			}else{
    				rootObj.token = curObj.token;
    			}
    			
    			if (typeof curObj.user == "undefined") {
    				rootObj.user = "Michael Jackon";
    			}else{
    				rootObj.user = curObj.user;
    			}
    			
    			if (typeof curObj.role == "undefined") {
    				rootObj.role = "customer";
    			}else{
    				rootObj.role = curObj.role;
    			}
    			
    			rootObj.prjname=prjname;
    			var url = $location.absUrl();
                
                var ishttps = 'https:' == document.location.protocol ? true: false;
                var ip = "";
                var port = "";
                if(ishttps){
                	ip = "aiaimeet.com";
                	port = "8489";
                }else{
                	ip = "54.255.164.113";
                	port = "8089";
                }
                rootObj.ip = ip;
                rootObj.port = port;
    			

    			return rootObj;

    		}
    		;
    		// parse url information
    		function getC(url) {// 从携带参数的Url里截取所携带的参数并将其转换成参数对象集,可从对象中获取已知参数名称的值
    			var obj = {};
    			var temp = url.split("#");
    			//var cs = url.sub(url.indexOf("?") + 1,url.indexOf("#"));
    			
    			var cs = temp[0].substr(temp[0].indexOf("?") + 1);
    			
    			//var cs = url.substr(url.indexOf("?") + 1);
//    			var cs = url.substr(url.indexOf("?") + 1);
    			// console.log(cs);
    			var arr1 = cs.split("=");
    			// console.log(arr1);
    			var arrLen1 = cs.split("=").length - 1;
    			// console.log(arrLen1);
    			if (arrLen1 > 1) {
    				var arr2 = cs.split("&");
    				// console.log(arr1);
    				for (var i = 0; i < arr2.length; i++) {
    					// console.log(arr2[i].split("="));
    					obj[(arr2[i].split("="))[0]] = (arr2[i].split("="))[1];
    				}
    			} else if (arrLen1 == 1) {
    				obj[arr1[0]] = arr1[1];
    			} else {
    				// popAlert("The URL did not carry parameters!");
    				// return;
    			}
    			return obj;
    		}
    		;
    		
    		$rootScope.sysInfo = initSystemData();
    		console.log($rootScope.sysInfo);
    		//alert($rootScope.rootObj);
    		
    	});

        return app;
    }
);