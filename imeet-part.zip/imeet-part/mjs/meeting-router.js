'use strict';

define([
        'meeting',
        'route-config'
    ],

    function (meeting, routeConfig) {
        return meeting.config(function ($routeProvider,$httpProvider) {      

                $routeProvider.when('/list', routeConfig.config('view/meetingList.html', 'controllers/meetingListCtrl', {
                    // directives: ['directives/version'], 
                    // services: [], 
                    // filters: ['filters/reverse']
                }));

                /*$routeProvider.when('/form/:params', routeConfig.config('view/meetingForm.html', 'controllers/meetingFormCtrl', {
                    // directives: ['directives/version'], 
                    // services: ['services/tester'], 
                    // filters: []
                }));*/
                
                $routeProvider.when('/form', routeConfig.config('view/meetingForm.html', 'controllers/meetingFormCtrl', {
                    // directives: ['directives/version'], 
                    // services: ['services/tester'], 
                    // filters: []
                }));


                $routeProvider.otherwise({redirectTo:'/list'});
        // $httpProvider.interceptors.push('myInterceptor');  
    });
});
