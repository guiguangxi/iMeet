'use strict';

//requireJS
requirejs.config({
    baseUrl:'mjs',
    paths:{
        'text': 'lib/require/text', //HTML
        'jquery': 'lib/jquery/jquery-2.1.1.min',
        //'jquery-ui': 'lib/jquery/jquery-2.1.1.min',
        'angular': 'lib/angular/angular.min',
        'angular-route':'lib/angular/angular-route',
        'bootstrap': 'lib/bootstrap',
        'commonService':'services/common/commonService',
        'meeting':'meeting',
        'angular-sanitize':'lib/angular/angular-sanitize.min',
        'angular-strap':'lib/angularstrap/angular-strap',
        'angular-strap.tpl':'lib/angularstrap/angular-strap.tpl.min',
        //'angular-mocks':'lib/angular/angular-mocks',
        //'daterangepicker':'lib/daterangepicker',
        'jquery.timerpicker':'lib/jquery.timepicker',
        //'moment':'lib/moment',
        'timepickerdirective':'lib/timepickerdirective',
        'library': 'lib'
    },
    waitSeconds: 0,
    shim:{
        'angular':{
            deps:['jquery'],
            exports:'angular'
        },
//        'angular-mocks':{
//            deps:['angular']
//        },
        'meeting':{
            deps:['angular']
        },
        'meeting-router':{
            deps:['angular']
        },
//        'daterangepicker':{
//            deps:['jquery']
//        },
        'jquery.timerpicker':{
            deps:['jquery']
        },
        'angular-route':{
            deps:['angular']
        },
        'timepickerdirective':{
            deps:['jquery','angular']
        },
        'angular-sanitize':{
            deps:['angular']
        },
        'angular-strap':{
            deps:['angular']
        },
        'angular-strap.tpl':{
            deps:['angular','angular-strap']
        }
    }
});

requirejs([
        'text', 
        'jquery', 
        'angular',
        'angular-route',
       // 'angular-mocks',
        'commonService',
        'meeting',
       // 'daterangepicker',
        'jquery.timerpicker',
        //'moment',
        'timepickerdirective',
        'meeting-router' ,//routes.js
        'angular-sanitize',
        'angular-strap',
        'angular-strap.tpl'
    ],
    function (text, $, angular) {
        $(document).ready(function () {
            angular.bootstrap(document, ['meeting']);
        });

    }
);
