'use strict';

define(["app"], function (app) {
    console.log('scrollController is called!');
    
    app.controller('scrollController', function($window, $rootScope, $location, $scope,IMeetSocketService) {

      //获取ng-view 的宽度，用于pdf中canvas的缩放zoomIn和zoomOut
        var contentLeftWidth = angular.element("#scroll").width();
        $rootScope.contentLeftWidth = contentLeftWidth;
        //console.log(contentLeftWidth);


      function action(yOffset){
          //解决ipad scroll 到底后PC scroll 不到底的问题
        var wH = window.innerHeight | document.body.clientHeight | document.documentElement.clientHeight;
        var scrollH = document.getElementById("scroll").offsetHeight;
          var offH = scrollH - wH;
          if(yOffset >= offH){
              yOffset = yOffset + 60;
          }else{
              yOffset = yOffset;
          }

        window.scrollTo(0,yOffset);
        var timer = setTimeout(function() {
          $scope.scrollStop(-1);
          clearTimeout(timer);
          timer = null;
             }, 250);
          //console.log(yOffset);
      }

      $scope.listener = function(data){
       action(data.result);
      }

      var timer;
      $scope.scrollStop = function(oldOffset){
          if (timer) {
              clearTimeout(timer);
           }
           timer = setTimeout(function() {
             timer = null;
             if(oldOffset == window.pageYOffset){
               var data = IMeetSocketService.createData('agent','scroll',window.pageYOffset, "onclick","onclick");
               IMeetSocketService.sendRequest(data);
                  if (timer) {
                        clearTimeout(timer);
                     }
            }
            }, 250);
      }
      
    });
});