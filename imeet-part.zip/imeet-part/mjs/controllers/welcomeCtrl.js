/**
 * Created by Gola Zhai on 16/10/13.
 */
'use strict';

define(["app","jquery"], function (app,$) {

    app.controller('welController', function($scope,$http,$rootScope,$location,$dateParser,$window,commonService) {
        console.log('welController is called!');

		var wH = window.innerHeight || document.body.clientHeight || document.documentElement.clientHeight;
		var welWrapper = document.getElementById("wel_wrapper");
		welWrapper.style.height = wH + "px";

		/*定义一个月的对象,来处理数字月份和英文月份间的转换*/
		var monthObj = {
			"num_m":["1","2","3","4","5","6","7","8","9","10","11","12"],
			"english_m":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
		};
		/*定义一个星期的对象,用来处理数字星期和英文星期间的转换*/
		var weekObj = {
			"num_w":[1,2,3,4,5,6,0],
			"english_w":["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]
		};
		function dateChangeToWeek(date){
			//var myDate = new Date(date);
			var dateParser = $dateParser();
			var myDate = dateParser.parse(date, null, "dd/MM/yyyy");

			var week = myDate.getDay();
			return week;
		}

		//date convert to english
		function dateConvert(paramDate){
			//var app_date_obj = new Date(paramDate);
			var dateParser = $dateParser();
			var app_date_obj = dateParser.parse(paramDate, null, "dd/MM/yyyy");

			var app_date_m_num = app_date_obj.getMonth()+1;//数字月份
			var app_date_m_eng;//英文月份
			for(var j = 0;j < monthObj.num_m.length;j ++){
				if(app_date_m_num == monthObj.num_m[j]){
					app_date_m_eng = monthObj.english_m[j];
				}
			};
			var app_week_num = dateChangeToWeek(paramDate);
			var app_week_eng;
			for(var n = 0;n < weekObj.num_w.length;n ++){
				if(app_week_num == weekObj.num_w[n]){
					app_week_eng = weekObj.english_w[n]
				}
			};
			return app_week_eng+' '+app_date_obj.getDate()+' '+app_date_m_eng+' '+app_date_obj.getFullYear();//meeting date
		}

		// parse url information
		function getC(url) {// 从携带参数的Url里截取所携带的参数并将其转换成参数对象集,可从对象中获取已知参数名称的值
			var obj = {};
			var temp = url.split("#");
			//var cs = url.sub(url.indexOf("?") + 1,url.indexOf("#"));

			var cs = temp[0].substr(temp[0].indexOf("?") + 1);

			//var cs = url.substr(url.indexOf("?") + 1);
//		var cs = url.substr(url.indexOf("?") + 1);
			// console.log(cs);
			var arr1 = cs.split("=");
			// console.log(arr1);
			var arrLen1 = cs.split("=").length - 1;
			// console.log(arrLen1);
			if (arrLen1 > 1) {
				var arr2 = cs.split("&");
				// console.log(arr1);
				for (var i = 0; i < arr2.length; i++) {
					// console.log(arr2[i].split("="));
					obj[(arr2[i].split("="))[0]] = (arr2[i].split("="))[1];
				}
			} else if (arrLen1 == 1) {
				obj[arr1[0]] = arr1[1];
			} else {
				// popAlert("The URL did not carry parameters!");
				// return;
			}
			return obj;
		};

        //$http.post('../../JsonServlet',{"action":"initlogin","token":token})
        //$http.get('jsondata/tsconfigwel.json')
        var Url = window.location.href;
		var curObj = getC(Url);
		
		var postCfg = {
			    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			    transformRequest: function (data) {
			        return $.param(data);
			    }
			};
		$(".loading").show();
		if(curObj.token == undefined){
			curObj.token = "a01234567890";
		}
		//hardcode
        $http.post('JsonServlet',{"action":"initlogin","token":curObj.token},postCfg)
		//$http.post('jsondata/tsconfigwel.json',{"action":"initlogin","token":"01234567890"},postCfg)
            .success(function(data){
            	console.log(data);
                //data.app_date = commonService.dateFormat(data.app_date);
				//var curDateTime = data.app_date + " " + data.app_startTime;
                $scope.datas = data;
				$scope.datas.user_name = $scope.datas.user_name.toUpperCase();
				$scope.datas.app_date = dateConvert($scope.datas.app_date);

                //$scope.leave = commonService.countDown(curDateTime).leave;
                //$scope.countdown = commonService.countDown(curDateTime).countdowntime;
                //var myTime = window.setInterval(function() {
                //    $scope.leave --;
                //    $scope.countdown = commonService.countDown(curDateTime).countdowntime;
                //    if($scope.leave <= 0){
                //        clearInterval(myTime);
                //    }
                //    $scope.$digest(); // 通知视图模型的变化$apply和$digest 相似
                //}, 1000);
				$scope.welContent = true;
				$(".loading").hide();
            })
            .error(function(error) {
				$(".loading").hide();
                console.log("an unexpected error ocurred in welcomeController!");
            });

		
		/*var req = {
                method: 'POST',
                url:'JsonServlet',
                headers: {
                  'Content-Type': 'application/json'
                },
                data: {"action":"initlogin","token":curObj.token}
               };
		
       $http(req).success(function(data){
    	   data.app_date = commonService.dateFormat(data.app_date);
           $scope.datas = data;
           $scope.leave = commonService.countDown(data.app_date).leave;
           $scope.countdown = commonService.countDown(data.app_date).countdowntime;
           var myTime = window.setInterval(function() {
               $scope.leave --;
               $scope.countdown = commonService.countDown(data.app_date).countdowntime;
               if($scope.leave <= 0){
                   clearInterval(myTime);
               }
               $scope.$digest(); // 通知视图模型的变化$apply和$digest 相似
           }, 1000);
       }).error(function(error) {
    	   console.log("an unexpected error ocurred in welcomeController!");
       });*/



		$scope.isvalid = function(param){
			if(param != "1234" || param == "") {
				commonService.standardPopup(1,"Please enter the correct One time password!");
				return;
			}else{
				//$("#sub").submit();
				var userName = $scope.datas.user_name;
				var partCode = $scope.partCode;
				//防止浏览器对新弹出的window窗口进行拦截 To prevent the browser from the new pop-up window to intercept
				var URL = "index2.html?video_name=Temasys&token="+curObj.token+"&user="+userName+"&initPage=0&role=customer";
				var newWin = window.open("","newwindow","top=100,left=100,width=1024,height=800,resizable=yes,menubar=no,scrollbars=no,toolbar=no,status=yes");
				$.ajax({
					type:"post",
					url:"JsonServlet",
					dataType:"TEXT",
					data:{"action":"login","partCode":partCode},
					success:function(data){
						if(data == ""){
							console.log(URL);
							//window.open(URL,"newwindow","top=100,left=100,width=1024,height=768,resizable=yes,menubar=no,scrollbars=no,toolbar=no,status=yes");
							newWin.location.href = URL;
						}

					},
					error:function(error){
						console.log("Error:ERROR");
					}
				});
			}
		};
		$scope.keyDown = function(event){
			var param = event.currentTarget.value;
			var keycode = window.event?event.keyCode:event.which;
			if(keycode==13){
				$scope.isvalid(param);
			}
		};
	})
});
