'use strict';

define([], function() {
	function _controller($scope, $http, $location, $rootScope,$routeParams,commonService) {
		console.log('meetingFormCtrl is called!');

		var wH = $(window).height();
		$(".bookAmeeting").css({"height":wH});
		$scope.selectedDate = new Date();
		var meeting = $rootScope.paramObj;
		//console.log(meeting);
		var myDate = new Date(),
			curDay = myDate.getDate(),
			curMon = myDate.getMonth() + 1,
			curYear = myDate.getFullYear(),
			curHH = myDate.getHours(),
			curMM = myDate.getMinutes();
		if(curMon < 10){
			curMon = "0" + curMon;
		}
		if(curDay < 10){
			curDay = "0" + curDay;
		}

		//var curDate = curDay+'/'+curMon+'/'+curYear;
		var curStartTime = "",curEndTime="";

		if(meeting.token == undefined){
			//init meeting information
			curStartTime = new Date(curYear,curMon,curDay,curHH,curMM,"00");
			curEndTime = curStartTime.getTime() + 2 * 60 * 60 * 1000;
			curEndTime = new Date(curEndTime);

			meeting.token = "";
			meeting.app_date = myDate;
			meeting.app_startTime = curStartTime;
			meeting.app_endTime = curEndTime;
			meeting.user_name = "";
			meeting.user_email = "";
			meeting.user_mobile = "";
			meeting.subject = "";
			meeting.remark = "";

		}else{
			console.log(meeting);
			var tempDate = meeting.app_date.split("/");
			var tempStartTime = meeting.app_startTime.split(":"),
			tempEndTime = meeting.app_endTime.split(":");
			console.log(tempDate);
			curStartTime = new Date(tempDate[2],tempDate[0]-1,tempDate[1],tempStartTime[0],tempStartTime[1]),

			curEndTime = new Date(tempDate[2],tempDate[0]-1,tempDate[1],tempEndTime[0],tempEndTime[1]);
			meeting.app_startTime = curStartTime;
			meeting.app_endTime = curEndTime;
			meeting.app_date = new Date(tempDate[2],tempDate[1]-1,tempDate[0],tempStartTime[0],tempStartTime[1]);
		}
		$scope.meeting = meeting;
		console.log($scope.meeting.app_date);

		$scope.bookMeeting = function($event) {
//			if($scope.meetingForm.$invalid){
//				commonService.standardPopup(1,"Please fill in all the items, thanks!");
//				return;
//			}

			console.log("book meeting");
			
			var url = $rootScope.rootObj.mrmServerURL+"/requestMeetingRoom";

			//param.token = "0123456789";
			var param = {};
			param = $.extend(param,$scope.meeting);
			console.log(param);
			//if(param.app_date.indexOf('/') > 0){
			//	param.app_date = commonService.dateFormat(param.app_date);
			//}
			//param.app_date = commonService.dateFormat(param.app_date);
			param.app_date = $("#config-demo").val();
			param.app_startTime = $("#b_start").val();
			param.app_endTime = $("#b_end").val();
			console.log(param);

			
			//$(".loading").show();
			$.ajax({
				type : "post",
				url : url,
				dataType : "text",
				data : param,
				timeout : 15 * 1000,
				success : function(data) {
					console.log("create meeting success");
					
					$location.path('/list');
					$scope.$apply();
					//$(".loading").hide();
				},
				error : function(data) {
					console.log("network is error");
					//$(".loading").hide();
					commonService.standardPopup(1,"Network is disconnect");
				}
			});		
		
		}
		// bind the close button fun to retun list page
		$scope.closeMeeting = function() {
			console.log("close meeting");
			$location.path('/list');
		}


		//
		//if(meeting.remark != ""){
		//	$("#b_remark").css({"color":"#554344"});
		//}
		//$scope.textareaFocus = function(){
		//	if(meeting.remark == "Please type in"){
		//		meeting.remark = "";
		//		$("#b_remark").css({"color":"#554344"});
		//	};
		//}
		//$scope.textareaBlur = function(){
		//	if(meeting.remark == ""){
		//		meeting.remark = "Please type in";
		//		$("#b_remark").css({"color":"#b3b1a8"});
		//	}else if(meeting.remark != "Please type in"){
		//		$("#b_remark").css({"color":"#554344"});
		//	};
		//}

	}

	return _controller;
});
