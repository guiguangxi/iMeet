'use strict';

define([], function () {
    function _controller($scope, $http, $rootScope, $location, IMeetSocketService, IMeetLoadDataService) {
    	console.log('quotationsCtrl is called!');

        //$rootScope.quoplusmorestatus = false;

        //execute sync function
        function pushPage(data){
            var id = data.elementID;
             IMeetLoadDataService.loadData("insured",{}).then(function(result){
               if(result){
                 changeView(id);
               }
           });
        }

        //when click item,change detail view
        function changeView(param) {

            //change view
            $location.path('/insured');

            $rootScope.quoplusmorestatus1 = false;
            $rootScope.quoplusmorecontstatus1 = false;
            $rootScope.quoliststatus1 = false;
            $rootScope.quobtnstatus1 = false;
            $rootScope.quomaskstatus1 = false;

            $rootScope.quoplusmorestatus = true;
            $rootScope.quoplusmorecontstatus = true;
            $rootScope.quoliststatus = false;
            $rootScope.quobtnstatus = true;
            $rootScope.quomaskstatus = false;
        }

        //add listener when on message from socket
        $scope.listener = function(data){
           if(data.action == 'pushPage'){
               pushPage(data);
           }else if(data.action == 'addStyle_checked'){
               addStyle_checked(data);
           }
        };

        //list click function
        $scope.getInsured = function(param){
          param = param.currentTarget;
            //解决daterangepicker插件在每次进入Insured页面时被调用造成累加
            if($(".daterangepicker")){
                console.log("Remove daterangepicker");
                $(".daterangepicker").remove();
            }
            $rootScope.protect_guarnteed_plus = angular.element("#" +param.id).find("protect_guarnteed_plus").html();
          IMeetLoadDataService.loadData("insured",{}).then(function(result){
             if(result){
               changeView(param.id);
               var data = IMeetSocketService.createData('agent',param.id,"", "pushPage","onclick");
               IMeetSocketService.sendRequest(data);
             }
          });
        };
        //click checkbox add css style
        $scope.add_checked = function(event){
            var id = event.currentTarget.id;
            var item = angular.element("#"+id).find(".checkbox");
            if(item.hasClass("com_list_checked")){
                item.removeClass("com_list_checked");
            }else{
                item.addClass("com_list_checked");
            }
            var data = IMeetSocketService.createData('agent',id,"", "addStyle_checked","onclick");
            IMeetSocketService.sendRequest(data);
        };
        function addStyle_checked(data){
            var id = data.elementID;
            var item = angular.element("#"+id).find(".checkbox");
            if(item.hasClass("com_list_checked")){
                item.removeClass("com_list_checked");
            }else{
                item.addClass("com_list_checked");
            }
        }


    }

    return _controller;
});
