'use strict';

// var _socketService;

define([], function () {
    // _socketService = socketService;
    function _controller($scope, $http, $location, $rootScope, IMeetSocketService,$dateParser, $dateFormatter,dataService, commonService) {
        console.log('insuredCtrl is called!');
        console.log($scope);

        //define variable
        $scope.insured = {};        //get json data of insured

        $scope.planConfig = {};     //get json data of planConfig

        $scope.dictionary = {};     //get json data of dictionary

        $scope.products = {};       //get json data of products

        $scope.planlist = [];
        $scope.planlist[0] = {
            "rider_name": "",
            "coverage": "",
            "style_premium": ""
        };

        $scope.totalPremiun = {};   //get json data of totalPremiun

        $scope.syncPremiumData = {}; // sync application quotation data

        $rootScope.objProductData = {}; // store data for when customer after Calculate premium and leave this page

        $rootScope.objProductData.insured = {};
        $rootScope.objProductData.plan = {};
        $rootScope.objProductData.totalPremiun = {};
        $rootScope.objProductData.dictionary = {};
        $rootScope.objProductData.totalPremiun = {};
        $rootScope.objProductData.planlist = {};
        $rootScope.objProductData.pic_icon = {};
        $rootScope.objProductData.products = {};

        var bizQuotationObj;        //all json data

        var curDate;                //get current date;

        $scope.questionDatastored = {} ;     //save data for back to insured,the data is the original data
        //date Format Flag
        $scope.DOBFormatFlag = false;
        //define end


        //UI function start
        //add listener when on message from socket
        $scope.listener = function (data) {

            if (data.action == 'calcPremium') {
                calcPremium(data);
            }else if (data.action == 'radioClassChange') {
                radioClassChange(data.elementID);
            } else if (data.action == 'InsuredInputChangeValue') {
                InsuredInputChangeValue(data);
            } else if (data.action == 'cacularAge') {
                cacularAge(data);
            } else if (data.action == 'add_additional') {
                add_additional(data);
            } else if (data.action == 'premmiumChangeValue') {
                premmiumChangeValue(data);
            } else if (data.action == 'premmiumChangeValue1') {
                premmiumChangeValue1(data);
            } else if(data.action == 'basicPremmiumChangeValue'){
                basicPremmiumChangeValue(data);
            }else if (data.action == 'syncFocusEditing') {
                syncFocusEditing(data);
            } else if (data.action == 'showSelect') {
                showSelect(data);
            } else if (data.action == 'hideSelect') {
                hideSelect(data);
            } else if(data.action == 'nullHideSelect'){
                nullHideSelect(data);
            }else if (data.action == 'setSelectedItem') {
                setSelectedItem(data);
            } else if (data.action == 'syncStrap_button') {
                syncStrap_button(data);
            }else if(data.action == 'anlayzPremium'){
                $scope.anlayzPremium(JSON.parse(data.result));
            }else if(data.action == 'syncPremiumVal'){
                syncPremiumVal(data.result);
            } else if(data.action == 'showDatepicker'){
                showDatepicker(data);
            } else if (data.action == 'setSelectPane'){
                setSelectPane(data);
            } else if(data.action == 'setToggleMode'){
                setToggleMode(data);
            } else if(data.action == 'setSelectedDate'){
                setSelectedDate(data);
            } else if(data.action == 'closePopFun'){
                closePopFun(data);
            }
        };

        //input text on blur
        $scope.InsuredInputBlur = function (event, value) {
            var id = event.currentTarget.id;
            var value = event.currentTarget.value;
            var data = IMeetSocketService.createData('agent', id, value, 'InsuredInputChangeValue', 'input');
            IMeetSocketService.sendRequest(data);
            if(id == "idob"){
                IsDate(value)
            }
            cacularAge(data);
        };

        //input text focus and editing ,the others know
        $scope.focusEditing = function (event) {
            var id = event.currentTarget.id;

            if(id == "sa"){
                var saStr;
                if ($scope.planConfig.sa != undefined && $scope.planConfig.sa.length > 0) {
                    //如传入"1,000"或"12,000.56" 则输出"1000"和"12000.56"
                    saStr =commonService.amountToNumFormat($scope.planConfig.sa);
                }
                var _id = id;
                $scope.planConfig.sa = saStr;
                var data = IMeetSocketService.createData('agent', _id, "", "syncFocusEditing", "focus");
                IMeetSocketService.sendRequest(data);
            }else if(id == "basicPremium"){
                var basicStr;
                if ($scope.insured.basicPremium != undefined && $scope.insured.basicPremium.length > 0) {
                    //如传入"1,000"或"12,000.56" 则输出"1000"和"12000.56"
                    basicStr =commonService.amountToNumFormat($scope.insured.basicPremium);
                }
                var _id = id;
                $scope.insured.basicPremium = basicStr;
                var data = IMeetSocketService.createData('agent', _id, "", "syncFocusEditing", "focus");
                IMeetSocketService.sendRequest(data);
            }


            var data = IMeetSocketService.createData('agent', id, "", "syncFocusEditing", "focus");
            IMeetSocketService.sendRequest(data);
        };

        //angular-strap div onkey blur
        $scope.strap_button = function (event) {
            var id = event.currentTarget.id;
            var data = IMeetSocketService.createData('agent', id, "", 'syncStrap_button', 'input');
            IMeetSocketService.sendRequest(data);

        };

        //input radio
        $scope.radioSelect = function (param) {
            param = param.currentTarget;
            var id = param.id;
            if(id == 'quoinsured_male' || id == 'quoinsured_famale'){
                $scope.insured.isex = id;
            }else if(id == 'quoinsured_smoker' || id == 'quoinsured_nosmoker'){
                $scope.insured.ismoker = id;
            }
            radioClassChange(id);
            var data = IMeetSocketService.createData('agent', id, "", "radioClassChange", "onclick");
            IMeetSocketService.sendRequest(data);

        };

        //sa premium on change and clear the value of Basic premium
        $scope.insuredSaChange = function (eventId) {
            $scope.insured.basicPremium = "";
            $scope.totalPremiun.totalSum = "0.00";
        };

        //sa premium on transfor format
        $scope.premmiumFormatBlur = function (event) {
            var saStr;
            if ($scope.planConfig.sa != undefined && $scope.planConfig.sa.length > 0) {
                //如传入"1000"或"10000"或"12000.88"等，则返回"1.000""10,000""12,000.88"
                saStr = commonService.numToAmountFormat($scope.planConfig.sa);
            }
            var id = event.currentTarget.id;
            $scope.planConfig.sa = saStr;

            //sync application quotation data value
            $scope.syncPremiumData.coverageAmountVal = $scope.planConfig.sa;

            var value = saStr;

            var editingElement = angular.element("#" + id);
            editingElement.removeClass("insuredFocus");
            var data = IMeetSocketService.createData('agent', id, value, 'premmiumChangeValue', 'input');
            IMeetSocketService.sendRequest(data);
        };
        //insured.basicPremium on transfor format
        $scope.basicPremiumFormatBlur = function (event) {
            var basicStr;
            if ($scope.insured.basicPremium != undefined && $scope.insured.basicPremium.length > 0) {
                //如传入"1000"或"10000"或"12000.88"等，则返回"1.000""10,000""12,000.88"
                basicStr = commonService.numToAmountFormat($scope.insured.basicPremium);
            }
            var id = event.currentTarget.id;
            $scope.insured.basicPremium = basicStr;

            var value = basicStr;

            var editingElement = angular.element("#" + id);
            editingElement.removeClass("insuredFocus");
            caltotalPremium(id);
            var data = IMeetSocketService.createData('agent', id, value, 'basicPremmiumChangeValue', 'input');
            IMeetSocketService.sendRequest(data);
        };

        //calculate basic premium
        $scope.btnCalculate = function () {
            //if device is ipad caculate,else ignore it
            var _data;
            //timer wait 500ms
            setTimeout(function () {

                if ((/iphone|ipad/gi).test(navigator.appVersion)) {
                    var data = genertePlandata('calcPremium');
                    data.data.plan.sa = commonService.amountToNumFormat(data.data.plan.sa);
                    _data = data.data.plan.sa;
                    var jsonStr = angular.toJson(data);
                    window.location.href = 'ios:///' + jsonStr;
                    $scope.planConfig.sa = commonService.numToAmountFormat(_data);

                }else {
                    var data = genertePlandata('calcPremium');
                    $scope.planConfig.sa = data.data.plan.sa;

                    storeDate();
                    var data = IMeetSocketService.createData('agent', "sa", $scope.planConfig.sa, "calcPremium", "input");
                    IMeetSocketService.sendRequest(data);
                }
            }, 500);

        };

        //click add additional page
        $scope.additional = function (param) {
            param = param.currentTarget;
            changeView(param.id);
            var data = IMeetSocketService.createData('agent', param.id, "", "add_additional", "onclick");
            IMeetSocketService.sendRequest(data);
        };

        //next input focus
        $scope.focusNextInput = function (event) {
            var param = event.currentTarget;
            if (event.keyCode == 13) {
                var inputs = angular.element(".onkey");
                for (var i = 0; i < inputs.length; i++) {
                    //var dropDown = angular.element("#" + inputs[i + 1].id);
                    // 如果是最后一个，则焦点回到第一个
                    if (i == (inputs.length - 1)) {
                        inputs[0].focus();
                        break;
                    } else if (param == inputs[i]) {
                        if (inputs[i + 1].type == "radio") {
                            var eventId = inputs[i + 1].parentElement.id;
                            radioClassChange(eventId);
                            var data = IMeetSocketService.createData('agent', eventId, "", "radioClassChange", "onclick");
                            IMeetSocketService.sendRequest(data);

                        }
                        inputs[i + 1].focus();
                        break;
                    }
                }
            }
        };

        $scope.willShow = function (obj) {
            var data = IMeetSocketService.createData('agent', obj.$id, "", "showSelect", "onclick");
            IMeetSocketService.sendRequest(data);
        };

        $scope.selectedItem = function (value, index, obj) {
            var data = IMeetSocketService.createData('agent', obj.$id, value, "setSelectedItem", "onclick");
            IMeetSocketService.sendRequest(data);
        };

        $scope.hidden = function (obj) {
            if(obj.$id == 'insuredIdob') {
                obj.setMode(2);
                if ($scope.insured.insuredIdob == undefined ||$scope.insured.insuredIdob == ""){
                    var data = IMeetSocketService.createData('agent', obj.$id, "", "nullHideSelect", "onclick");
                    IMeetSocketService.sendRequest(data);
                }else{
                    $scope.insured.idob = $dateFormatter.formatDate($scope.insured.insuredIdob,'dd/MM/yyyy');
                    var data = IMeetSocketService.createData('agent', obj.$id, $scope.insured.idob, "hideSelect", "onclick");
                    IMeetSocketService.sendRequest(data);
                    cacularAge(data);
                    $scope.DOBFormatFlag = false;
                }

            }else{
                var data = IMeetSocketService.createData('agent', obj.$id, $scope.insured.idob, "hideSelect", "onclick");
                IMeetSocketService.sendRequest(data);
            }


        };

        // click icon left or right
        $scope.selectPane = function(obj,value){
            var data = IMeetSocketService.createData('agent', obj.$id, value, "setSelectPane", "onclick");
            IMeetSocketService.sendRequest(data);

        };

        //transfor DD / MM / YY
        $scope.toggleMode = function(obj){
            var data = IMeetSocketService.createData('agent', obj.$id, "", "setToggleMode", "onclick");
            IMeetSocketService.sendRequest(data);

        };

        //select date
        $scope.selectedYM = function(obj,date){
            //date transfor to string
            console.log(date);
            //var dateFormat = new Date(date);
            //var stringDate = dateFormat.getDate() + '/' + (dateFormat.getMonth() + 1) + '/' + dateFormat.getFullYear();//+ ' ' + dateFormat.getHours() + ':' + dateFormat.getMinutes() + ':' + dateFormat.getSeconds()
            var stringDate = $dateFormatter.formatDate(date,'dd/MM/yyyy');
            var data = IMeetSocketService.createData('agent', obj.$id, stringDate, "setSelectedDate", "onclick");
            IMeetSocketService.sendRequest(data);
        };
        //UI function end


        //private function start
        //var datapicker;

        function uiInit() {
        }

        function init() {
            var dataFlag = dataService.objProductData;
            console.log(dataFlag);
            if(dataFlag == undefined || JSON.stringify(dataFlag) == "{}" )
            {
                bizQuotationObj = dataService.insured;
                $scope.selectedDate = new Date();
                $scope.insured.idob = $dateFormatter.formatDate($scope.selectedDate,'dd/MM/yyyy');

            }else{
                bizQuotationObj = dataService.objProductData;
                $scope.insured.idob = $dateFormatter.formatDate(bizQuotationObj.insured.idob,'dd/MM/yyyy');

                radioClassChange(bizQuotationObj.insured.ismoker);
                radioClassChange(bizQuotationObj.insured.isex);
            }


            $scope.items = bizQuotationObj;

            $scope.insured.iname1 = bizQuotationObj.insured.iname1;
            $scope.insured.iname2 = bizQuotationObj.insured.iname2;
            $scope.insured.iname3 = bizQuotationObj.insured.iname3;
            $scope.insured.isex = bizQuotationObj.insured.isex;
            $scope.insured.ismoker = bizQuotationObj.insured.ismoker;
            $scope.insured.ioccupation = bizQuotationObj.insured.ioccupation;
            $scope.insured.iage = bizQuotationObj.insured.iage;
            $scope.insured.basicPremium = bizQuotationObj.insured.basicPremium;

            $scope.planConfig.sa = bizQuotationObj.plan.sa;
            $scope.planConfig.currency = bizQuotationObj.plan.currency;
            $scope.planConfig.paymentMode = bizQuotationObj.plan.paymentMode;
            $scope.planConfig.premmiumTerm = bizQuotationObj.plan.premmiumTerm;

            $scope.dictionary.currency = bizQuotationObj.dictionary.currency;
            $scope.dictionary.paymentMode = bizQuotationObj.dictionary.paymentMode;
            $scope.dictionary.premmiumTerm = bizQuotationObj.dictionary.premmiumTerm;

            $scope.products = bizQuotationObj.planlist;
            $scope.totalPremiun.totalSum = bizQuotationObj.totalPremiun.totalSum

            $scope.syncPremiumData.coverageAmountVal = $scope.planConfig.sa;
            $scope.syncPremiumData.annualPremiumVal = $scope.insured.basicPremium;
            $scope.syncPremiumData.totalSumVal = $scope.totalPremiun.totalSum;

            $scope.insured.action = "pdf";

            // <- [object Date]
            console.warn( $scope.insured.idob);
        }

        //sync input value of changed
        function InsuredInputChangeValue(data) {
            var id = data.elementID;
            $scope.insured[data.elementID] = data.result;
            $scope.planConfig[data.elementID] = data.result;
            if( id == "idob"){
                IsDate(data.result);
            }
            cacularAge(data);

            var editingElement = angular.element("#" + id);
            editingElement.removeClass("insuredFocus");
        }
        function syncStrap_button(data){
            var id = data.elementID;

            var editingElement = angular.element("#" + id);
            editingElement.removeClass("insuredFocus");
        }

        //input idob chenged calculate age
        function cacularAge(data) {
            if($scope.DOBFormatFlag){
                $scope.insured.iage = 0;
            }else {
                var newDate_year = new Date(),
                    newYear = newDate_year.getFullYear();
                var dateParser = $dateParser();
                var oldYear = dateParser.parse($scope.insured.idob,null,'dd/MM/yyyy');
                var myYear = new Date(oldYear),
                    myAge = myYear.getFullYear();
                var myNewAge = newYear - myAge;
                $scope.insured.iage = myNewAge;
            }
            var id = data.elementID;
            var editingElement = angular.element("#" + id);
            editingElement.removeClass("insuredFocus");
        }

        //input type of radio change
        function radioClassChange(id) {
            if(id == 'quoinsured_male' || id == 'quoinsured_famale'){
                $scope.insured.isex = id;
            }else if(id == 'quoinsured_smoker' || id == 'quoinsured_nosmoker'){
                $scope.insured.ismoker = id;
            }
            angular.element("#" + id).parent().find("a").removeClass("quoinsured_a_selected");
            angular.element("#" + id).parent().find("span").removeClass("quoinsured_selected");
            angular.element("#" + id).addClass("quoinsured_a_selected");
            angular.element("#" + id).find("span").addClass("quoinsured_selected");
        }

        //sync premium value
        function premmiumChangeValue(data) {
            var id = data.elementID;

            if ($scope.planConfig[data.elementID] != data.result) {
                $scope.insured.basicPremium = "";
                $scope.totalPremiun.totalSum = "0.00";
            }

            $scope.planConfig[data.elementID] = data.result;

            //sync application quotation data value
            $scope.syncPremiumData.coverageAmountVal = $scope.planConfig.sa;
            var editingElement = angular.element("#" + id);
            editingElement.removeClass("insuredFocus");


        }
        //basicPremmiumChangeValue
        function basicPremmiumChangeValue(data) {
            var id = data.elementID;

            if ($scope.insured[data.elementID] != data.result) {
                $scope.totalPremiun.totalSum = "0.00";
            }

            $scope.insured[data.elementID] = data.result;

            //sync application quotation data value
            var editingElement = angular.element("#" + id);
            editingElement.removeClass("insuredFocus");
            caltotalPremium(id);

        }
        // init data
        function genertePlandata(type) {
            var result = {
                method: type,
                data: {
                    plan: $scope.planConfig,
                    insured: $scope.insured,
                    owner: $scope.insured
                },
                status: "",
                error: ""
            };
            return result;
        }

        function calcPremium(value) {
            $scope.planConfig[value.elementID] = value.result;

            //if device is ipad caculate,else ignore it
            if ((/iphone|ipad/gi).test(navigator.appVersion)) {
                var data = genertePlandata('calcPremium');
                data.data.plan.sa = commonService.amountToNumFormat(data.data.plan.sa);
                var jsonStr = JSON.stringify(data);
                window.location.href = 'ios:///' + jsonStr;
                $scope.planConfig.sa = commonService.numToAmountFormat(data.data.plan.sa);
            }
            storeDate();
        }

        //calculate summary total premium function
        function caltotalPremium(eventId) {
            if($scope.insured.basicPremium == undefined){
                $scope.totalPremiun.totalSum = "0.00";

            }else{
                var products_Sum = $scope.insured.basicPremium;
                var rider_sum = $scope.products[0].style_premium;
                var i,tatalStr;
                if ($scope.products) {
                    for (i = 0; i < $scope.products.length; i++) {
                        var premiumList = $scope.products[i].style_premium;
                        if (premiumList == "") {
                            rider_sum = 0;
                        } else {
                            rider_sum += commonService.amountToNumFormat(rider_sum);//.toFixed(2);
                        }

                    }
                }
                if (products_Sum == "") {
                    products_Sum = 0;
                } else {
                    products_Sum = commonService.amountToNumFormat($scope.insured.basicPremium);//.toFixed(2);
                }
                var totalSum = Number(products_Sum) + Number(rider_sum);
                $scope.totalPremiun.totalSum = totalSum.toFixed(2);
                //total permium translate format
                var sum = $scope.totalPremiun.totalSum.toString();
                var tatalStr = commonService.numToAmountFormat(sum);
                if (tatalStr == "0" || tatalStr == "") {
                    $scope.totalPremiun.totalSum = "0.00";
                } else {
                    $scope.totalPremiun.totalSum = tatalStr;
                }

                //sync application quotation data value
                $scope.syncPremiumData.totalSumVal = $scope.totalPremiun.totalSum;
                //storeDate();
            }

        }

        //sync total premium value
        function premmiumChangeValue1(data) {
            if (data.result == "0") {
                $scope.totalPremiun.totalSum = "0.00";
            } else {
                $scope.totalPremiun.totalSum = data.result;
            }
        }

        //sync editing
        function syncFocusEditing(data) {
            var id = data.elementID;
            var editingElement = angular.element("#" + id);
            editingElement.addClass("insuredFocus");
        }


        //changeView
        function add_additional(data) {
            var id = data.elementID;
            changeView(id);
        }

        function changeView(param) {

            $location.path(param);

            // to do call a common function
            $rootScope.quoplusmorestatus = false;
            $rootScope.quoplusmorecontstatus = false;
            $rootScope.quoliststatus = false;
            $rootScope.quobtnstatus = false;
            $rootScope.quomaskstatus = false;

            $rootScope.quoplusmorestatus1 = false;
            $rootScope.quoplusmorecontstatus1 = false;
            $rootScope.quoliststatus1 = false;
            $rootScope.quobtnstatus1 = false;
            $rootScope.quomaskstatus1 = false;

            $rootScope.quoplusmorestatus2 = false;
            $rootScope.quoplusmorecontstatus2 = false;
            $rootScope.quoliststatus2 = false;
            $rootScope.quobtnstatus2 = false;
            $rootScope.quomaskstatus2 = false;

            $rootScope.quoplusmorestatus3 = true;
            $rootScope.quoplusmorecontstatus3 = true;
            $rootScope.quoliststatus3 = false;
            $rootScope.quobtnstatus3 = true;
            $rootScope.quomaskstatus3 = false;
        }

        function showSelect(data){
            if(data.elementID == "insuredIdob"){
                var $scopeSelect = angular.element("#"+data.elementID).scope().$$childHead;
            }else if(data.elementID == "currency"){
                var $scopeSelect = angular.element("#"+data.elementID).scope().$$childHead.$$nextSibling;
            }else if(data.elementID == "premmiumTerm"){
                var $scopeSelect = angular.element("#"+data.elementID).scope().$$childHead.$$nextSibling.$$nextSibling;
            }else if(data.elementID == "paymentMode"){
                var $scopeSelect = angular.element("#"+data.elementID).scope().$$childHead.$$nextSibling.$$nextSibling.$$nextSibling;
            }
            //
            $scopeSelect.$triggerEvt('sync');
            $scopeSelect.$show();
            if(data.elementID == "insuredIdob"){
                $("#insuredIdob").focus();
            }
            //var editingElement = angular.element("#" + data.elementID);
            //editingElement.addClass("insuredFocus");
        }

        function hideSelect(data){

            if(data.elementID == "insuredIdob"){
                var $scopeSelect = angular.element("#"+data.elementID).scope().$$childHead;
                $scope.insured.idob = data.result;
                cacularAge(data);
            }else if(data.elementID == "currency"){
                var $scopeSelect = angular.element("#"+data.elementID).scope().$$childHead.$$nextSibling;
            }else if(data.elementID == "premmiumTerm"){
                var $scopeSelect = angular.element("#"+data.elementID).scope().$$childHead.$$nextSibling.$$nextSibling;
            }else if(data.elementID == "paymentMode"){
                var $scopeSelect = angular.element("#"+data.elementID).scope().$$childHead.$$nextSibling.$$nextSibling.$$nextSibling;
            }
            //

            $scopeSelect.$triggerEvt('sync');
            $scopeSelect.$hide();

            if(data.elementID == "insuredIdob"){
                $("#insuredIdob").blur();
            }


            //var editingElement = angular.element("#" + data.elementID);
            //editingElement.removeClass("insuredFocus");
        }
        function nullHideSelect(data){
            var $scopeSelect = angular.element("#"+data.elementID).scope().$$childHead;
            $scopeSelect.$setMode(2);
            $scopeSelect.$triggerEvt('sync');
            $scopeSelect.$hide();
            $("#insuredIdob").blur();
            var editingElement = angular.element("#" + data.elementID);
            editingElement.removeClass("insuredFocus");
        }

        function setSelectedItem(data){
            if(data.elementID == "currency"){
                var $scopeSelect = angular.element("#"+data.elementID).scope().$$childHead.$$nextSibling;
            }else if(data.elementID == "premmiumTerm"){
                var $scopeSelect = angular.element("#"+data.elementID).scope().$$childHead.$$nextSibling.$$nextSibling;
            }else if(data.elementID == "paymentMode"){
                var $scopeSelect = angular.element("#"+data.elementID).scope().$$childHead.$$nextSibling.$$nextSibling.$$nextSibling;
            }
            //
            $scope.planConfig[data.elementID] = data.result;
            //
            var editingElement = angular.element("#" + data.elementID);
            editingElement.removeClass("insuredFocus");

        };
        $scope.anlayzPremium = function(Obj){//analyse
            if(Obj.status == "1"){
                var val = commonService.numToAmountFormat(Obj.data.premium);
                $scope.insured["basicPremium"] = val;

                //sync application quotation data value
                $scope.syncPremiumData.annualPremiumVal = val;
                $scope.insured.basicPremium = val;

                var data = IMeetSocketService.createData('agent', "basicPremium", val, "syncPremiumVal", "click");
                IMeetSocketService.sendRequest(data);

                caltotalPremium('totalPremiun');
                storeDate();
            }else{
                commonService.standardPopup(1,Obj.error.errorMsg,callbackClosePop);
                console.log(Obj.error.errorMsg);
            }

        };
        $scope.sendPremiumResult = function(Obj){
            //$scope.insured["basicPremium"] = commonService.numToAmountFormat(Obj.data.premium);
            var _obj = JSON.stringify(Obj);
            //var _val = commonService.numToAmountFormat(Obj.data.premium);
            var data = IMeetSocketService.createData('agent', "basicPremium", _obj, "anlayzPremium", "click");
            IMeetSocketService.sendRequest(data);

        };

        function syncPremiumVal(value){
            $scope.insured["basicPremium"] = value;
            storeDate();
            caltotalPremium('totalPremiun');


        };
        function setSelectPane(data){
            var $scopeselectPane = angular.element("#"+data.elementID).scope().$$childHead;
            //
            var temp = $scopeselectPane.$trigger;
            $scopeselectPane.$triggerEvt('sync');
            $scopeselectPane.$selectPane(data.result);
            $scopeselectPane.$triggerEvt(temp);

        };

        function setToggleMode(data){
            var $scopeselectPane = angular.element("#"+data.elementID).scope().$$childHead;
            //
            var temp = $scopeselectPane.$trigger;
            $scopeselectPane.$triggerEvt('sync');
            $scopeselectPane.$toggleMode();
            $scopeselectPane.$triggerEvt(temp);
        };

        function setSelectedDate(data){
            var $scopeselectPane = angular.element("#"+data.elementID).scope().$$childHead;
            //string transfor to date
            var str = data.result;
            var dateParser = $dateParser();
            var date = dateParser.parse(str,null,'dd/MM/yyyy');
            //
            var temp = $scopeselectPane.$trigger;
            $scopeselectPane.$triggerEvt('sync');
            if($scopeselectPane.$mode == '0'){
                var keep =  true;
            }
            $scopeselectPane.$selectKeep(date,keep);

            $scopeselectPane.$triggerEvt(temp);

        };
        //private function end

        //Pop btn sync
        function callbackClosePop(type){
            if(type == 1){
                var id = "insured_popID";
                var data = IMeetSocketService.createData('agent',id,"","closePopFun","onclick");
                IMeetSocketService.sendRequest(data);
            }
        }
        function closePopFun(data){
            //var id = data.elementID;
            $("#pop").hide();
        }
        function storeDate(){
            //store data of quotations insured
            $rootScope.objProductData.insured = $scope.insured;
            $rootScope.objProductData.plan = $scope.planConfig;
            $rootScope.objProductData.dictionary = $scope.dictionary;
            $rootScope.objProductData.totalPremiun = $scope.totalPremiun;
            $rootScope.objProductData.planlist = $scope.planlist;
            $rootScope.objProductData.pic_icon.s_pic = "img/images/Vector-Smart-Object1.png";
            $rootScope.objProductData.products.production_name ="AIA Guaranteed Protect Plus";

            dataService.objProductData= $rootScope.objProductData;
        }
        function IsDate(dateval){
            var arr = new Array();

            if(dateval.indexOf("/") != -1){
                arr = dateval.split("/");
            }else{
                $scope.DOBFormatFlag = true;
            }
            //dd-mm-yyyy || dd/mm/yyyy
            if(arr[2].length==4){
                var date = new Date(arr[2],arr[1]-1,arr[0]);
                if(date.getFullYear()==arr[2] && date.getMonth()==arr[1]-1 && date.getDate()==arr[0]){
                    $scope.DOBFormatFlag = false;
                }else{
                    $scope.DOBFormatFlag = true;
                }
            }else{
                $scope.DOBFormatFlag = true;
            }
        }



        //main logic start
        uiInit();

        init();
        //main logic end

    }

    return _controller;

});


//caculatePremium call back
function callBack(data) {
    try {
        var Obj = JSON.parse(data);
        var scope = angular.element("#basicPremium").scope();

        scope.sendPremiumResult(Obj);
        scope.anlayzPremium(Obj);
    } catch(e) {
        console.log(e);
    }

}
