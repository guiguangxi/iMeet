/**
 * Created by bsnpbxt on 10/20/2016.
 */
'use strict';

define([], function () {
    function _controller($scope, $http, $rootScope, $location, IMeetSocketService, IMeetLoadDataService) {
        console.log('applyCtrl is called!');

        //$rootScope.quoplusmorestatus = false;

        //execute sync function
        function pushPage(data){
            var id = data.elementID;
            IMeetLoadDataService.loadData("protectionProducts",{}).then(function(result){
                if(result){
                    changeView(id);
                }
            });
        }

        //when click item,change detail view
        function changeView(param) {
            //change view
            $location.path('/insured');
            $rootScope.quoplusmorestatus = true;
            $rootScope.quobtnstatus = true;
        }

        //add listener when on message from socket
        $scope.listener = function(data){
            if(data.action == 'pushPage'){
                pushPage(data);
            }
        }

        //list click function
        $scope.getInsured = function(param){
            param = param.currentTarget;

            IMeetLoadDataService.loadData("insured",{}).then(function(result){
                if(result){
                    changeView(param.id);
                    var data = IMeetSocketService.createData('agent',param.id,"", "pushPage","onclick");
                    IMeetSocketService.sendRequest(data);
                }
            });
        }
    }

    return _controller;
});
/**
 * Created by bsnpbxt on 10/21/2016.
 */
