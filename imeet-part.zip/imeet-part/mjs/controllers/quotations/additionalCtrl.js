/**
 * Created by bsnpbxt on 10/20/2016.
 */
'use strict';



define([], function () {
    function _controller($scope, $http, $rootScope, $location, IMeetSocketService, IMeetLoadDataService,commonService) {
        console.log('addCtrl is called!');

        init();
        function ResultData(){
            this.method = 'calcRiderPremium';
            this.data;
            this.status;
            this.error;
        }
        function RiderCategory(){
            this.categoryID;
            this.categoryType;
            this.categoryLogo;
            this.categoryName;
            this.riders = [];
        }
        function Rider(){
            this.riderID;
            this.riderName;
            this.riderCoverage;
            this.riderPremium;
            this.selectFlag;
        }
        function init(){
            var lifeRider = new Rider();
            lifeRider.riderID = 'life';
            lifeRider.riderName ="Critical protect life";
            lifeRider.riderCoverage ="";
            lifeRider.riderPremium ="";
            lifeRider.selectFlag = false;

            var riderRider = new Rider();
            riderRider.riderID = "rider";
            riderRider.riderName ="Critical protect rider";
            riderRider.riderCoverage ="";
            riderRider.riderPremium ="";
            riderRider.selectFlag = false;

            var lifeCategory = new RiderCategory();
            lifeCategory.categoryID = "111";
            lifeCategory.categoryType = "life";
            lifeCategory.categoryLogo = "img/images/products/prd_critical_illness_2x.png";
            lifeCategory.categoryName = "CRITICAL ILLNESS";
            lifeCategory.riders.push(lifeRider,riderRider);

            var lifeRider1 = new Rider();
            lifeRider1.riderID = '003';
            lifeRider1.riderName ="Critical protect life";
            lifeRider1.riderCoverage ="";
            lifeRider1.riderPremium ="";
            lifeRider1.selectFlag = false;

            var riderRider1 = new Rider();
            riderRider1.riderID = "004";
            riderRider1.riderName ="Critical protect rider";
            riderRider1.riderCoverage ="";
            riderRider1.riderPremium ="";
            riderRider1.selectFlag = false;

            var termtegory = new RiderCategory();
            termtegory.categoryID = "222";
            termtegory.categoryType = "life";
            termtegory.categoryLogo = "img/images/products/term_2x.png";
            termtegory.categoryName = "TERM";
            termtegory.riders.push(lifeRider1,riderRider1);

            var lifeRider2 = new Rider();
            lifeRider2.riderID = '005';
            lifeRider2.riderName ="Critical protect life";
            lifeRider2.riderCoverage ="";
            lifeRider2.riderPremium ="";
            lifeRider2.selectFlag = false;

            var riderRider2 = new Rider();
            riderRider2.riderID = "006";
            riderRider2.riderName ="Critical protect rider";
            riderRider2.riderCoverage ="";
            riderRider2.riderPremium ="";
            riderRider2.selectFlag = false;

            var payorBenefitCategory = new RiderCategory();
            payorBenefitCategory.categoryID = "333";
            payorBenefitCategory.categoryType = "life";
            payorBenefitCategory.categoryLogo = "img/images/products/prd_disability_2x.png";
            payorBenefitCategory.categoryName = "PAYOR BENEFIT";
            payorBenefitCategory.riders.push(lifeRider2,riderRider2);

            var lifeRider3 = new Rider();
            lifeRider3.riderID = '007';
            lifeRider3.riderName ="Critical protect life";
            lifeRider3.riderCoverage ="";
            lifeRider3.riderPremium ="";
            lifeRider3.selectFlag = false;

            var riderRider3 = new Rider();
            riderRider3.riderID = "008";
            riderRider3.riderName ="Critical protect rider";
            riderRider3.riderCoverage ="";
            riderRider3.riderPremium ="";
            riderRider3.selectFlag = false;
            var premiumWaiverCategory = new RiderCategory();
            premiumWaiverCategory.categoryID = "444";
            premiumWaiverCategory.categoryType = "life";
            premiumWaiverCategory.categoryLogo = "img/images/products/prd_medical_protection_2x.png";
            premiumWaiverCategory.categoryName = "PREMIUM WAIVER";
            premiumWaiverCategory.riders.push(lifeRider3,riderRider3);

            var riders = [lifeCategory,termtegory,payorBenefitCategory,premiumWaiverCategory];

            var riderJson = JSON.stringify(riders);
            $scope.RiderCategorys = JSON.parse(riderJson);

            //store rider list of which is selected
            $scope.selectRider=[];


        }
        function genertePlandata(riderList) {
            if (riderList){
                var result = new ResultData();
                result.method = 'calcRiderPremium';
                result.data = riderList;
                result.status = "";
                result.error = "";
            }

            return result;
        }

        function cal(){
            //rider
            JSON.stringify()

        }
        //execute sync function
        function listShow(data){
            var id = data.elementID;
            IMeetLoadDataService.loadData("addition",{}).then(function(result) {
                if (result) {
                    var showUp = angular.element("#" + id);
                    var showEle = showUp[0].parentNode.parentNode.nextElementSibling;
                    var bottom_plan = angular.element(showEle);
                    if (showUp.hasClass("clicked")) {
                        bottom_plan.hide();
                        showUp.removeClass("clicked");
                    } else {
                        bottom_plan.show();
                        showUp.addClass("clicked");
                    }
                }
            })
        }

        // chnage view
        function pushPage(data){
            changeView();
        }
        //when click item,change detail view
        function changeView(param) {
            //change view
            $location.path('/insured');
            $rootScope.quoplusmorestatus = true;
            $rootScope.quoplusmorecontstatus = true;
            $rootScope.quoliststatus = false;
            $rootScope.quobtnstatus = true;
            $rootScope.quomaskstatus = false;
        }

        function addStyle_checked(data){
            var id = data.elementID;
            var item = angular.element("#"+id);
            if(item.hasClass("com_list_checked")){
                item.removeClass("com_list_checked");
            }else{
                item.addClass("com_list_checked");
            }
        }

        //sync input value of changed
        function InputBlurValue(data) {
            var id = data.elementID;
            //$scope.riderCoverage[data.elementID] = data.result;s
            var editingElement = angular.element("#" + id);
            editingElement.removeClass("insuredFocus");
        }

        //sync editing
        function syncFocusEditing(data) {
            var id = data.elementID;
            //$scope.riderCoverage[id] = commonService.amountToNumFormat($scope.riderCoverage[id]);
            var editingElement = angular.element("#" + id);
            editingElement.addClass("insuredFocus");
        }

        //store data for rider
        function storeDate(){
            $rootScope.objProductData.riderName = $scope.riderName;
            $rootScope.objProductData.coverAmount = $scope.rider;
            $rootScope.objProductData.premium = $scope.premium;
            dataService.objRiderData= $rootScope.objRiderData;
        }

        // calculate rider premium
        function btnPremium(riderList){

            //timer wait 500ms
        //    setTimeout(function () {
        //
        //        if ((/iphone|ipad/gi).test(navigator.appVersion)) {
        //            var result = genertePlandata(riderList);
        //            for(var i = 0;i < riderList.length; i++){
        //                result.data.riders[i].riderCoverage = commonService.amountToNumFormat(data.data.riders[i].riderCoverage);
        //                riderList[i].riderCoverage = commonService.amountToNumFormat(riderList[i].riderCoverage);
        //            }
        //            var jsonStr = JSON.stringify(result);
        //            window.location.href = 'ios:///' + jsonStr;
        //        }else {
        //            var data = IMeetSocketService.createData('agent', riderList[0].riderID,riderList , "calcRiderPremium", "input");
        //            IMeetSocketService.sendRequest(data);
        //        }
        //    }, 500);
        //}


            setTimeout(function () {
                var result = genertePlandata(riderList);
                for(var i = 0;i < riderList.length; i++){
                    result.data.riders[i].riderCoverage = commonService.amountToNumFormat(data.data.riders[i].riderCoverage);
                    riderList[i].riderCoverage = commonService.amountToNumFormat(riderList[i].riderCoverage);
                }
                var jsonStr = JSON.stringify(result);
                window.location.href = 'ios:///' + jsonStr;
            }, 500);
        }

        function calcRiderPremium(riderList) {

            //if device is ipad caculate,else ignore it
            if ((/iphone|ipad/gi).test(navigator.appVersion)) {
                var result = genertePlandata(riderList);
                for(var i = 0;i < riderList.length; i++){
                    result.data.riders[i].riderCoverage = commonService.amountToNumFormat(data.data.riders[i].riderCoverage);
                    riderList[i].riderCoverage = commonService.amountToNumFormat(riderList[i].riderCoverage);
                }
                var jsonStr = JSON.stringify(result);
                window.location.href = 'ios:///' + jsonStr;

            }
        }


        function syncPremiumVal(value){
            //$scope.riderCoverage["earltPremium1"] = value.lifeVal;
            //$scope.riderCoverage.critlcalPremium1 = value.riderVal;


        };

//.....................................add listener when on message from socket............................
        $scope.listener = function(data){
            if(data.action == 'listShow'){
                listShow(data);
            }else if(data.action == 'pushPage'){
                pushPage(data);
            }else if(data.action == 'addStyle_checked'){
                addStyle_checked(data);
            }else if(data.action == 'InputBlurValue'){
                InputBlurValue(data);
            }else if(data.action == 'syncFocusEditing'){
                syncFocusEditing(data);
            }else if(data.action == 'calcRiderPremium'){
                calcRiderPremium(data.result)
            }else if(data.action == 'calcPremium'){
                calcPremium(data);
            }else if(data.action == 'anlayzPremium'){
                $scope.anlayzPremium(JSON.parse(data.result));
            }else if(data.action == 'syncPremiumVal'){
                syncPremiumVal(data.result);
            }else if(data.action == 'closePopFun'){
                closePopFun(data);
            }
        }

        //list click function
        $scope.hide_show = function(event){
            var id = event.currentTarget.id;
            IMeetLoadDataService.loadData("addition",{}).then(function(result){
                if(result){
                    var  showUp = angular.element("#" + id);
                    var showEle = showUp[0].parentNode.parentNode.nextElementSibling;
                    var bottom_plan = angular.element(showEle);
                    if(showUp.hasClass("clicked")){
                        bottom_plan.hide();
                        showUp.removeClass("clicked");
                    }else{
                        bottom_plan.show();
                        showUp.addClass("clicked");

                    }
                    var data = IMeetSocketService.createData('agent',id,"", "listShow","onclick");
                    IMeetSocketService.sendRequest(data);
                }
            });
        };

        //back to quotaions page
        $scope.backToQuos = function(event){
            var id = event.currentTarget.id;
            changeView();
            var data = IMeetSocketService.createData('agent',id,"", "pushPage","onclick");
            IMeetSocketService.sendRequest(data);

        };

        //click checkbox add css style
        $scope.add_checked = function(rider){
            var id = rider.riderID + '_item';
            var item = angular.element("#"+id).find("span");
            var inputDisabled = angular.element("#"+id)[0].parentNode.nextElementSibling.childNodes[1];
            if(item.hasClass("com_list_checked")){
                item.removeClass("com_list_checked");
                inputDisabled.disabled = true;
                rider.selectFlag = false;
                $scope.selectRider.remove(rider);

            }else{
                item.addClass("com_list_checked");
                inputDisabled.disabled = false;
                rider.selectFlag = true;
                $scope.selectRider.push(rider);
            }
            var data = IMeetSocketService.createData('agent',id,"", "addStyle_checked","onclick");
            IMeetSocketService.sendRequest(data);
        };

        //input text on blur
        $scope.InsuredInputBlur = function (rider) {
            var id = rider.riderID;
            if (rider.riderCoverage != undefined && rider.riderCoverage > 0) {
                //如传入"1000"或"10000"或"12000.88"等，则返回"1.000""10,000""12,000.88"
                rider.riderCoverage = commonService.numToAmountFormat(rider.riderCoverage);
            }
            //calculate premium
            btnPremium($scope.selectRider);
            //var data = IMeetSocketService.createData('agent', id, value, 'InputBlurValue', 'input');
            //IMeetSocketService.sendRequest(data);
        };

        //input text focus and editing ,let the others know
        $scope.focusEditing = function (event) {
            var id = event.currentTarget.id;
            //if ($scope.riderCoverage[id] != undefined && $scope.riderCoverage[id] > 0) {
            //    $scope.riderCoverage[id] = commonService.amountToNumFormat($scope.riderCoverage[id]);
            //}
            var data = IMeetSocketService.createData('agent', id, "", "syncFocusEditing", "focus");
            IMeetSocketService.sendRequest(data);
        };

        //next input focus
        $scope.focusNextInput = function (event) {
            var param = event.currentTarget;
            if (event.keyCode == 13) {
                var inputs = angular.element(".onkey");
                for (var i = 0; i < inputs.length; i++) {
                    //var dropDown = angular.element("#" + inputs[i + 1].id);
                    // 如果是最后一个，则焦点回到第一个
                    if (i == (inputs.length - 1)) {
                        inputs[0].focus();
                        break;
                    } else if(param == inputs[i]) {
                        inputs[i + 1].focus();
                        break;
                    }
                }
            }
        };

        $scope.sendPremiumResult = function(Obj){
            var _obj = JSON.stringify(Obj);
            var data = IMeetSocketService.createData('agent', "criticalR", _obj, "anlayzPremium", "click");
            IMeetSocketService.sendRequest(data);

        };

        $scope.anlayzPremium = function(Obj){//analyse
            if(Obj.status == "1"){

                var data = IMeetSocketService.createData('agent', "criticalR", val, "syncPremiumVal", "click");
                IMeetSocketService.sendRequest(data);
            }else{
                commonService.standardPopup(1,Obj.error.errorMsg,callbackClosePop);
                console.log(Obj.error.errorMsg);
            }

        };

        //Pop btn sync
        function callbackClosePop(type){
            if(type == 1){
                var id = "insured_popID";
                var data = IMeetSocketService.createData('agent',id,"","closePopFun","onclick");
                IMeetSocketService.sendRequest(data);
            }
        }
        function closePopFun(data){
            $("#pop").hide();
        }
    }

    return _controller;
});
/**
 * Created by bsnpbxt on 11/8/2016.
 */
//caculatePremium call back
function callBack(data) {
    try {
        var Obj = JSON.parse(data);
        var scope = angular.element("#earltRider").scope();
        scope.sendPremiumResult(Obj);
        scope.anlayzPremium(Obj);
    } catch(e) {
        console.log(e);
    }

}
