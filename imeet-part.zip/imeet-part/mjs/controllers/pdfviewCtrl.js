/**
 * Created by admin on 16/10/19.
 */
'use strict';

define([], function () {
	console.log('pdfviewCtrl is called!');
	
    function _controller($scope, $rootScope, $http, $location, $timeout, pdfDelegate, IMeetSocketService, IMeetWebService, IMeetLoadDataService, dataService, commonService) {
    	
    	
        function init(){
        	console.log('pdfviewCtrl.init();');
        	var pdfPath = $rootScope.pdfUrl;
        	$scope.pdfUrl = pdfPath;
            pdfDelegate.$getByHandle('my-pdf-container').load(pdfPath);

//        	$timeout(function(){
//            	pdfDelegate.$getByHandle('my-pdf-container').load(pdfPath);
//        	},3000);
        };
        
        init();
    }

    return _controller;
});