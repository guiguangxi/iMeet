/**
 * Created by admin on 16/10/19.
 */
'use strict';

define(["app"], function (app) {
    console.log('addlistCtrl is called!');

    app.controller('addlistCtrl', function($q, $scope, $rootScope, $dateFormatter,$location, $window, IMeetSocketService, IMeetLoadDataService, dataService, commonService) {
        //quotation Insured page addlist btn
        //add listener when on message from socket

        $scope.listener = function(data){
            if(data.action == 'showQuoInsuredAddlistFun'){
                showQuoInsuredAddlistFun();
            }else if(data.action == 'hideQuoInsuredAddlistFun'){
                hideQuoInsuredAddlistFun();
            }else if(data.action == 'displayPdfViewer'){
            	displayPdfViewer(data.result);
            }else if(data.action == 'closePdfFun'){
                closePdfFun();
            }else if(data.action == 'pushPage'){
                pushPage(data);
            }
        };

        //click quo_plusBtn show quotation insured addlist
        $scope.showQuoInsuredAddlist = function(param){
            param = param.currentTarget;
            showQuoInsuredAddlistFun();
        }

        function showQuoInsuredAddlistFun(){
            $rootScope.quoplusmorestatus = true;
            $rootScope.quoplusmorecontstatus = true;
            $rootScope.quoliststatus = true;
            $rootScope.quobtnstatus = false;
            $rootScope.quomaskstatus = true;
        }
        //click quo_plusMoreMask hide quotation insured addlist
        $scope.hideQuoInsuredAddlist = function(param){
            param = param.currentTarget;
            hideQuoInsuredAddlistFun();
            var data = IMeetSocketService.createData('agent',param.id,"", "hideQuoInsuredAddlistFun","onclick");
            IMeetSocketService.sendRequest(data);
        }
        function hideQuoInsuredAddlistFun(){
            $rootScope.quoplusmorestatus = true;
            $rootScope.quoplusmorecontstatus = true;
            $rootScope.quoliststatus = false;
            $rootScope.quobtnstatus = true;
            $rootScope.quomaskstatus = false;
        }
        //when click preview ,hide the quoInsuredAddlistBtnfun
        function hideQuoInsuredAddlistBtnFun(){
            $rootScope.quoplusmorestatus = false;
            $rootScope.quoplusmorecontstatus = false;
            $rootScope.quoliststatus = false;
            $rootScope.quobtnstatus = false;
            $rootScope.quomaskstatus = false;
        }
        //preview PDF in quotation page
        $rootScope.preview = function(param){
            //param = param.currentTarget.id;

            var objInsured= dataService.objProductData;
            if(objInsured == undefined || JSON.stringify(objInsured) == "{}"){
                commonService.standardPopup(1,"Please complete the premium calculation!");
                return;
            }else {
                if(objInsured.insured.basicPremium == ""){
                    commonService.standardPopup(1,"Please complete the premium calculation!");
                    return;
                }
            }
            readPdfFilesFun(param);
        };

        function readPdfFilesFun(param){
            //control addlist show or hide

            var curDataInfo = {};
            var dataInsured = dataService.objProductData;
            if(dataInsured == undefined || JSON.stringify(dataInsured) == "{}" ){
                //console.log(dataInsured);
            }else{
                var dataInfo = dataInsured.insured;
                var dataPlan = dataInsured.plan;
                //console.log(dataInfo);

                curDataInfo.name = dataInfo.iname1;
                curDataInfo.action = dataInfo.action;
                //curDataInfo.birth = "10011986";curDataInfo.birth为不带"/"的字符串;
                //var DateArr = dataInfo.idob.split("/");
                //curDataInfo.birth = DateArr[0]+DateArr[1]+DateArr[2];
                curDataInfo.birth = "10011986";
                curDataInfo.age = dataInfo.iage;

                curDataInfo.basicpremium = commonService.amountToNumFormat(dataInfo.basicPremium);

                var sa = dataPlan.sa;
                curDataInfo.deathbenefit = commonService.amountToNumFormat(sa);

                curDataInfo.usertype = "C";
                curDataInfo.token = "01234567890";

                reqPdfFiles(curDataInfo,param);

            }



        }
        function reqPdfFiles(data,param){
            $(".loading").show();

            //$.ajax({
            //    type : "post",
            //    url : "JsonServlet",
            //    data : data,
            //    dataType: "json",
            //    error : function(XMLHttpRequest, textStatus, errorThrown){
            //    	console.log(XMLHttpRequest);
            //        $(".loading").hide();
            //        commonService.standardPopup(1,textStatus);
            //    },
            //    success : function(data) {
            //        $(".loading").hide();
            //        if(data == "" || data == null || data == undefined){
            //            return;
            //        }else if(data.result  == "fail"){
            //            commonService.standardPopup(1,data.errormsg);
            //            return;
            //        }else{
            //            var url = data.filepath;
            //            //var url = '../../imeet-web/js/generic/web/pdf/AIA_Guaranteed_for_Life_33926_20161020172309_.pdf';
            //            var data = IMeetSocketService.createData('agent',param.currentTarget.id,url, "displayPdfViewer","onclick");
            //            IMeetSocketService.sendRequest(data);
            //
            //            displayPdfViewer(url);
            //
            //            $scope.$apply();
            //
            //        }
            //    }
            //});

            var url = 'mjs/pdf/AIA_Guaranteed_for_Life_33926_20161020172309_.pdf';
            var data = IMeetSocketService.createData('agent',param.currentTarget.id,url, "displayPdfViewer","onclick");
            IMeetSocketService.sendRequest(data);

            displayPdfViewer(url);
            $(".loading").hide();
            //$scope.$apply();
        }
        //receive msg to display pdf viewer
        function displayPdfViewer(pdfUrl){
        	//pdf file url
            hideQuoInsuredAddlistBtnFun();
        	$rootScope.pdfUrl = pdfUrl;
        	$rootScope.pageUrl = "/insured";
        	console.log($rootScope.pdfUrl);
        	//change to pdf view
            var url = "/pdfview";
            
            $location.path(url);
            //$scope.$apply();
        }
        
        
        //close pdf
        $scope.closePDF = function(param){
            param = param.currentTarget;
            closePdfFun();
            var data = IMeetSocketService.createData('agent',param.id,"", "closePdfFun","onclick");
            IMeetSocketService.sendRequest(data);
        }
        function closePdfFun(){
            $("#pdf").attr("src","");
//            $rootScope.pdfwrapstatus = false;
        }
        //icom of tryMore and apply click function anfd sync
        //execute sync function
        function pushPage(data){
            var id = data.elementID;
            IMeetLoadDataService.loadData("add",{}).then(function(result){
                if(result){
                    changeView(id);
                    $rootScope.applicationDocId = "app_cont_list_list_0";
                }
            });
        }

        //when click item,change detail view
        function changeView(param) {
            //change view
            $rootScope.quoplusmorestatus = false;
            $rootScope.quoplusmorecontstatus = false;
            $rootScope.quoliststatus = false;
            $rootScope.quobtnstatus = false;
            $rootScope.quomaskstatus = false;
            var url = "/" + param;
            $location.path(url);
            if(param =="quo_plusMore_tryMore"){
                angular.element("#quotations_nav").find(".uparrow").css("display","block");
                angular.element("#quotations_nav").siblings().find(".uparrow").css("display","none");

                $rootScope.quoplusmorestatus1 = true;
                $rootScope.quoplusmorecontstatus1 = true;
                $rootScope.quoliststatus1 = false;
                $rootScope.quobtnstatus1 = true;
                $rootScope.quomaskstatus1 = false;
            }else if(param =="quo_plusMore_preview"){
                $rootScope.quoplusmorestatus = true;
                $rootScope.quoplusmorecontstatus = true;
                $rootScope.quoliststatus = false;
                $rootScope.quobtnstatus = true;
                $rootScope.quomaskstatus = false;
//               $rootScope.pdfwrapstatus = false;
            }
        };

        //list click function
        $scope.getOtherPage = function(param){
            param = param.currentTarget;
            IMeetLoadDataService.loadData(param.id).then(function(result){
                if(result){
                    changeView(param.id);
                    $rootScope.applicationDocId = "app_cont_list_list_0";
                    var data = IMeetSocketService.createData('agent',param.id,"", "pushPage","onclick");
                    IMeetSocketService.sendRequest(data);
                }
            });
        }
    });
    app.controller('addlistCtrl1', function($q, $scope, $rootScope, $location, $window, IMeetSocketService, IMeetLoadDataService, dataService) {
        //quotations product list addlist
        //add listener when on message from socket

        $scope.listener = function(data){
            if(data.action == 'showQuoAddlistFun'){
                showQuoAddlistFun();
            }else if(data.action == 'hideQuoAddlistFun'){
                hideQuoAddlistFun();
            }else if(data.action == 'pushPage'){
                pushPage(data);
            }
        };
        //execute sync function
        function pushPage(data){
            var id = data.elementID;
            IMeetLoadDataService.loadData("add",{}).then(function(result){
                if(result){
                    changeView(id);
                    $rootScope.applicationDocId = "app_cont_list_list_0";
                }
            });
        }

        //when click item,change detail view
        function changeView(param) {
            //change view
            $rootScope.quoplusmorestatus1 = false;
            $rootScope.quoplusmorecontstatus1 = false;
            $rootScope.quoliststatus1 = false;
            $rootScope.quobtnstatus1 = false;
            $rootScope.quomaskstatus1 = false;
            var url = "/" + param;
            $location.path(url);
            if(param =="quo_plusMore_add"){
                $rootScope.quoplusmorestatus1 = true;
                $rootScope.quoplusmorecontstatus1 = true;
                $rootScope.quoliststatus1 = false;
                $rootScope.quobtnstatus1 = true;
                $rootScope.quomaskstatus1 = false;
            }else if(param =="quo_plusMore_apply"){
                angular.element("#application_nav").find(".uparrow").css("display","block");
                angular.element("#application_nav").siblings().find(".uparrow").css("display","none");
            }else if(param =="quo_plusMore_compare"){
                $rootScope.quoplusmorestatus1 = true;
                $rootScope.quoplusmorecontstatus1 = true;
                $rootScope.quoliststatus1 = false;
                $rootScope.quobtnstatus1 = true;
                $rootScope.quomaskstatus1 = false;
            }
        };

        //click quo_plusBtn show quotation insured addlist
        $scope.showQuoAddlist = function(param){
            param = param.currentTarget;
            showQuoAddlistFun();
            //var data = IMeetSocketService.createData('agent',param.id,"", "showQuoAddlistFun","onclick");
            //IMeetSocketService.sendRequest(data);
        }
        function showQuoAddlistFun(){
            $rootScope.quoplusmorestatus1 = true;
            $rootScope.quoplusmorecontstatus1 = true;
            $rootScope.quoliststatus1 = true;
            $rootScope.quobtnstatus1 = false;
            $rootScope.quomaskstatus1 = true;
        }
        //click quo_plusMoreMask hide quotation insured addlist
        $scope.hideQuoAddlist = function(param){
            param = param.currentTarget;
            hideQuoAddlistFun();
            var data = IMeetSocketService.createData('agent',param.id,"", "hideQuoAddlistFun","onclick");
            IMeetSocketService.sendRequest(data);
        }
        function hideQuoAddlistFun(){
            $rootScope.quoplusmorestatus1 = true;
            $rootScope.quoplusmorecontstatus1 = true;
            $rootScope.quoliststatus1 = false;
            $rootScope.quobtnstatus1 = true;
            $rootScope.quomaskstatus1 = false;
        }
        //list click function
        $scope.getOtherPage = function(param){
            param = param.currentTarget;
            IMeetLoadDataService.loadData(param.id).then(function(result){
                if(result){
                    $rootScope.applicationDocId = "app_cont_list_list_0";
                    changeView(param.id);
                    var data = IMeetSocketService.createData('agent',param.id,"", "pushPage","onclick");
                    IMeetSocketService.sendRequest(data);
                }
            });
        }
    });
    //productDetail addList
    app.controller('addlistCtrl2', function($q, $scope, $rootScope, $location, $window, IMeetSocketService, IMeetLoadDataService, dataService) {
        //add listener when on message from socket

        $scope.listener = function(data){
            if(data.action == 'showProductAddlistFun'){
                showProductAddlistFun();
            }else if(data.action == 'hideProductAddlistFun'){
                hideProductAddlistFun();
            }else if(data.action == 'pushPage'){
                pushPage(data);
            }
        };
        //execute sync function
        function pushPage(data){
            var id = data.elementID;
            IMeetLoadDataService.loadData("insured",{}).then(function(result){
                if(result){
                    changeView(id);
                }
            });
        }

        //when click item,change detail view
        function changeView(param) {
            //change view
            IMeetLoadDataService.loadData("insured",param).then(function(result){
                if(result){
                    $rootScope.quoplusmorestatus2 = false;
                    $rootScope.quoplusmorecontstatus2 = false;
                    $rootScope.quoliststatus2 = false;
                    $rootScope.quobtnstatus2 = false;
                    $rootScope.quomaskstatus2 = false;
                    var url = "/" + param;
                    $location.path(url);
                    if(param =="pro_plusMore_quote"){
                        angular.element("#quotations_nav").find(".uparrow").css("display","block");
                        angular.element("#quotations_nav").siblings().find(".uparrow").css("display","none");
                        $rootScope.quoplusmorestatus = true;
                        $rootScope.quoplusmorecontstatus = true;
                        $rootScope.quoliststatus = false;
                        $rootScope.quobtnstatus = true;
                        $rootScope.quomaskstatus = false;
//                $rootScope.pdfwrapstatus = false;
                    }
                }
            });

        };

        //click quo_plusBtn show quotation insured addlist
        $scope.showProductAddlist = function(param){
            param = param.currentTarget;
            showProductAddlistFun();
            //var data = IMeetSocketService.createData('agent',param.id,"", "showProductAddlistFun","onclick");
            //IMeetSocketService.sendRequest(data);
        }
        function showProductAddlistFun(){
            $rootScope.quoplusmorestatus2 = true;
            $rootScope.quoplusmorecontstatus2 = true;
            $rootScope.quoliststatus2 = true;
            $rootScope.quobtnstatus2 = false;
            $rootScope.quomaskstatus2 = true;
        }
        //click quo_plusMoreMask hide quotation insured addlist
        $scope.hideProductAddlist = function(param){
            param = param.currentTarget;
            hideProductAddlistFun();
            var data = IMeetSocketService.createData('agent',param.id,"", "hideProductAddlistFun","onclick");
            IMeetSocketService.sendRequest(data);
        }
        function hideProductAddlistFun(){
            $rootScope.quoplusmorestatus2 = true;
            $rootScope.quoplusmorecontstatus2 = true;
            $rootScope.quoliststatus2 = false;
            $rootScope.quobtnstatus2 = true;
            $rootScope.quomaskstatus2 = false;
        }
        //list click function
        $scope.getOtherPage = function(param){
            param = param.currentTarget;
            IMeetLoadDataService.loadData("insured",param.id).then(function(result){
                if(result){
                    changeView(param.id);
                    var data = IMeetSocketService.createData('agent',param.id,"", "pushPage","onclick");
                    IMeetSocketService.sendRequest(data);
                }
            });
        }
    });
});


