'use strict';

define(["app"], function (app) {
    console.log('navCtrl is called!');
    
    app.controller('navCtrl', function($q, $scope, $rootScope, $location, $window, IMeetSocketService, IMeetLoadDataService, dataService,commonService) {
        if ((/iphone|ipad/gi).test(navigator.appVersion)) {
            $("img.back").css({"display":"block"});
        }

        ////判断浏览器缩放比例是否是100%，若不是，提示用户按ctrl+0或command+0重置浏览器缩放比例至100%。
        //$rootScope.browserzoomstatus = 0;
        //if(!(/iphone|ipad/gi).test(navigator.appVersion)){
        //    var browserZoom = detectZoom();
        //    if(browserZoom != 100 && $rootScope.browserzoomstatus == 0){
        //        //commonService.extendPopup("","Your browser is currently in an enlarged or reduced state, will lead to the space is not normal, you can press the 'CTRL+ 0' or 'COMMAND+0' key to restore the initial state, thank you!","",noLongerPrompt,[{text:'OK',value:1},{text:'No Longer Prompt',value:-1}]);
        //        commonService.standardPopup(1,"Your browser is currently in an enlarged or reduced state, will lead to the space is not normal, you can press the 'CTRL + 0' or 'COMMAND + 0' key to restore the initial state, thank you!");
        //    }
        //}
        //function noLongerPrompt(val){
        //    if(val == -1){
        //        $rootScope.browserzoomstatus = 1;
        //    };
        //};

        function initHealthData() {
            //init application health page step and health page html
            dataService.healthHtml = [];
            dataService.healthRequestStep = 0;
            dataService.health = {};
        }
        //execute sync function
        function pushNavPage(data){
            //init application health page step and health page html
            initHealthData();

            $(".loading").show();

            var id = data.elementID;
            IMeetLoadDataService.loadData(id.replace("_nav","")).then(function(result){
                if(result){
                    changeView(id);
                    $(".loading").hide();
                }
            });
        }

        //when click nav bar,change view
        function changeView(id){
            //隐藏画布
            //$rootScope.isShow = false;
            angular.element("#" + id).parent().find("div").attr("style","display:none");
            angular.element("#" + id +" div").attr("style","display:block");
            var url = '/'+ id.replace("_nav","");

            $location.path(url);

            $rootScope.quoplusmorestatus = false;
            $rootScope.quoplusmorecontstatus = false;
            $rootScope.quoliststatus = false;
            $rootScope.quobtnstatus = false;
            $rootScope.quomaskstatus = false;
            //$rootScope.pdfwrapstatus = false;

            $rootScope.quoplusmorestatus1 = false;
            $rootScope.quoplusmorecontstatus1 = false;
            $rootScope.quoliststatus1 = false;
            $rootScope.quobtnstatus1 = false;
            $rootScope.quomaskstatus1 = false;

            $rootScope.quoplusmorestatus2 = false;
            $rootScope.quoplusmorecontstatus2 = false;
            $rootScope.quoliststatus2 = false;
            $rootScope.quobtnstatus2 = false;
            $rootScope.quomaskstatus2 = false;

            $rootScope.quoplusmorestatus3 = false;
            $rootScope.quoplusmorecontstatus3 = false;
            $rootScope.quoliststatus3 = false;
            $rootScope.quobtnstatus3 = false;
            $rootScope.quomaskstatus3 = false;

            $rootScope.quoplusmorestatus4 = false;
            $rootScope.quoplusmorecontstatus4 = false;
            $rootScope.quoliststatus4 = false;
            $rootScope.quobtnstatus4 = false;
            $rootScope.quomaskstatus4 = false;

            if(id == "quotations_nav"){
                //QUOTATION PLUS MORE LIST
                $rootScope.quoplusmorestatus1 = true;
                $rootScope.quoplusmorecontstatus1 = true;
                $rootScope.quoliststatus1 = false;
                $rootScope.quobtnstatus1 = true;
                $rootScope.quomaskstatus1 = false;
            }

        }


        //add listener when on message from socket
        $scope.listener = function(data){
           if(data.action == 'pushNavPage'){
               pushNavPage(data);
           }
        };

        //listen click function
        $scope.navClick = function(param){
            //init application health page step and health page html
            initHealthData();

            $(".loading").show();

            param = param.currentTarget;
            //load next level data,if success,change view and send message to socket
            IMeetLoadDataService.loadData(param.id.replace("_nav","")).then(function(result){
               if(result){
                 changeView(param.id);
                 var data = IMeetSocketService.createData('agent',param.id,"", "pushNavPage","onclick");
                 IMeetSocketService.sendRequest(data);

                   $(".loading").hide();
               }
            });
        };

        //init show sync page
        var initPage= "products_nav";
        var data = IMeetSocketService.createData('agent',initPage,"", "pushNavPage","onclick");

        pushNavPage(data);
    });
});
////这里所说的缩放不是指浏览器大小的缩放，而是指浏览器网页内容的百分比缩放（按Ctrl和+号键或者-号键的缩放）。
////detectZoom 函数的返回值如果是 100 就是默认缩放级别，大于 100 则是放大了，小于 100 则是缩小了。
//function detectZoom (){
//    var ratio = 0,
//        screen = window.screen,
//        ua = navigator.userAgent.toLowerCase();
//
//    if (window.devicePixelRatio !== undefined) {
//        ratio = window.devicePixelRatio;
//    }
//    else if (~ua.indexOf('msie')) {
//        if (screen.deviceXDPI && screen.logicalXDPI) {
//            ratio = screen.deviceXDPI / screen.logicalXDPI;
//        }
//    }
//    else if (window.outerWidth !== undefined && window.innerWidth !== undefined) {
//        ratio = window.outerWidth / window.innerWidth;
//    }
//
//    if (ratio){
//        //ratio = Math.round(ratio * 100);
//        ratio = Math.round(ratio * 100)/2;
//    }
//
//    return ratio;
//};