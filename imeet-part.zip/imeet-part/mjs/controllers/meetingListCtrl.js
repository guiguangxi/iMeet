'use strict';

define(
		[],
		function() {
			function _controller($scope, $http, $location, $rootScope,$dateParser,commonService) {
				console.log('meetingListCtrl is called!');
				/*定义一个月的对象,来处理数字月份和英文月份间的转换*/
				var monthObj = {
				    "num_m":["1","2","3","4","5","6","7","8","9","10","11","12"],
				    "english_m":["January","February","March","April","May","June","July","August","September","October","November","December"]
				};
				/*定义一个星期的对象,用来处理数字星期和英文星期间的转换*/
				var weekObj = {
				    "num_w":[1,2,3,4,5,6,0],
				    "english_w":["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
				};
				function dateChangeToWeek(date){
				    //var myDate = new Date(date);
                    //let dateParser = $dateParser();
					var dateParser = $dateParser();
					var myDate = dateParser.parse(date, null, "dd/MM/yyyy");
				    var week = myDate.getDay();
				    return week;
				}
				// call iosFunction
				function iosFunc(data){
				    var jsonStr = JSON.stringify(data);
				    var Link = 'ios:///'+ jsonStr;
				    return Link;
				}
				// date format
				function dateFormat(paramDate) {// d代表日期,n代表标识
					var newDateType;
					var myDate = new Date(paramDate);
					var Y = myDate.getFullYear();
					var M = myDate.getMonth() + 1;
					var D = myDate.getDate();
					if (M < 10) {
						M = "0" + M;
					}
					if (D < 10) {
						D = "0" + D;
					}
					if (paramDate.indexOf("/") > 0) {

						newDateType = Y + '-' + M + '-' + D;
					} else {
						newDateType = M + '/' + D + '/' + Y;
					}

					return newDateType;
				}
				//date convert to english
				function dateConvert(paramDate){

					/*
					var app_date_obj = new Date(paramDate);
					*/
					console.log($dateParser);

					//let dateParser = $dateParser();
					var dateParser = $dateParser();
					var app_date_obj = dateParser.parse(paramDate, null, "dd/MM/yyyy");

                    var app_date_m_num = app_date_obj.getMonth()+1;//数字月份
                    var app_date_m_eng;//英文月份
                    for(var j = 0;j < monthObj.num_m.length;j ++){
                        if(app_date_m_num == monthObj.num_m[j]){
                            app_date_m_eng = monthObj.english_m[j];
                        }
                    };
                    var app_week_num = dateChangeToWeek(paramDate);
                    var app_week_eng;
                    for(var n = 0;n < weekObj.num_w.length;n ++){
                        if(app_week_num == weekObj.num_w[n]){
                            app_week_eng = weekObj.english_w[n]
                        }
                    };
                    return app_week_eng+',  '+app_date_m_eng+' '+app_date_obj.getDate()+',  '+app_date_obj.getFullYear();//meeting date

				}
				//time zone
				function getTimeZone(){
				    var _date = new Date();
				    var zoneTime = Math.abs(_date.getTimezoneOffset())/60;
				    var time_one = "GMT" + "+" +zoneTime;

				    return time_one;
				}
				
				// request meeting information from socket server
				function reqMeetingList() {
					var param = {
						"agent_code" : $rootScope.rootObj.agent_code
					},
					// post请求的地址
					url = $rootScope.rootObj.mrmServerURL + "/listRoomforAgent",
					
					webServerURL = $rootScope.rootObj.webServerURL,
					
					video_name = $rootScope.rootObj.video_name,
					
					agent_code = $rootScope.rootObj.agent_code,
					
					agent_name = $rootScope.rootObj.agent_name,

					// 将参数传递的方式改成form
					postCfg = {
						headers : {
							'Content-Type' : 'application/x-www-form-urlencoded'
						},
						transformRequest : function(value) {
							return $.param(value);
						}
					};
					$(".loading").show();
					$.ajax({
						type : "post",
						url : url,
						dataType : "text",
						data : param,
						timeout : 15 * 1000,
						success : function(data) {
							console.log("network is OK");
							//commonService.standardPopup(1,"network is OK")

							if (data == "") {
								$(".loading").hide();
								commonService.standardPopup(1,"Welcome to use iMeet, please create your first meeting room!");
								return;
							}
							var roomlist = data.match(/\{[^\}]+\}/g);
							var roolistlen = roomlist.length;
							var room;
							var rooms = [];

							for (var i = 0; i < roolistlen; i++) {
								room = $.parseJSON(roomlist[i]);

//										var startHour = new Date(room.app_startTime).getHours();
//										var startMin = new Date(room.app_startTime).getMinutes();
//										var endHour = new Date(room.app_endTime).getHours();
//										var endMin = new Date(room.app_endTime).getMinutes();
//										if(startHour < 10){
//											startHour = "0" + startHour;
//										}
//										if(startMin < 10){
//											startMin = "0" + startMin;
//										}
//										if(endHour < 10){
//											endHour = "0" + endHour;
//										}
//										if(endMin < 10){
//											endMin = "0" + endMin;
//										}
//										room.app_startTime = startHour + ":" + startMin;
//										room.app_endTime = endHour + ":" + endMin;
								rooms.push(room);
								rooms[i].idx = i;
								rooms[i].user_name = rooms[i].user_name.toUpperCase();
								rooms[i].agent_name = agent_name;
								rooms[i].app_date = rooms[i].app_date;
								rooms[i].linkAddr = webServerURL
										+ "/welcome.html?video_name="
										+ video_name + "&token="
										+ rooms[i].token
										+ "&initPage=0";
							}

							$scope.rooms = rooms;
							$scope.agent_code = agent_code;
							$scope.agent_name = agent_name;
							$scope.$apply();
							console.log($scope.rooms);

							$(".loading").hide();
						},
						error : function(data) {
							console.log("network is error");
							$(".loading").hide();
							commonService.standardPopup(1,"Network is disconnect");
						}
					});
				}
				;
				
				// bind the add button fun to forward to meeting form page
				$scope.addMeeting = function() {
					console.log("forward to meeting form page to create new meeting");

					var param = {};

					param.agent_code = $rootScope.rootObj.agent_code;
					param.agent_name = $rootScope.rootObj.agent_name;
					$rootScope.paramObj = param;
					$location.path('/form');
				}
				// bind the edit button fun to forward to meeting form page
				$scope.editMeeting = function(param) {
					console.log("forward to meeting form page to edit meeting");
					// console.log("param="+param);
					/*
					var curStartTimeDate = param.app_date + " " +  param.app_startTime;
					var curEndTimeDate = param.app_date + " " + param.app_endTime;
					console.log(curStartTimeDate);
					console.log(curEndTimeDate);
					param.app_startTime = new Date(curStartTimeDate);
					param.app_endTime = new Date(curEndTimeDate);
					*/
					$rootScope.paramObj = param;
					$location.path('/form');
				}
				// bind the delete button fun to delete the meeting info
				$scope.deleteMeeting = function(param) {
					console.log("delete meeting");

					$scope.rooms.splice(param.idx,1);
					var param = {
							"token"		 :param.token,
							"agent_code" : param.agent_code
						},
						// post请求的地址
						url = $rootScope.rootObj.mrmServerURL + "/delRoombyToken";
					//console.log($scope.rooms);
					$
					.ajax({
						type : "post",
						url : url,
						dataType : "text",
						data : param,
						timeout : 15 * 1000,
						success : function(data) {
							console.log("network is OK");
							$location.path('/list');
							$scope.$apply();
							reqMeetingList();
							
						},
						error : function(data) {
							console.log("network is error");
							commonService.standardPopup(1,"Network is disconnect");
						}
					});
					
					
				}
				// bind the mail button fun to send mail
				$scope.mailMeeting = function(param) {
					console.log("send meeting infomation by mail");
					var emailAddData = {
                            "method":"sendEmail",
                            "email":param.user_email,
                            "curstomer_name":param.user_name,
                            "agent_name":param.agent_name,
                            "meeting_subject":param.subject,
                            "meeting_date":dateConvert(param.app_date),
                            "meeting_time":param.app_startTime +'-'+ param.app_endTime+' | '+getTimeZone(),
                            "link":param.linkAddr,
                            "token":param.token
                        };
					//$location.path('/list');
					
					window.location.href=iosFunc(emailAddData);
					//alert(iosFunc(emailAddData));
					
					//$location.path('/list');
				}
				// bind the start button fun to open iposweb
				$scope.startMeeting = function(param) {
					console.log("forward to iposweb");
					
					var param = {
							"token"		 :param.token,
							"agent_code" : param.agent_code
						},
						// post请求的地址
						url = $rootScope.rootObj.mrmServerURL + "/validateToken";
					$(".loading").show();
					$
					.ajax({
						type : "post",
						url : url,
						dataType : "text",
						data : param,
						timeout : 15 * 1000,
						success : function(data) {
							console.log("network is OK");
							 var dataCode = data.substr(0,1);
				                if(dataCode == 1){
				                	$(".loading").hide();
									commonService.standardPopup(1,"The meeting has expired!");
				                    return;
				                }else{
				                	var linkAddData = {
				                            "method":"start",
				                            "link":$rootScope.rootObj.webServerURL+"/index.html?video_name="+$rootScope.rootObj.video_name+ "&token="+ param.token+"&role=agent&user="+$rootScope.rootObj.agent_name,
				                            "token":param.token,
				                            "agentName":$rootScope.rootObj.agent_name,
				                            "dataCode":"0"
				                        };
				                	
				                	//alert(linkAddData.link);
				                	$(".loading").hide();
									window.location.href=iosFunc(linkAddData); 
				                }
				              							
						},
						error : function(data) {
							console.log("network is error");
							$(".loading").hide();
							commonService.standardPopup(1,"Network is disconnect");
						}
					});
					
										
					
					
					//alert(iosFunc(linkAddData));
				}
				
				reqMeetingList();

			}
			return _controller;

		});
