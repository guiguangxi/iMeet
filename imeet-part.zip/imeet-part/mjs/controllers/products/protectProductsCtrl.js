'use strict';

define([], function () {

    function _controller($scope, $http, $rootScope,$location, IMeetSocketService, IMeetLoadDataService, dataService) {
    	console.log('protectionProductsCtrl is called!');

        $scope.items = dataService.protectProducts;
        $scope.title = dataService.protectProductsTitle;

        //execute sync function
        function pushPage(data){
            var id = data.elementID;
             IMeetLoadDataService.loadData("productDetails",{}).then(function(result){
               if(result){
                 changeView(id);
               }
           });
        }

        //when click item,change detail view
        function changeView(param) {

            //change view
            $location.path('/productDetails');
            $rootScope.quoplusmorestatus2 = true;
            $rootScope.quoplusmorecontstatus2 = true;
            $rootScope.quoliststatus2 = false;
            $rootScope.quobtnstatus2 = true;
            $rootScope.quomaskstatus2 = false;

        }

        //add listener when on message from socket
        $scope.listener = function(data){
           if(data.action == 'pushPage'){
               pushPage(data);
           }
        };

        //list click function
        $scope.getProductDetails = function(param){
            IMeetLoadDataService.loadData("productDetails",{}).then(function(result){
               if(result){
                 changeView(param.id);
                 var data = IMeetSocketService.createData('agent',param.id,"", "pushPage","onclick");
                 IMeetSocketService.sendRequest(data);
               }
            });
        }
    }

    return _controller;
});