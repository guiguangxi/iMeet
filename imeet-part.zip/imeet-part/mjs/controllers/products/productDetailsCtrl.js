'use strict';

define([], function () {

    function _controller($scope, $rootScope, $http, $location, IMeetSocketService, IMeetWebService, IMeetLoadDataService, dataService, commonService) {
        console.log('protectDetail is called!');
        function  init(){
            $scope.items = dataService.productDetails;
        }
        init();
    }

    return _controller;
});
