'use strict';

define([], function () {
    function _controller($scope, $rootScope, $http, $location, IMeetSocketService, IMeetWebService, IMeetLoadDataService, dataService, commonService) {
    	console.log('productsController is called!');
        //add alert demo
        // commonService.standardPopup(1,"Welcome Welcome Welcome Welcome",function(){
        //     console.log('pop up');
        // });

    	$scope.items = dataService.products;

        //execute sync function
        function pushPage(data){
            var id = data.elementID;
             IMeetLoadDataService.loadData("protectionProducts",{}).then(function(result){
               if(result){
                 changeView(id);
               }
           });
        }

        //when click item,change detail view
        function changeView(param) {
            //change view
            $location.path('/protectionProducts');
        }

        //add listener when on message from socket
        $scope.listener = function(data){
           if(data.action == 'pushPage'){
               pushPage(data);
           }
        }

        //listen click function
        $scope.getProtectionDetails = function(param){
            IMeetLoadDataService.loadData("protectionProducts",{}).then(function(result){
               if(result){
                 changeView(param.id);
                 
                 var data = IMeetSocketService.createData('agent',param.id,"", "pushPage","onclick");
                 IMeetSocketService.sendRequest(data);
               }
            });
        }
    }

    return _controller;
});
