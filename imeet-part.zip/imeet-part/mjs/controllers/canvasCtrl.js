'use strict';

define(["app"], function (app) {
    console.log('canvasController is called!');
    
    app.controller('canvasController', function($window, $location, $scope,IMeetSocketService) {
		$scope.isShow = false;
		$scope.isLock = true;
		$scope.highlighterToolIsShow = false;

		//highlighter tool diyColor
		//$scope.DiyColor = "rgba(240,240,0,0.2)";
		$scope.DiyColor = "rgba(251,191,86,0.2)";
		$scope.DiyLineWidth = 30;


		var winResizeTimeId;
		//window.onresize = function(){
		$(window).resize(function(){
			//调整有侧聊天窗口高度自适应
			//alert("akgajkg");
			win_resize();
		});
		function win_resize(){
			window.clearTimeout(winResizeTimeId);
			winResizeTimeId = window.setTimeout(function(){
				doResizeCode();
			},100);
		}
		function doResizeCode(){
			var contentLeftW = angular.element("#scroll").width() + 2;
			//alert(contentLeftW);
			document.getElementById("canvas_div").style.width = contentLeftW + "px";
			document.getElementById("canvas_content").style.width = contentLeftW + "px";
			document.getElementById("canvas").style.width = contentLeftW + "px";
		}
    	function showPalette() {
			var width = angular.element("#scroll").width() + 2;
			var height = angular.element("#scroll").height() + 2;
			var canvas = document.getElementById("canvas");

			canvas.width = width;
			canvas.height = height;
			var canvas_content = document.getElementById("canvas_content");
			canvas_content.width = width;
			canvas_content.height = height;
			//var canvas_div = document.getElementById("pro");

			$scope.isShow = !$scope.isShow;
			$scope.highlighterToolIsShow = false;
			var canvas_div = document.getElementById("canvas_div");
			var highlighter_tool = document.getElementById("highlighter_tool");
			var scroll_padding = document.getElementById("scroll");
			if ($scope.isShow == false) {
				canvas_div.style.height = "20px";
				scroll_padding.style.paddingTop = "0px";
				highlighter_tool.style.display= 'none';
			} else {
				canvas_div.style.height = "45px";
				scroll_padding.style.paddingTop = "20px";

				var toolNodes = document.getElementsByClassName("h_tool");
				for(var i =0,tl= toolNodes.length;i<tl;i++) {
					toolNodes[i].style.borderColor = '#ccc';
					toolNodes[i].style.borderRadius = '0';
				}

				var hLine3 = document.getElementById("h_line_3");
				hLine3.style.borderColor = "#fff";
				hLine3.style.borderRadius = "4px";
				var hColor2 = document.getElementById("h_color_2");
				hColor2.style.borderColor = "#fff";
				hColor2.style.borderRadius = "4px";

				$scope.DiyColor = "rgba(251,191,86,0.2)";
				$scope.DiyLineWidth = 30;
			}
			$scope.$emit('show',$scope.isShow);

		}
    	
    	function showRubber(){
    		document.getElementById("pen").style.backgroundColor= '';
    		document.getElementById("highlighter").style.backgroundColor= '';
    		document.getElementById("rubber").style.backgroundColor= 'rgba(89,108,126,1)';
    		$scope.$emit('rubber');
			hideHighlighterTool();
    	}
    	
    	function showPainting(){
    		document.getElementById("rubber").style.backgroundColor= '';
    		document.getElementById("highlighter").style.backgroundColor= '';
    		document.getElementById("pen").style.backgroundColor= 'rgba(89,108,126,1)';
    		$scope.$emit('painting');
			hideHighlighterTool();
    	}
    	
    	
    	function showHighlighter(){
    		document.getElementById("rubber").style.backgroundColor= '';
    		document.getElementById("pen").style.backgroundColor= '';
    		document.getElementById("highlighter").style.backgroundColor= 'rgba(89,108,126,1)';

			//$scope.DiyColor = "rgba(240,240,0,0.1)";
    		$scope.$emit('highlighter');
			showHighlighterTool();
    	}
		//highlighter tool S
		function changeToolColor(id){
			console.log("BorderColor" + id);
			var curToolNode = document.getElementById(id);
			var toolNodes = document.getElementsByClassName("h_color_tool");
			console.log(toolNodes.length);
			for(var i =0,tl= toolNodes.length;i<tl;i++) {
				if(toolNodes[i] !== curToolNode){
					toolNodes[i].style.borderColor = '#ccc';
					toolNodes[i].style.borderRadius = '0';
				}else{
					toolNodes[i].style.borderColor = '#fff';
					toolNodes[i].style.borderRadius = '4px';
				};
			}
			//angular.element("#" + id).parent().children("span").css({'borderColor'}) = '#ccc';
			//document.getElementById(id).style.borderColor = 'rgb(240,240,0)';
		}
		function changeToolLineWidth(id){
			console.log("BorderColor" + id);
			var curToolNode = document.getElementById(id);
			var toolNodes = document.getElementsByClassName("h_line_tool");
			console.log(toolNodes.length);
			for(var i =0,tl= toolNodes.length;i<tl;i++) {
				if(toolNodes[i] !== curToolNode){
					toolNodes[i].style.borderColor = '#ccc';
					toolNodes[i].style.borderRadius = '0';
				}else{
					toolNodes[i].style.borderColor = '#fff';
					toolNodes[i].style.borderRadius = '4px';
				};
			}
			//angular.element("#" + id).parent().children("span").css({'borderColor'}) = '#ccc';
			//document.getElementById(id).style.borderColor = 'rgb(240,240,0)';
		}
		function showHighlighterTool(){
			$scope.highlighterToolIsShow = !$scope.highlighterToolIsShow;
			var highlighter_tool = document.getElementById("highlighter_tool");

			highlighter_tool.style.display= 'inline-block';
		}
		function hideHighlighterTool(){
			$scope.highlighterToolIsShow = false;

			var highlighter_tool = document.getElementById("highlighter_tool");
			highlighter_tool.style.display= 'none';
		}
		function highLineSel(id){
			$scope.$emit('hLineSel',id);
			changeToolLineWidth(id);
		}

		$scope.highLineClick = function(event){
			var id = event.currentTarget.id;
			console.log(id);
			highLineSel(id);
			var data =IMeetSocketService.createData('agent',id, "", "highLineSel","onclick");
			IMeetSocketService.sendRequest(data);
		}

		function highColorSel(id){
			$scope.$emit('hColorSel',id);
			changeToolColor(id);
		}
		$scope.highColorClick = function(event){
			var id = event.currentTarget.id;
			console.log(id);
			highColorSel(id);
			var data =IMeetSocketService.createData('agent',id, "", "highColorSel","onclick");
			IMeetSocketService.sendRequest(data);
		}
		function diyColor(data){
			$scope.DiyColor = data.result;
			$scope.$emit('highlighter');
		}
		$scope.diyColorBlur = function(event){
			var id = event.currentTarget.id;
			var value = $scope.DiyColor;
			var data =IMeetSocketService.createData('agent',id,value, "diyColor","onclick");
			IMeetSocketService.sendRequest(data);
			diyColor(data);
		}
		$scope.diyColorChange = function(event){
			var id = event;
			var value = $scope.DiyColor;
			var data =IMeetSocketService.createData('agent',id, value, "diyColor","onclick");
			IMeetSocketService.sendRequest(data);
			diyColor(data);
		}


		//highlighter tool E

    	function clear(data){    		
    		$scope.$emit('clear',data);
    	}
    	
    	function draw(data){
    		
    		if($location.path().indexOf('pdfview') > 0){
    			$scope.$emit('drawPDF',data);
    		}else{
    			$scope.$emit('draw',data);
    		}
    	}
    	
    	function lockScreen(){
    		$scope.isLock = !$scope.isLock;
    	}
    	
    	$scope.listener = function(data){
	    	  if(data.action == 'showPalette'){
	    		  showPalette();
	    	  }else if(data.action == 'showPainting'){
	    		  showPainting();
	    	  }else if(data.action == 'showRubber'){
	    		  showRubber();
	    	  }else if(data.action == 'draw'){
	    		  draw(data.result);
	    	  }else if(data.action == 'clear'){
	    		  clear(data.result);
	    	  }else if(data.action == 'lockScreen'){
	    		  lockScreen();
	    	  }else if(data.action == 'showHighlighter'){
	    		  showHighlighter();
	    	  }else if(data.action == 'highLineSel'){
				  highLineSel(data.elementID);
			  }else if(data.action == 'highColorSel'){
				  highColorSel(data.elementID);
			  }else if(data.action == 'diyColor'){
				  diyColor(data);
			  }
	      };
    	
    	$scope.$watch('isLock',function(result){
    		if(result){
    			$scope.btn_locker = 'img/canvas/lock.png';
    		}else{
    			$scope.btn_locker = 'img/canvas/unlock.png';
    		}
    	});
    	
    	$scope.$watch('isShow',function(result){
    		$scope.btn_pen = 'img/canvas/pen.png';
    		$scope.btn_rubber = 'img/canvas/rubber.png';
    		$scope.btn_locker = 'img/canvas/lock.png';
    		$scope.btn_highlighter = 'img/canvas/highlighter.png';
    		document.getElementById("canvas").style.display = "block";
    		document.getElementById("canvas_tool").style.display = "block";
    		
    		if(result){
    			$scope.btn_img = 'img/canvas/drawingShow.png';
    			angular.element("#canvas").hidden = true;
    			document.getElementById("canvas").style.display = "block";
    			document.getElementById("canvas_tool").style.display = "block";
    			$scope.isLock = true;
    			showPainting();
    		}else{
    			document.getElementById("rubber_content").style.display = "none";
    			$scope.btn_img = 'img/canvas/drawingHidden.png';
    			angular.element("#canvas").hidden = false;
    			document.getElementById("canvas").style.display = "none";
    			document.getElementById("canvas_tool").style.display = "none";
    			$scope.isLock = false;
    		}
    	});
    	
    	$scope.penClick= function(){
    		showPainting();
    		var data =IMeetSocketService.createData('agent','canvas_div','', "showPainting","onclick");
    		IMeetSocketService.sendRequest(data);
    	};
    	$scope.highlighterClick= function(){
    		showHighlighter();
    		var data =IMeetSocketService.createData('agent','canvas_div','', "showHighlighter","onclick");
    		IMeetSocketService.sendRequest(data);
    	};
    	
    	$scope.rubberClick= function(){
    		showRubber();
    		var data =IMeetSocketService.createData('agent','canvas_div','', "showRubber","onclick");
    		IMeetSocketService.sendRequest(data);
    	};
    	
    	$scope.lockerClick= function(){
    		lockScreen();
    		var data =IMeetSocketService.createData('agent','canvas_div','', "lockScreen","onclick");
    		IMeetSocketService.sendRequest(data);
    	};
    	
    	$scope.showPalette = function(){
    			showPalette();
    			var data =IMeetSocketService.createData('agent','canvas_div','', "showPalette","onclick");
	    		IMeetSocketService.sendRequest(data);
    	};
    	
    	$scope.finished = function (type,positions){
    		var value = {
    			cwidth:angular.element("#scroll").width(),
    			cheight:angular.element("#scroll").height(),
    			positions:positions
    		};
    		var data =IMeetSocketService.createData('agent','canvas_div',value, type,"onclick");
    		IMeetSocketService.sendRequest(data);
    	};
    	
		function canvas_fixed(){
			var width_div = angular.element("#scroll").width();
			var canvas_div = document.getElementById("canvas_div");
			canvas_div.style.width = width_div+"px";
			//product padding-top change

		}
		canvas_fixed();
    });
});