// Create our Skylink object
var SkylinkDemo = new Skylink();
var userList;
var messageList;

function initChat(roomname,username) {
	  $("#clearInputButton").click(function () {
		    $("#MessageList").empty();
	  })
     $("iframe[name='adapterjs-alert']").hide();
	
    SkylinkDemo.setUserData(username);
    //Get Object by ID
    // userList = document.getElementById("UserList");
    messageList = document.getElementById("MessageList");
    //var userInputName = document.getElementById("UserNameInput");
    // var userInputRoom = document.getElementById("RoomNameInput");
    var userInputMessage = document.getElementById("MessageInput");
    var userInputMessageButton = document.getElementById("MessageInputButton");


    function getTextAndSend() {
        sendMessage(userInputMessage.value);
        userInputMessage.value = '';
    }

    userInputMessage.addEventListener("keydown", function (event) {
        if (event.keyCode == 13)
            getTextAndSend();
    });
    userInputMessageButton.addEventListener("click", function () {
        getTextAndSend();
    });

    SkylinkDemo.init({
        appKey: 'fdd8476e-877a-44bb-928d-779822abd5bc',
        defaultRoom: roomname,
        enableDataChannel: true, // Disable this and sendBlobData(), sendP2PMessage() and sendURLData() will NOT work!
        enableIceTrickle: true,
        audioFallback: true,
        forceSSL: true
    }, function (error, success) {
        if (success) {
            SkylinkDemo.joinRoom({
                userData: username,
                audio: false,
                video: false
            });

        } else {
            for (var errorCode in SkylinkDemo.READY_STATE_CHANGE_ERROR) {
                if (SkylinkDemo.READY_STATE_CHANGE_ERROR[errorCode] === error.errorCode) {
                    var div = document.createElement('div');
                    div.className = "alert alert-danger msg-date";
                    div.innerHTML = '<strong>Impossible to connect to Skylink: ' + errorCode + '</strong>';
                    messageList.appendChild(div);
                    break;
                }
            }
        }
    });
    //New User in the room, we add it to the user list
    SkylinkDemo.on('peerJoined', function(peerId, peerInfo, isSelf) {
        var userData = peerInfo.userData;
        if(userData == username){
            $("#userTips",parent.document).text("Peer On Line");
        }
        console.log(peerInfo);
    });

    //User in the room left
    SkylinkDemo.on('peerLeft', function(peerId, peerInfo, isSelf) {
        var userData = peerInfo.userData;
        if(userData != username){
            $("#userTips",parent.document).text("Peer Off Line");
        }
    });
}


//New User in the room, we add it to the user list
//SkylinkDemo.on('peerJoined', function(peerId, peerInfo, isSelf) {
//  console.log("Peer Joined");
//  //userList.appendChild(div);
//});

//User in the room left
//SkylinkDemo.on('peerLeft', function(peerId, peerInfo, isSelf) {
//    var elm = document.getElementById("User_" + peerId);
//    if (elm) {
//        elm.remove();
//    } else {
//        console.error('Peer "' + peerId + '" DOM element does not exists');
//    }
//});

//User in the room changed his name
//SkylinkDemo.on('peerUpdated', function(peerId, peerInfo, isSelf) {
//  document.getElementById("UserTitle_" + peerId).innerHTML = peerInfo.userData + ((isSelf) ? "" : "");
//});

//User in the room (including us) sent a message
SkylinkDemo.on('incomingMessage', function(message, peerId, peerInfo, isSelf) {
  var Name = peerInfo.userData;
  addMessage(Name, message.content,isSelf);
});

function setName(newName) {
  if (newName != undefined) {
    newName = newName.trim(); //Protection for empty user name
    if (newName != '') {
      console.log("Change User Name to " + newName);
      SkylinkDemo.setUserData(newName);
    }
  }
}

function setRoom(newRoom) {
  if (newRoom != undefined) {
    newRoom = newRoom.trim(); //Protection for joining room with empty name
    if (newRoom != '') {
      console.log("Change Room To " + newRoom);
      SkylinkDemo.joinRoom(newRoom);
      var div = document.createElement('div');
      div.className = "alert alert-info msg-date";
      div.innerHTML = '<strong>Join Room "' + newRoom + '"</strong>';
      messageList.appendChild(div);
    }
  }

}

function sendMessage(message) {
  if (message != undefined) {
    message = message.trim(); //Protection for empty message
    if (message != '') {
      SkylinkDemo.sendMessage(message);
    }
  }
}

function addMessage(user, message,chanel) {
    console.log("chanel-----"+chanel);
    var timestamp = new Date();
    var tolo=timestamp.toLocaleString()
    var getM=timestamp.getMonth()+1;
    var strO=timestamp.getMonth()>9?timestamp.getMonth().toString():'0' + getM;
    var strM=timestamp.getMinutes()>9?timestamp.getMinutes().toString():'0' + timestamp.getMinutes();
    var strH=timestamp.getHours()>9?timestamp.getHours().toString():'0' + timestamp.getHours();
    var strS=timestamp.getSeconds()>9?timestamp.getSeconds().toString():'0' + timestamp.getSeconds();
    var div = document.createElement('div');
    div.className = "media msg";
    if(chanel == true){
        div.innerHTML = '<div class="media-body">' +
            '<div style="overflow:hidden">'+
            '<small class="pull-left time" >' +
            '<i class="fa fa-clock-o"></i>' +
                //timestamp.getFullYear()+'年'+strO+'月'+ strH+ ':' +strM +':'+strS+
            strO + '/' + timestamp.getFullYear() + ' ' + strH + ':' +strM +':'+strS+
            '</small>' +
            '<h5 class="media-heading pull-right">' + user + '</h5>' +
            '</div>'+
                '<div>'+
            '<p class="col-lg-10 pull-right" style="word-break:break-all;">' + message + '</p>' +
                '</div>'+
            '</div>';
    }else if(chanel == false){
        div.innerHTML = '<div class="media-body">' +
            '<div style="overflow:hidden">'+
            '<small class="pull-right time" >' +
            '<i class="fa fa-clock-o"></i>' +
                //timestamp.getFullYear()+'年'+strO+'月'+ strH+ ':' +strM +':'+strS+
            strO + '/' + timestamp.getFullYear() + ' ' + strH + ':' +strM +':'+strS+
            '</small>' +
            '<h5 class="media-heading" style="color:#f60;">' + user + '</h5>' +
            '</div>'+
                '<div>'+
            '<p class="col-lg-10" style="word-break:break-all;">' + message + '</p>' +
                '</div>'+
            '</div>';
    }

  messageList.appendChild(div);
  messageList.scrollTop = messageList.scrollHeight;
}
