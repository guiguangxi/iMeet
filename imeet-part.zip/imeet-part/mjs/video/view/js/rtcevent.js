/********************************************************
 API Settings
 *********************************************************/
var Demo = Demo || {};
Demo.Peers = {};
Demo.FilesPublic = [];
Demo.Files = {};
Demo.Streams = [];
Demo.Methods = {};
Demo.gridster;
Demo.Skylink = new Skylink();
var muted = true;
var localstream;

var messageList;
var video_timer;
var sendStatus_timer,recStatus_timer;
var peersStats = {};

var url = window.parent.location.href;
var paramObj = getC(url);
var token = paramObj.token;
var username = decodeURI(paramObj.user);
var peerIds;
console.log(paramObj);
 
/********************************************************
 Skylink Events
 *********************************************************/
//---------------------------------------------------
function refreshFrozenVideoStream (peerId) {
	Demo.Skylink.refreshConnection(peerId, function (error, success) {
      if (error) return;
      console.log("Refreshing connection for '" + peerId + "'");
    });
  }

Demo.Skylink.on('incomingMessage', function(message, peerId, peerInfo, isSelf) {
    var Name = peerInfo.userData;
    addMessage(Name, message.content,isSelf);
});

Demo.Skylink.on('peerJoined', function(peerId, peerInfo, isSelf) {
    if (!isSelf)
    $("#userTips",parent.document).text("Peer On Line");
    peerIds=peerId;
});
Demo.Skylink.on('incomingStream', function(peerId, stream, isSelf, peerInfo) {
    console.log("DemoSkylink is Reconncet");
    //clearTimeout(video_timer);
    if (isSelf) {
        if($("#video_self").length===0){
    	 var ownerVideo = document.createElement('video');
 	    ownerVideo.id = 'video_self';
 	    ownerVideo.style.cssText = "width:100%;";
 	    if (window.webrtcDetectedBrowser !== 'IE') {
 	        ownerVideo.muted = 'muted';
 	        ownerVideo.autoplay = 'autoplay';
 	    }
 	    $('#media_self').append(ownerVideo);

 	    attachMediaStream(ownerVideo, localstream);
 	    $('#picture_self').remove();
        return;
        }else{
        	return;
        }
    }
    //Video
    var peerVideo = document.createElement('video');
    peerVideo.id = 'video_' + peerId;
    peerVideo.style.cssText = "width:95%;border: 1px solid red;display:block;margin:0 auto;margin-top: 1px;padding-right:1px";
    if (window.webrtcDetectedBrowser !== 'IE') {
        peerVideo.autoplay = 'autoplay';
    }
    
    var div='<div id="v'+peerId+'" style="position: relative;width:100%"></div>';
    
    $('#video_cont').append(div);
    $('#v'+peerId).append(peerVideo);
    attachMediaStream(peerVideo, stream);
    $('#picture_peer').remove();

    var str='<div class="bandwidth_speed receiveBtn">'
            +'<div class="v_ctrl_btns">'
            +'<p>RECEIVE:<span class="customer_speed" id="s'+peerId+'"></span></p></div></div>';
               
    $('#v'+peerId).append(str);         
            
    var customer_speed =$('#s'+peerId);
    var cStatus = "VeryLow";

    signalIntensity(cStatus,customer_speed);  
     
    
    if(window.webrtcDetectedBrowser==='IE'){
    	$("object").css({
    		"width":"95%",
            "display":"block",
            "margin":"0 auto",
    		"margin-top":"-10px"
    	})
    	$(".receiveBtn p").css({
    		"width":"42%",
    		"margin-bottom":"15px"
    	})
    	$(".myvideo object").css({
    		"margin-left":"0px",
    		"margin-top":"0px"
    	})
    	$(".myvideo div:nth-child(3) object").css({
    		"margin-top":"-40px"
    	})
    }
        
    
    

    var fg = 0;
    video_timer = window.setInterval(function(){
        fg ++;
        console.log("1000-" + fg);
        resetHeight();
        var videoContH = document.getElementById("video_cont").offsetHeight;
        if(videoContH != 158){
            clearInterval(video_timer);
        }
    },1000);
    
    peersStats[peerId] = true;
    recStatus_timer = setInterval(function () {
		if (!peersStats[peerId]) {
			clearInterval(recStatus_timer);
			return;
		}
		Demo.Skylink.getConnectionStatus(peerId);
	}, 5000);
    
    

});
//---------------------------------------------------
Demo.Skylink.on('mediaAccessSuccess', function(stream) {
	 if (window.webrtcDetectedBrowser === 'IE') {
         localstream = stream;
     }
});


//---------------------------------------------------
Demo.Skylink.on('mediaAccessError', function(stream) {
    standardPopup(1,(typeof error === 'object') ? error.message : error);
    Demo.Methods.displayChatMessage('System', 'Failed to join room as video and audio stream is required.');
});
//---------------------------------------------------
Demo.Skylink.on('peerLeft', function(peerId) {
    //Demo.gridster.remove_widget(Demo.Peers[peerId]);
    delete Demo.Peers[peerId];
   // $("#video_"+peerId).remove();
  //  $("#userTips",parent.document).text("Peer Off Line");
    $("#v"+peerId).remove();
   
    //clearInterval(video_timer);
    resetHeight();
   // signalIntensity("VeryLow",customer_speed);
    peersStats[peerId] = false;
});


//---------------------------------------------------
Demo.Skylink.on('channelError', function(error) {
    Demo.Methods.displayChatMessage('System', 'Channel Error:<br>' + (error.message || error));
});
//---------------------------------------------------
Demo.Skylink.on('mediaAccessError', function(error) {
    standardPopup(1,(error.message || error));
    return;
});


Demo.Skylink.init({
    appKey: 'fdd8476e-877a-44bb-928d-779822abd5bc',
    //defaultRoom: "MY_ROOM",
    defaultRoom: token,
    enableDataChannel: true, // Disable this and sendBlobData(), sendP2PMessage() and sendURLData() will NOT work!
    enableIceTrickle: true,
    audioFallback: true,
    forceSSL: true
},function (error, success) {
    if (success) {
        var displayName = username;
        var startCallFn = function () {
            Demo.Skylink.joinRoom({
                userData: displayName,
//                bandwidth:{
//                	audio:50,
//                	video:500,
//                	data:10000
//                },  
                audio: true,
                video: true
            });
        };
        //if (error) return;
        if (window.webrtcDetectedBrowser !== 'IE') {
            navigator.getUserMedia({
                audio: true,
                video: true
            }, function (displayStream) {
                localstream = displayStream;
                startCallFn()
            }, function (error) {
                console.error('GetUserMedia for self display stream error ->', error);
            });
        } else {
            startCallFn();
        }
        
        
        
    

        $('#close_video').click(function(){
            $(".close_video").attr('src',$(".close_video").attr('src')=='./Icon/slect-02@3x.png'?'./Icon/02@3x.png':'./Icon/slect-02@3x.png');
            if($(".close_video").attr('src')=='./Icon/slect-02@3x.png'){
                toggleStream();
                //Demo.Skylink.enableVideo();
            }
            if($(".close_video").attr('src')=='./Icon/02@3x.png'){
                toggleStream();
                //Demo.Skylink.disableVideo();
            }
        });
        $('#close_audio').click(function(){
            $(".close_audio").attr('src',$(".close_audio").attr('src')=='./Icon/slect-01@3x.png'?'./Icon/01@3x.png':'./Icon/slect-01@3x.png');
            if($(".close_audio").attr('src')=='./Icon/01@3x.png'){
                Demo.Skylink.enableAudio();
                //$(this).css({"border":"1px solid #fff"});
            }
            if($(".close_audio").attr('src')=='./Icon/slect-01@3x.png'){
                Demo.Skylink.disableAudio();
                //$(this).css({"border":"1px solid #ccc"});
            }
        });

    } else {
        standardPopup(1,'An error occurred parsing and retrieving server code.\n' +
            'Error was: ' + error.errorCode);
        return;
    }
});
//
function toggleStream(){
    if (muted) {
        muted = false;
        //document.getElementById('togglebutton').innerHTML = 'Start sending Stream';
        Demo.Skylink.muteStream({});
    } else {
        muted = true;
        //document.getElementById('togglebutton').innerHTML = 'Stop sending Stream';
        Demo.Skylink.muteStream({
            audioMuted: false,
            videoMuted: false
        });
    }
}

function getCapureImage(){
	
	if(window.webrtcDetectedBrowser==='IE'||window.webrtcDetectedBrowser==='safari'){
		var video, $output;
		var scale = 0.25;
		video = document.getElementById("video_self");
		var base64 = video.getFrame();
		return 'data:image/bmp;base64,' + base64
		
	}else{
		var video, $output;
		var scale = 0.25;
		video = $("#video_self").get(0);
		$output = $("#output");
		
		var canvas = document.createElement("canvas");
		canvas.width = video.videoWidth * scale;
		canvas.height = video.videoHeight * scale;
		canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
		
		return canvas.toDataURL();
	}	
}
function addMessage(user, message,chanel) {
    console.log("chanel-----"+chanel);
    //alert(user);
    var timestamp = new Date();
    var tolo=timestamp.toLocaleString()
    var getM=timestamp.getMonth()+1;
    var strO=timestamp.getMonth()>9?timestamp.getMonth().toString():'0' + getM;
    var strM=timestamp.getMinutes()>9?timestamp.getMinutes().toString():'0' + timestamp.getMinutes();
    var strH=timestamp.getHours()>9?timestamp.getHours().toString():'0' + timestamp.getHours();
    var strS=timestamp.getSeconds()>9?timestamp.getSeconds().toString():'0' + timestamp.getSeconds();
    var div = document.createElement('div');
    div.className = "media msg";
    if(chanel == true){
        div.innerHTML = '<div class="media-body">' +
            //'<div style="overflow:hidden">'+
            //'<small class="pull-left time" >' +
            //'<i class="fa fa-clock-o"></i>' +
            //    //timestamp.getFullYear()+'年'+strO+'月'+ strH+ ':' +strM +':'+strS+
            //strO + '/' + timestamp.getFullYear() + ' ' + strH + ':' +strM +':'+strS+
            //'</small>' +
            '<h5 class="media-heading pull-right" style="color:#6f6e68;font-size:12px">' + user + '</h5>' +
            '</div>'+
            '<div>'+
            '<p class="col-lg-10 pull-right msgInfo" style="display:inline-block;word-break:break-all;max-width:80%;border:1px solid #ccc;border-radius:4px 0 4px 4px;padding:5px;margin-right:2px;margin:0;background:#d4edf1;">' + message + '</p>' +
            '</div>'+
            '</div>';
    }else if(chanel == false){
        div.innerHTML = '<div class="media-body">' +
            //'<div style="overflow:hidden">'+
            //'<small class="pull-right time" >' +
            //'<i class="fa fa-clock-o"></i>' +
            //    //timestamp.getFullYear()+'年'+strO+'月'+ strH+ ':' +strM +':'+strS+
            //strO + '/' + timestamp.getFullYear() + ' ' + strH + ':' +strM +':'+strS+
            //'</small>' +
            '<h5 class="media-heading" style="color:#6f6e68;font-size:12px">' + user + '</h5>' +
            '</div>'+
            '<div>'+
            '<p class="col-lg-10 msgInfo" style="display:inline-block;word-break:break-all;max-width:80%;border:1px solid #ccc;border-radius:0 4px 4px 4px;padding:5px;margin-left:2px;margin:0;background:#faf9f2;">' + message + '</p>' +
            '</div>'+
            '</div>';
    }

    messageList.appendChild(div);
    var stH = messageList.scrollHeight;
    var scH = document.getElementById("chat_body").offsetHeight;
    if(stH >= scH){
        //document.getElementById("chat_log").style.scrollTop = -(stH - scH);
        $("#chat_body").scrollTop(stH - scH - 30);
    }

    //messageList.scrollTop = messageList.scrollHeight;
}


/********************************************************
 DOM Events
 *********************************************************/
$(document).ready(function() {
    //Demo.Skylink.setUserData('davis');
    Demo.Skylink.setUserData(username);
    messageList = document.getElementById("chat_log");

    $("#clearInputButton").click(function () {
        Demo.Skylink.shareScreen();
        $("#chat_log").empty();
    });
    $("#sendInputButton").click(function(){
        if($('#chat_input_public').val().trim() == ""){
            return;
        }
        Demo.Skylink.sendMessage($('#chat_input_public').val());
        $('#chat_input_public').val('');
    });
    //Public Chat
    $('#chat_input_public').keyup(function(e) {
        e.preventDefault();
        if (e.keyCode === 13) {
            if($('#chat_input_public').val().trim() == ""){
                return;
            }
            Demo.Skylink.sendMessage($('#chat_input_public').val());
            $('#chat_input_public').val('');
        }
    });
    //---------------------------------------------------
});
Demo.Skylink.on('serverPeerJoined', function (peerId) {
	  peersStats[peerId] = true;
      sendStatus_timer = setInterval(function () {
			if (!peersStats[peerId]) {
				clearInterval(sendStatus_timer);
				return;
			}
			Demo.Skylink.getConnectionStatus(peerId);
		}, 5000);

});
function getC(url){//从携带参数的Url里截取所携带的参数并将其转换成参数对象集,可从对象中获取已知参数名称的值
    var obj = {};
    var cs = url.substr(url.indexOf("?")+1);
    //console.log(cs);
    var arr1 = cs.split("=");
    //console.log(arr1);
    var arrLen1 = cs.split("=").length -1;
    //console.log(arrLen1);
    if(arrLen1 > 1){
        var arr2 = cs.split("&");
        //console.log(arr1);
        for(var i = 0;i < arr2.length;i ++){
            //console.log(arr2[i].split("="));
            obj[(arr2[i].split("="))[0]] = (arr2[i].split("="))[1];
        }
    }else if(arrLen1 == 1){
        obj[arr1[0]] = arr1[1];
    }else{
        console.log("The URL did not carry parameters!");
        //return;
    }
    return obj;
}
//standard
//type: popup类型（alert/confirm/others）
//msg: popup 提示信息内容
//callback: popup 按钮点击的回调函数
function standardPopup(type,msg,callback){
    if(type == 1){
        extendPopup("",msg,"","",[{text:"OK",value:0}]);
    }else if(type == 2){
        extendPopup("",msg,callback,"",[{text:"OK",value:1},{text:"CANCEL",value:0}]);
    }
}
//extendPopup(3,"","Welcome Welcome Welcome Welcome",[fun1,fun2,fun3],[{text:'OK',value:1},{text:'Cancel',value:0}]);
//type: popup类型（alert/confirm/others），此处暂时没设定。没用
//title: popup 提示标题（如：warning/tips)
//msg: popup 提示信息内容
//callback: popup 按钮点击的回调函数
//cancelcallback:对应所传参数btnvalarr中value值是-1的时候需要调用的函数
//btnvalarr: popup 按钮对应的value值（即，相应按钮名字）如果value是-1，则表示CANCEL取消按钮也绑定cancelcallback回调函数
//extend
function extendPopup(title,msg,callback,cancelcallback,btnvalarr){
    var msg_h = $("#pop_msg",window.parent.document).height(),
        popBtns = $("#pop_btns",window.parent.document),
        len = btnvalarr.length;
    popBtns.html("");
    $("#pop_title",window.parent.document).html("");
    $("#pop_msg",window.parent.document).text("");
    if(title != ""){
        $("#pop_title",window.parent.document).text(title+":");
    }
    $("#pop_msg",window.parent.document).text(msg);
    if(msg_h > 25){
        $("#pop_msg",window.parent.document).css({"text-align":"justify"});
    }
    if(len == 1){
        $("<a href='javascript:;' class='pop_btn'></a>").html(btnvalarr[0].text).addClass("only_btn").appendTo(popBtns);
        $("a.pop_btn",window.parent.document).on("click",function(){
            $(".pop",window.parent.document).hide();
        });
    }
    if(len == 2){
        for(var i = 0;i < btnvalarr.length;i ++){
            $("<a href='javascript:;' class='pop_btn'></a>").html(btnvalarr[i].text).addClass("two_btn").appendTo(popBtns);
            if(btnvalarr[i].value == 0 || btnvalarr[i].value == -1){
                var index = $(this).index();
                $(".pop_btn",window.parent.document).eq(index).addClass("oColor");
            }
            if(btnvalarr[i].value == -1){
                var index = $(this).index();
                $(".pop_btn",window.parent.document).eq(index).attr({"href":"ios:///{\"method\":\"back\"}"});
            }
        }
        for(var i = 0;i < $("a.pop_btn",window.parent.document).length;i ++){
            $("a.pop_btn",window.parent.document).eq(i).on("click",function(){
                var index = $(this).index();
                if(btnvalarr[index].value == 1){
                    $(this).parents().find(".pop").hide();
                    callback(1);
                }else if(btnvalarr[index].value == -1){
                    $(this).parents().find(".pop").hide();
                    cancelcallback(-1);
                }
                $(".pop",window.parent.document).hide();
            });
        }
    }
    $(".pop",window.parent.document).show();
}
Demo.Skylink.on('getConnectionStatusStateChange', function (state, peerId, stats) {
	if (state === Demo.Skylink.GET_CONNECTION_STATUS_STATE.RETRIEVE_SUCCESS) {
		//var peerStats = document.getElementById(peerId + 'stats');
		//if (!peerStats) return;

		//var parseStatsFn = function (bytes) {
		//	var bits = bytes * 8;
         //   if (bits < 1000) {
         //       return 'VERY LOW - ' + bits + ' bps';
         //       //return "WEAK";
         //   } else if (bits < 1000000) {
         //       var kbps = parseFloat((bits / 1000).toFixed(2), 10);
         //       return (kbps >= 250 ? 'MODERATE' : 'LOW') + ' - ' + kbps + ' kbps';
         //       //return "MIDDLE";
         //   } else {
         //       return 'GOOD ' + (bits / 1000000).toFixed(2) + ' mbps';
         //       //return "GOOD";
         //   }
        //};

        //设定statuschange的时间点，用于监测 PC 和 iPad 同步状态
        var curDate = new Date();
        var curYear = curDate.getFullYear();
        var curMon = curDate.getMonth() + 1;
        var curDay = curDate.getDate();
        var curHour = curDate.getHours();
        var curMin = curDate.getMinutes();
        var curSec = curDate.getSeconds();
        var curTime = curYear + "-" + curMon + "-" +curDay + " " + curHour + ":" + curMin + ":" + curSec;
        //console.log(peerId + " " + "=========================>" + curTime);
	    if(peerId === 'MCU'){
            console.log(peerId);
  	        //console.log('  videosend '+parseSendStatsFn(stats.video.sending.bytes)+"="+stats.video.sending.bytes);
            var nextSendSpeeds = stats.video.sending.bytes;
            var curSendStatus = parseSendStatsFn(nextSendSpeeds,curTime);

            signalIntensity(curSendStatus,agent_speed);

	    }else{
            console.log(peerId);
            //console.log('  videorecv '+parseRecStatsFn(stats.video.receiving.bytes)+"="+stats.video.receiving.bytes);
            var nextRecSpeeds = stats.video.receiving.bytes;
            var curRecStatus = parseRecStatsFn(nextRecSpeeds,curTime);

            signalIntensity(curRecStatus,$('#s'+peerId));
	    }
	}
});
//监测网络状态
//recive
function parseRecStatsFn(bytes,time) {
    var bits = bytes * 8;
    var kbps = parseFloat((bits / 1000).toFixed(2), 10)
    console.log(kbps);
    if (bits < 1000) {
        //console.log(time + " " + "Rec_veryLow ----" + kbps + "kbps");
        return "VeryLow";
    }else if(bits < 250000){
        //console.log(time + " " + "Rec_Low ----" + kbps + "kbps");
        return "Low";
    } else if (bits < 500000) {
        return (kbps >= 250 ? 'MODERATE' : 'LOW') + ' - ' + kbps + ' kbps';
        //console.log(time + " " + "Rec_Lower ----" + kbps + "kbps");
        return "Lower";
    } else if (bits < 1000000) {
        //return (kbps >= 250 ? 'MODERATE' : 'LOW') + ' - ' + kbps + ' kbps';
        //console.log(time + " " + "Rec_Moderate ----" + kbps + "kbps");
        return "Moderate";
    } else {
        //return 'GOOD ' + (bits / 1000000).toFixed(2) + ' mbps';
        //console.log(time + " " + "Rec_Strong ----" + kbps + "kbps");
        return "Strong";
    }
};
//send
function parseSendStatsFn(bytes,time) {
    var bits = bytes * 8;
    var kbps = parseFloat((bits / 1000).toFixed(2), 10)
    console.log(kbps);
    if (bits < 1000) {
        //console.log(time + " " + "Send_veryLow ----" + kbps + "kbps");
        return "VeryLow";
    }else if(bits < 250000){
        //console.log(time + " " + "Send_Low ----" + kbps + "kbps");
        return "Low";
    } else if (bits < 500000) {
        //return (kbps >= 250 ? 'MODERATE' : 'LOW') + ' - ' + kbps + ' kbps';
        //console.log(time + " " + "Send_Lower ----" + kbps + "kbps");
        return "Lower";
    }  else if (bits < 1000000) {
        //return (kbps >= 250 ? 'MODERATE' : 'LOW') + ' - ' + kbps + ' kbps';
        //console.log(time + " " + "Send_Moderate ----" + kbps + "kbps");
        return "Moderate";
    } else {
        //return 'GOOD ' + (bits / 1000000).toFixed(2) + ' mbps';
        //console.log(time + " " + "Send_Strong ----" + kbps + "kbps");
        return "Strong";
    }
};


//监听视频加载成功之后 调用该方法
function resetHeight(){
    //console.log("Video loading complete！");
    //var vH = $('#video_cont').height();
    //console.log("Gola" + vH);
    //调整有侧聊天窗口高度自适应
    var winH = window.parent.window.innerHeight || window.parent.document.body.clientHeight || window.parent.document.documentElement.clientHeight;
//        console.log(window.parent.window.innerHeight);
//        console.log(window.parent.document.body.clientHeight);
//        console.log(winH);
    var wH = winH - 55 - 22 - 14;//55是iframe有一个padding-top值,22是userTips的高度,14是距离body底部的距离
    //console.log(wH);
    window.parent.document.getElementById("video_chat_content").style.height = wH + "px";
    var video_cont_h = document.getElementById("video_cont").offsetHeight;
    var bandwidth_speed = document.getElementById("bandwidth_speed").offsetHeight;
    var chat_input_public = document.getElementById("chat_input_public").offsetHeight;//聊天输入框高度
    //console.log("Gola" + video_cont_h);
    var chat_cont_h = wH - video_cont_h - bandwidth_speed;
    document.getElementById("chat_cont").style.height = chat_cont_h + "px";///wH*100 + "%";
    document.getElementById("chat_body").style.height = chat_cont_h - chat_input_public -40 - 10 - 2 +'px';//60是button：btn-panel高度，10是button-btn-panel的mairgin-top值，2是微调值
}
//监测网络信号强度
var agent_speed = $("#agent_speed");
var aStatus = "VeryLow";
signalIntensity(aStatus,agent_speed);

function signalIntensity(status,parent){
    var len = 5;
   // parent.empty();
    if(status == "VeryLow"){
        for(var i = 0;i < len; i ++){
            var curI = i + 1;
            var em = document.createElement("em");
            em.setAttribute("class","speedStatus sS" + curI);
            if(i < 1){
                em.style.borderLeftColor = "red";
            }
            parent.append(em);
        };
    }else if(status == "Low"){
        for(var i = 0;i < len; i ++){
            var curI = i + 1;
            var em = document.createElement("em");
            em.setAttribute("class","speedStatus sS" + curI);
            if(i < 2){
                em.style.borderLeftColor = "red";
            }
            parent.append(em);
        };
    }else if(status == "Lower"){
        for(var i = 0;i < len; i ++){
            var curI = i + 1;
            var em = document.createElement("em");
            em.setAttribute("class","speedStatus sS" + curI);
            if(i < 3){
                em.style.borderLeftColor = "rgb(249,189,94)";
            }
            parent.append(em);
        };
    }else if(status == "Moderate"){
        for(var i = 0;i < len; i ++){
            var curI = i + 1;
            var em = document.createElement("em");
            em.setAttribute("class","speedStatus sS" + curI);
            if(i < 4){
                em.style.borderLeftColor = "rgb(249,189,94)";
            }
            parent.append(em);
        };
    }else if(status == "Strong"){
        for(var i = 0;i < len; i ++){
            var curI = i + 1;
            var em = document.createElement("em");
            em.setAttribute("class","speedStatus sS" + curI);
            em.style.borderLeftColor = "green";
            parent.append(em);
        };
    };
    
}