function initTemasys() {
	//var user = getUser();
	//var channal = getChannal();
    //$("#video_right").attr("src", "./mjs/video/view/temasys.html");
    //$("#msg_right").attr("src", "./mjs/video/view/chat.html");
    //
    //$('#video_right').on('load', function () {
    //    this.contentWindow.initVideo(channal);
    //});
    //$('#msg_right').on('load', function () {
    //    this.contentWindow.initChat(channal,user);
    //});
	//if show in pad ,empty the iframe param src in content_right part
	if((/ipad|iphone/gi).test(navigator.appVersion)){
		$("#userTips").empty();
		$("#video_chat_content").attr("src","");
	}else{
		$("#video_chat_content").attr("src","./mjs/video/view/videochat.html");
	}

	//$("#video_chat_content").on("load",function(){
	//	this.contentWindow.initVideo(channal);
	//	this.contentWindow.initChat(channal,user);
	//});

}

function getChannal(){
	var channal = getQueryString('token');
 	if(channal != null){
 		return channal;
 	}
	return 'a1234567890aaa';
 }
 
 function getUser(){
 	var user = getQueryString('user');
 	if(user != null){
 		return user;
 	}
	return 'user1';
 }
  
function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if (r != null)return unescape(r[2]);
    return null;
}